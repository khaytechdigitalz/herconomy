<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Tier extends Model
{
    protected $table = "tiers";

    protected  $guarded = ['id'];
   
}
