
<?php
    $subscribe = getContent('subscribe.content', true);
?>


<section  <?php echo e(gradient()); ?>  class="newsletter-section bg--base padding-top padding-bottom">
    <div class="container">
        <div class="section-header mb-4">
            <h3 class="title mb-0"><?php echo app('translator')->get(@$subscribe->data_values->text); ?></h3>
        </div>
        <div class="subscribe-form ml-auto mr-auto">
            <input type="text" placeholder="Enter Your Email Address" class="form-control" name="email">
            <button type="button" class="subscribe-btn"><?php echo app('translator')->get('Subscribe'); ?></button>
        </div>
    </div>
</section>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/sections/subscribe.blade.php ENDPATH**/ ?>