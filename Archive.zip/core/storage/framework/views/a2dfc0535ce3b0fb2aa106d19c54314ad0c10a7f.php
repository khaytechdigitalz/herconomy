<?php $__env->startSection('panel'); ?>
<div class="row">
    <div class="col-lg-12">
        <form action="<?php echo e(route('admin.coupon.store', $coupon->id??0)); ?>" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0"><?php echo app('translator')->get('General Information'); ?></h5>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group row">
                                <div class="col-lg-2 col-md-3">
                                    <label class="font-weight-bold" for="coupon_name"><?php echo app('translator')->get('Coupon Name'); ?> </label>
                                </div>
                                <div class="col-lg-10 col-md-9">
                                    <input type="text" class="form-control" id="coupon_name" name="coupon_name" value="<?php echo e(isset($coupon)?$coupon->coupon_name:old('coupon_name')); ?>" placeholder="<?php echo app('translator')->get('Type Here'); ?>..." />
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-2 col-md-3">
                                    <label class="font-weight-bold" for="coupon_code"><?php echo app('translator')->get('Coupon Code'); ?></label>
                                </div>
                                <div class="col-lg-10 col-md-9">
                                    <input type="text" class="form-control" id="coupon_code" name="coupon_code" value="<?php echo e(isset($coupon)?$coupon->coupon_code:old('coupon_code')); ?>" placeholder="<?php echo app('translator')->get('Type Here'); ?>...">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-2 col-md-3">
                                    <label class="font-weight-bold" for="discount_type"><?php echo app('translator')->get('Discount Type'); ?></label>
                                </div>
                                <div class="col-lg-10 col-md-9">
                                    <select class="form-control" id="discount_type" name="discount_type">
                                        <option selected value=""><?php echo app('translator')->get('Select One'); ?></option>
                                        <option value="1"><?php echo app('translator')->get('Fixed'); ?></option>
                                        <option value="2"><?php echo app('translator')->get('Percentage'); ?></option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-2 col-md-3">
                                    <label class="font-weight-bold" for="amount"><?php echo app('translator')->get('Amount'); ?></label>
                                </div>
                                <div class="col-lg-10 col-md-9">
                                    <div class="input-group">
                                        <input type="number" class="form-control numeric-validation" id="amount" name="amount" value="<?php echo e(isset($coupon)?$coupon->coupon_amount:old('amount')); ?>" placeholder="<?php echo app('translator')->get('Type Here'); ?>...">
                                        <div class="input-group-append">
                                            <span class="input-group-text" id="basic-addon2"><?php if(isset($coupon)): ?> <?php echo e($coupon->type==1?$general->cur_sym:'%'); ?> <?php else: ?> <?php echo e($general->cur_text); ?> <?php endif; ?></span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-2 col-md-3">
                                    <label class="font-weight-bold" for="start_date"><?php echo app('translator')->get('Start Date'); ?></label>
                                </div>
                                <div class="col-lg-10 col-md-9">
                                    <input type="text" name="start_date" id="start_date" class="datepicker-here form-control" data-language='en' data-date-format="yyyy-mm-dd" data-position='bottom left' value="<?php echo e(isset($coupon)?$coupon->start_date:old('start_date')); ?>" placeholder="<?php echo app('translator')->get('Select Date'); ?>" autocomplete="off" >

                                    <small class="form-text text-muted"> <i class="fa fa-info-circle" aria-hidden="true"></i> <?php echo app('translator')->get('Year-Month-Date'); ?></small>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-2 col-md-3">
                                    <label class="font-weight-bold" for="end_date"><?php echo app('translator')->get('End Date'); ?></label>
                                </div>
                                <div class="col-lg-10 col-md-9">
                                    <input type="text" name="end_date" id="end_date" class="datepicker-here form-control" data-language='en' data-date-format="yyyy-mm-dd" data-position='bottom left' value="<?php echo e(isset($coupon)?$coupon->end_date:old('end_date')); ?>" placeholder="<?php echo app('translator')->get('Select Date'); ?>" autocomplete="off">
                                    <small class="form-text text-muted"> <i class="fa fa-info-circle" aria-hidden="true"></i> <?php echo app('translator')->get('Year-Month-Date'); ?></small>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-2 col-md-3">
                                    <label class="font-weight-bold" for="description"><?php echo app('translator')->get('Description'); ?></label>
                                </div>
                                <div class="col-lg-10 col-md-9">
                                    <textarea class="form-control" name="description" id="description" rows="3"><?php echo e(isset($coupon)?$coupon->description:old('$coupon->description')); ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card my-3">
                <div class="card-header">
                    <h5 class="card-title mb-0"><?php echo app('translator')->get('Usage Restrictions'); ?></h5>
                </div>
                <div class="card-body has-select2">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="form-group row  ">
                                <div class="col-lg-2 col-md-3">
                                    <label class="font-weight-bold" for="minimum_spend"><?php echo app('translator')->get('Minimum Spend'); ?></label>
                                </div>

                                <div class="col-lg-10 col-md-9">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon2"> <?php echo e($general->cur_sym); ?></span>
                                        </div>
                                        <input type="number" class="form-control numeric-validation" id="minimum_spend" name="minimum_spend" value="<?php echo e(isset($coupon)?$coupon->minimum_spend:old('minimum_spend')); ?>" placeholder="<?php echo app('translator')->get('Type Here'); ?>..." />
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-2 col-md-3">
                                    <label class="font-weight-bold" for="maximum_spend"><?php echo app('translator')->get('Maximum Spend'); ?></label>
                                </div>
                                <div class="col-lg-10 col-md-9">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text" id="basic-addon2"> <?php echo e($general->cur_sym); ?></span>
                                        </div>
                                        <input type="number" class="form-control numeric-validation" id="maximum_spend" name="maximum_spend" value="<?php echo e(isset($coupon)?$coupon->maximum_spend:old('maximum_spend')); ?>" placeholder="<?php echo app('translator')->get('Type Here'); ?>...">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-2 col-md-3">
                                    <label class="font-weight-bold" for="categories"><?php echo app('translator')->get('Categories'); ?></label>
                                </div>
                                <div class="col-lg-10 col-md-9">
                                    <select class="select2-multi-select form-control" name="categories[]" id="categories" multiple>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($category->id); ?>"><?php echo app('translator')->get($category->name); ?></option>
                                            <?php
                                                $prefix = '--'
                                            ?>
                                            <?php $__currentLoopData = $category->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php echo $__env->make('admin.partials.subcategories', ['subcategory' => $subcategory, 'prefix'=>$prefix], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                <option value="<?php echo e($subcategory->id); ?>">
                                                    <?php echo e($prefix); ?><?php echo app('translator')->get($subcategory->name); ?>
                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-2 col-md-3">
                                    <label class="font-weight-bold"><?php echo app('translator')->get('Select Product'); ?></label>
                                </div>
                                <div class="col-lg-10 col-md-9">

                                    <select class="form-control" id="products" name="products[]" multiple>
                                        <?php if(request()->routeIs('admin.coupon.edit')): ?>
                                            <?php $__currentLoopData = $coupon->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($product->id); ?>"><?php echo e(__($product->name)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-2 col-md-3">
                                    <label for="usage_limit_per_coupon" class="font-weight-bold"><?php echo app('translator')->get('Usage Limit Per Coupon'); ?></label>
                                </div>
                                <div class="col-lg-10 col-md-9">
                                    <input name="usage_limit_per_coupon" class="form-control integer-validation" id="usage_limit_per_coupon" value="<?php echo e(isset($coupon)?$coupon->usage_limit_per_coupon:old('usage_limit_per_coupon')); ?>" type="number" placeholder="<?php echo app('translator')->get('Type Here'); ?>...">
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-lg-2 col-md-3">
                                    <label for="usage_limit_per_customer" class="font-weight-bold"><?php echo app('translator')->get('Usage Limit Per Customer'); ?></label>
                                </div>
                                <div class="col-lg-10 col-md-9">
                                    <input name="usage_limit_per_customer" class="form-control numeric-validation" id="usage_limit_per_customer" value="<?php echo e(isset($coupon)?$coupon->usage_limit_per_user:old('usage_limit_per_customer')); ?>" type="number" placeholder="<?php echo app('translator')->get('Type Here'); ?>...">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <button type="submit" class="btn btn-block btn--primary"><?php echo app('translator')->get('Add'); ?></button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <a href="<?php echo e(route('admin.coupon.index')); ?>" class="btn btn-sm btn--primary box--shadow1 text--small"><i class="la la-backward"></i><?php echo app('translator')->get('Go Back'); ?></a>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        (function($){
            var dropdownParent = $('.has-select2');
            $('.select2-basic, .select2-multi-select').select2({
                dropdownParent: dropdownParent,
                closeOnSelect: false
            });

            $('#discount_type').on('change', function () {
                var val = this.value;
                if(val == 1) {
                    $('#basic-addon2').text(`<?php echo e($general->cur_sym); ?>`);
                }else{
                    $('#basic-addon2').text(`%`);
                }
            });

            <?php if(request()->routeIs('admin.coupon.edit')): ?>
                var categories = <?php echo json_encode($coupon->categories->pluck('id'), 15, 512) ?>;

                var products = <?php echo json_encode($coupon->products->pluck('id'), 15, 512) ?>;
                $('#products').val(products);

                $('#discount_type').val(<?php echo e($coupon->discount_type); ?>);
                if($('#discount_type').val() == 1) {
                    $('#basic-addon2').text(`<?php echo e($general->cur_sym); ?>`);
                }else{
                    $('#basic-addon2').text(`%`);
                }
                $('#categories').val(categories);
                $('.select2-multi-select').select2({
                    dropdownParent: dropdownParent,
                    closeOnSelect: false
                });

                $('#start_date').datepicker({
                    singleDatePicker: true,
                    showDropdowns: true,
                    autoApply: true,
                    locale: {
                        format: 'YYYY-MM-DD'
                    }
                }).data('datepicker').selectDate(new Date($('#start_date').val()));

                $('#end_date').datepicker({
                    singleDatePicker: true,
                    showDropdowns: true,
                    autoApply: true,
                    locale: {
                        format: 'YYYY-MM-DD'
                    }
                }).data('datepicker').selectDate(new Date($('#end_date').val()));
            <?php else: ?>
            $('.datepicker-here').datepicker({
                singleDatePicker: true,
                showDropdowns: true,
                autoApply: true,
                locale: {
                    format: 'YYYY-MM-DD'
                }
            });

            <?php endif; ?>

            $('#products').select2({
                ajax: {
                    url: '<?php echo e(route("admin.products_for_coupon")); ?>',
                    type: "get",
                    dataType: 'json',
                    delay: 1000,
                    data: function (params) {

                        return {
                            search: params.term,
                            page : params.page,// Page number, page breaks
                            rows : 5// How many rows are displayed per page
                        };
                    },
                    processResults: function (response, params) {
                        params.page = params.page || 1;
                        return {
                            results: response,
                            pagination : {
                                more : params.page < response.length
                            }
                        };
                    },
                    cache: false
                },
                dropdownParent: dropdownParent
            });
        })(jQuery)

    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script-lib'); ?>
<script type="text/javascript" src="<?php echo e(asset('assets/dashboard/js/vendor/datepicker.min.js')); ?>"></script>
<script type="text/javascript" src="<?php echo e(asset('assets/dashboard/js/vendor/datepicker.en.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/admin/coupons/create.blade.php ENDPATH**/ ?>