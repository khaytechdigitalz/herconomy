
<?php
    $invite = getContent('invite_seller.content', true);
?>

<?php if($invite): ?>
<section  <?php echo e(gradient()); ?>  class="newsletter-section bg--base mt-4">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-xl-7 col-lg-6">
                <div class="newsletter-header">
                    <h3 class="title">
                        <?php echo app('translator')->get(@$invite->data_values->text); ?>
                    </h3>
                </div>
            </div>
            <div class="col-xl-5 col-lg-6 text-lg-right">
                <a href="<?php echo e(url(@$invite->data_values->button_link)); ?>" class="cmn--btn white"><?php echo app('translator')->get(@$invite->data_values->button_text); ?></a>
            </div>
        </div>
    </div>
</section>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/sections/invite_seller.blade.php ENDPATH**/ ?>