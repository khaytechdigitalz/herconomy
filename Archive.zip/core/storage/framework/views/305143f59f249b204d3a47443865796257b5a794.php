<?php $__env->startSection('content'); ?>

<div class="user-profile-section padding-top padding-bottom">
    <div class="container">
        <div class="row">
            <div class="col-xl-3">
                <div class="dashboard-menu">
                    <?php echo $__env->make($activeTemplate.'user.partials.dp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <ul>
                        <?php echo $__env->make($activeTemplate.'user.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-xl-9">
        <div class="table-responsive--md">
          <table class="table custom--table">
            <thead>
              <tr>
                <th><?php echo app('translator')->get('Name'); ?></th>
                <th><?php echo app('translator')->get('Email'); ?></th>
                <th><?php echo app('translator')->get('Username'); ?></th>
                <th><?php echo app('translator')->get('Status'); ?></th>
                <th><?php echo app('translator')->get('Date Joined'); ?></th>
              </tr>
            </thead>
            <tbody>

            <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td data-label="<?php echo app('translator')->get('Name'); ?>"><?php echo e($data->fullname); ?></td>
                <td data-label="<?php echo app('translator')->get('Email'); ?>">
                    <strong>
                        <?php echo e($data->email); ?>

                    </strong>
                </td>
                <td data-label="<?php echo app('translator')->get('Username'); ?>">
                    <strong>
                        <?php echo e($data->username); ?>

                    </strong>
                </td>
                
                <td data-label="<?php echo app('translator')->get('Status'); ?>">
                    <?php if($data->status == 0): ?>
                        <span class="badge badge--info"><?php echo app('translator')->get('Inactibe'); ?></span>
                    <?php else: ?>
                        <span class="badge badge--success"><?php echo app('translator')->get('Active'); ?></span>
                    <?php endif; ?>
                </td>
                <td data-label="<?php echo app('translator')->get('Next Return Date'); ?>"><?php echo e(showDateTime($data->created_at)); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                </tr>
            <?php endif; ?>

            </tbody>
          </table>
        </div>

        <?php echo e($logs->links()); ?>


      </div>
    </div>
  </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/user/ref_log.blade.php ENDPATH**/ ?>