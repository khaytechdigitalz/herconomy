
<h4 class="title"><?php echo app('translator')->get('Your Cart'); ?></h4>
<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

<div class="single-product-item">
    <div class="thumb">
        <img src="<?php echo e(getImage(imagePath()['product']['path'].'/'.@$item->product->main_image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('shop'); ?>">
    </div>
    <div class="content">
        <h4 class="title"><a class="cl-white" href="<?php echo e(route('product.detail', ['id'=>$item->product->id, 'slug'=>slug($item->product->name)])); ?>"><?php echo e(shortDescription(__($item->product->name), 35)); ?></a></h4>
        <div class="price">
            <span class="pprice">
                <?php echo e($general->cur_sym); ?><?php
                    if($item->attributes != null){
                        $s_price = App\Models\AssignProductAttribute::priceAfterAttribute($item->product, $item->attributes);
                        echo getAmount($s_price, 2);
                    }else{
                        if($item->product->offer && $item->product->offer->activeOffer){
                            $s_price = $item->product->base_price - calculateDiscount($item->product->offer->activeOffer->amount, $item->product->offer->activeOffer->discount_type, $item->product->base_price);
                        }else{
                            $s_price = $item->product->base_price;
                        }
                        echo getAmount($s_price, 2);
                    }
                ?>
                x <?php echo e($item->quantity); ?>

            </span>
        </div>
        <div class="text-white">
            <?php if($item->attributes != null): ?>
                <?php echo App\Models\AssignProductAttribute::cartAttributesShow($item->attributes) ?>
            <?php endif; ?>
        </div>

        <a href="javascript:void(0)" class="remove-item-button remove-cart-item" data-id="<?php echo e($item->id); ?>" data-pid="<?php echo e($item->product->id); ?>"><i class="la la-times"></i></a>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="single-product-item no_data">
    <div class="no_data-thumb w-50 ml-auto mr-auto mb-4 text-white">
        <i class="la la-shopping-basket la-10x"></i>
    </div>
    <h6 class="cl-white"><?php echo e(__($emptyMessage)); ?></h6>
</div>
<?php endif; ?>

<?php if($data->count()>0): ?>
<div class="btn-wrapper text-center">
    <a href="<?php echo e(route('shopping-cart')); ?>" class="qv-btn bg btn-block"><?php if($more> 0): ?>
        <?php echo app('translator')->get('And'); ?> <?php echo e($more); ?> <?php echo app('translator')->get('More'); ?>
    <?php else: ?>
        <?php echo app('translator')->get('View Cart'); ?>
    <?php endif; ?></a>
</div>
<?php endif; ?>

<?php if($subtotal > 0): ?>
    <div class="d-flex justify-content-between mt-3 text-white">
        <span class="text-white"> <?php echo app('translator')->get('Subtotal'); ?> </span>
        <span class="text-white"><?php echo e($general->cur_sym); ?><?php echo e(getAmount($subtotal, 2)); ?></span>

    </div>
    <?php if($coupon): ?>

    <div class="coupon-wrapper">
        <div class="d-flex mt-1 text-white">
            <span class="mr-2 text-danger remove-coupon"><i class="la la-times-circle"></i></span>
            <span><?php echo app('translator')->get('Coupon'); ?> (<b class="couponCode1"><?php echo e($coupon['code']); ?></b>) </span>
            <div class="ml-auto">
                <span class="amount"><?php echo e($general->cur_sym); ?><span class="couponAmount"> <?php echo e(getAmount($coupon['amount'], 2)); ?></span> </span>
            </div>
        </div>

        <div class="d-flex justify-content-between mt-1 text-white border-top-1">
            <span class="text-white"> <?php echo app('translator')->get('Total Amount'); ?> </span>
            <span class="text-white"><?php echo e($general->cur_sym); ?><?php echo e(getAmount($subtotal - $coupon['amount'], 2)); ?></span>
        </div>
    </div>

    <?php endif; ?>
<?php endif; ?>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/partials/cart_items.blade.php ENDPATH**/ ?>