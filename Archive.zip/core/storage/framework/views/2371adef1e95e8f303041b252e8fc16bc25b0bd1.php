<?php
    $sliders = getContent('banner_sliders.element');
?>
<div class="banner-slider">
    <div class="banner__slider owl-theme owl-carousel">
        <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="slide-item">
                <div class="banner-slide-content">
                    <a href="<?php echo e(url(@$slider->data_values->link ?? '/')); ?>" class="d-block">
                        <div class="banner__img">
                            <img src="<?php echo e(getImage('assets/images/frontend/banner_sliders/'. @$slider->data_values->slider, '1024x608')); ?>" alt="<?php echo app('translator')->get('slider'); ?>">
                        </div>
                    </a>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="slide-progress"></div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/sections/banner_sliders.blade.php ENDPATH**/ ?>