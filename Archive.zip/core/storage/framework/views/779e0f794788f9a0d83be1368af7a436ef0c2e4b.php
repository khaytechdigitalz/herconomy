<?php $__env->startSection('content'); ?>
<!-- section start -->
<div class="compare-section padding-bottom padding-top">
    <div class="container">
        <div class="oh">
            <div class="compare-table-wrapper">

                <?php if($compare_items->count()>0): ?>
                <table class="compare-table">
                    <tbody>

                        <tr class="th-compare">
                            <?php $__currentLoopData = $compare_items->pluck('id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th class="product-<?php echo e($item); ?> text-right" >
                                <button type="button" data-pid="<?php echo e($item); ?>" class="bg-transparent remove-compare"><i class="las la-trash"></i></button>
                            </th>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>

                        <tr>
                            <?php $__currentLoopData = $compare_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="align-top product-<?php echo e($item->id); ?>">
                                <div class="compare-thumb">
                                    <img src="<?php echo e(getImage(imagePath()['product']['path'].'/'.@$item->main_image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('featured'); ?>">
                                </div>
                                <div class="name">
                                    <?php echo e($item->name); ?>

                                </div>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>

                        <tr>
                            <?php $__currentLoopData = $compare_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <td class="p-0 product-<?php echo e($item->id); ?>">
                                <ul class="compare-specification">
                                    <?php if($item->specification): ?>
                                        <?php $__currentLoopData = $item->specification; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <span class="title"><?php echo e(@$specification['name']); ?></span>
                                            <span class="info"><?php echo e(@$specification['value']); ?></span>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </ul>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>

                        <tr>
                            <?php $__currentLoopData = $compare_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                if($item->offer && $item->offer->activeOffer){
                                    $discount = calculateDiscount($item->offer->activeOffer->amount, $item->offer->activeOffer->discount_type, $item->base_price);
                                }else $discount = 0;
                            ?>
                            <td class="p-0 product-<?php echo e($item->id); ?>">
                                <ul class="compare-specification">
                                    <li><span class="title"><?php echo app('translator')->get('Price'); ?></span>

                                    <span class="info"> <?php if($discount > 0): ?>
                                        <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price - $discount, 2)); ?>

                                        <del><?php echo e(getAmount($item->base_price, 2)); ?></del>
                                        <?php else: ?>
                                        <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price, 2)); ?>

                                        <?php endif; ?></span>

                                    </li>
                                </ul>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>

                        <tr>
                            <?php $__currentLoopData = $compare_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <td class="p-0 product-<?php echo e($item->id); ?>">
                                <ul class="compare-specification">
                                    <li><span class="title"><?php echo app('translator')->get('Availability'); ?></span>
                                    <?php if($item->stocks->sum('quantity') > 0): ?>
                                    <span class="text-success info"><?php echo app('translator')->get('Available in Stock'); ?></span>
                                    <?php else: ?>
                                    <span class="text-danger info"><?php echo app('translator')->get('Not Available in Stock'); ?></span>
                                    <?php endif; ?>
                                    </li>
                                </ul>
                            </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>

                        <tr>
                            <?php $__currentLoopData = $compare_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <td class="product-<?php echo e($item->id); ?>"><a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>" class="cmn-btn btn-block"><?php echo app('translator')->get('Buy Now'); ?></a></td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>


                    </tbody>
                </table>
                <?php else: ?>
                    <?php if($compare_items->count() == 0): ?>
                        <div class="col-lg-12 mb-30">
                            <?php echo $__env->make($activeTemplate.'partials.empty_page', ['message' => __($emptyMessage)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    <?php endif; ?>

                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<!-- Section ends -->


<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        (function($){
            $('.remove-compare').on('click', function(){
                var pid = $(this).data('pid');
                var className = `.product-${pid}`;
                var data = {id:pid};


                $.ajax({
                    headers: {"X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"},
                    url: "<?php echo e(route('del-from-compare', '')); ?>"+"/"+pid,
                    method:"post",
                    data: data,
                    success: function(response){
                        if(response.message) {
                            notify('success', response.message);
                            $(document).find(className).hide('300');
                            getCompareData();
                        }else{
                            notify('error', response.error);
                        }
                    }
                });
            });

        })(jQuery)
    </script>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('meta-tags'); ?>
    <?php echo $__env->make('partials.seo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate .'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/compare.blade.php ENDPATH**/ ?>