
<?php if($topSellingProducts->count()): ?>
<section class="cash-on-shop-section padding-bottom padding-top-half overflow-hidden">
    <div class="container">
        <div class="section-header-2 left-style">
            <h4 class="title pr-0"><?php echo app('translator')->get('Top Selling Products'); ?></h4>
        </div>

        <div class="row g-3 justify-content-center">
            <?php $__currentLoopData = $topSellingProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-md-6 col-lg-4">
                <div class="best-sell-item">
                    <div class="best-sell-inner">
                        <div class="thumb">
                            <a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>"><img src="<?php echo e(getImage(imagePath()['product']['path'].'/thumb_'.@$item->main_image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('products-sell'); ?>"></a>
                        </div>
                        <div class="content">
                            <h6 class="title">
                                <h6 class="title">
                                    <a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>"><?php echo e(__($item->name)); ?></a>
                                </h6>
                            </h6>
                            <div class="ratings-area justify-content-between">
                                <div class="ratings">
                                    <?php echo displayAvgRating($item->reviews) ?>
                                </div>
                                <span class="ml-2 mr-auto">(<?php echo e($item->reviews->count()); ?>)</span>
                            </div>
                            <a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>" class="read-more cl-1"><?php echo app('translator')->get('View Details'); ?><i class="las la-long-arrow-alt-right"></i></a>
                        </div>
                    </div>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/sections/trending_products.blade.php ENDPATH**/ ?>