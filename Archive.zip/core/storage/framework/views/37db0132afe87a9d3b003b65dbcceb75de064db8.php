<div class="row product-details-wrapper">
    <div class="col-lg-5 variant-images">
        <div class="sync1 owl-carousel owl-theme">
            <?php if($product->productImages->count() == 0): ?>
                <div class="thumbs">
                    <img src="<?php echo e(getImage(imagePath()['product']['path'].'/'.@$product->main_image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('products-details'); ?>">
                </div>
            <?php else: ?>
                <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="thumbs">
                    <img src="<?php echo e(getImage(imagePath()['product']['path'].'/'.@$item->image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('products-details'); ?>">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>

        <div class="sync2 owl-carousel owl-theme mt-2">
            <?php if($product->productImages->count() > 1): ?>
                <?php $__currentLoopData = $product->productImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="thumbs">
                    <img src="<?php echo e(getImage(imagePath()['product']['path'].'/thumb_'.@$item->image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('products-details'); ?>">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </div>
    </div>

    <div class="col-lg-7">
        <div class="product-details-content product-details">
            <h4 class="title mt-3"><?php echo e(__($product->name)); ?></h4>

            <?php if($product->show_in_frontend && $product->track_inventory): ?>
                <?php $quantity = $product->stocks->sum('quantity'); ?>
                <div data-stocks="<?php echo e($product->stocks); ?>" class="badge badge--<?php echo e($quantity>0?'success':'danger'); ?> stock-status">
                    <?php echo app('translator')->get('In Stock'); ?> (<span class="stock-qty"><?php echo e($quantity); ?></span>)
                </div>
            <?php endif; ?>

            <div class="ratings-area justify-content-between">
                <div class="ratings">
                    <?php echo displayAvgRating($product->reviews) ?>
                </div>
                <span class="ml-2 mr-auto">(<?php echo e(__($product->reviews->count())); ?>)</span>
            </div>

            <div class="price">
                <?php if($discount > 0): ?>
                    <?php echo e($general->cur_sym); ?><span class="special_price"><?php echo e(getAmount($product->base_price - $discount)); ?></span>
                    <del><?php echo e($general->cur_sym); ?></del><del class="price-data"><?php echo e(getAmount($product->base_price)); ?></del>
                <?php else: ?>
                    <?php echo e($general->cur_sym); ?><span class="price-data"><?php echo e(getAmount($product->base_price)); ?></span>
                <?php endif; ?>
            </div>

            <p>
                <?php echo __($product->summary) ?>
            </p>

            <?php $__empty_1 = true; $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <?php $attr_data = \App\Models\AssignProductAttribute::productAttributes($product->id, $attr->product_attribute_id); ?>
            <?php if($attr->productAttribute->type==1): ?>
            <div class="product-size-area attr-area">
                <span class="caption"><?php echo e($attr->productAttribute->name_for_user); ?></span>
                <?php $__currentLoopData = $attr_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product-single-size attribute-btn" data-type="1" data-ti="<?php echo e($product->track_inventory); ?>" data-discount=<?php echo e($discount); ?> data-attr_count="<?php echo e($attributes->count()); ?>" data-id="<?php echo e($data->id); ?>" data-product_id="<?php echo e($product->id); ?>"  data-price="<?php echo e($data->extra_price); ?>" data-base_price="<?php echo e(getAmount($product->base_price)); ?>" ><?php echo e($data->value); ?></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <?php if($attr->productAttribute->type==2): ?>
            <div class="product-color-area attr-area">
                <span class="caption"><?php echo e($attr->productAttribute->name_for_user); ?></span>
                <?php $__currentLoopData = $attr_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product-single-color attribute-btn" data-type="2" data-ti="<?php echo e($product->track_inventory); ?>" data-discount=<?php echo e($discount); ?> data-attr_count="<?php echo e($attributes->count()); ?>" data-id="<?php echo e($data->id); ?>" data-product_id="<?php echo e($product->id); ?>" data-bg="<?php echo e($data->value); ?>" data-price="<?php echo e($data->extra_price); ?>" data-base_price="<?php echo e(getAmount($product->base_price)); ?>"></div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <?php endif; ?>
            <?php if($attr->productAttribute->type==3): ?>
            <div class="product-color-area attr-area">
                <span class="caption"><?php echo e($attr->productAttribute->name_for_user); ?></span>
                <?php $__currentLoopData = $attr_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="product-single-color attribute-btn bg_img" data-type="3" data-ti="<?php echo e($product->track_inventory); ?>" data-discount=<?php echo e($discount); ?> data-attr_count="<?php echo e($attributes->count()); ?>" data-id="<?php echo e($data->id); ?>" data-product_id="<?php echo e($product->id); ?>" data-price="<?php echo e($data->extra_price); ?>" data-base_price="<?php echo e(getAmount($product->base_price)); ?>" data-background="<?php echo e(getImage(imagePath()['attribute']['path'].'/'. @$data->value)); ?>">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="cart-and-coupon mt-3">
                <div class="attr-data">
                </div>
                <div class="cart-plus-minus quantity">
                    <div class="cart-decrease qtybutton dec">
                        <i class="las la-minus"></i>
                    </div>
                    <input type="number" name="quantity" step="1" min="1" value="1" class="integer-validation">
                    <div class="cart-increase qtybutton inc">
                        <i class="las la-plus"></i>
                    </div>
                </div>

                <div class="add-cart">
                    <button type="button" class="qv-btn cart-add-btn" data-id="<?php echo e($product->id); ?>"><?php echo app('translator')->get('Add To Cart'); ?></button>
                </div>
            </div>
            <div>
                <p class="acc">
                    <b>
                        <?php echo app('translator')->get('Categories'); ?>:
                    </b>
                    <?php $__currentLoopData = $product->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('products.category', ['id'=>$category->id, 'slug'=>slug($category->name)])); ?>"><?php echo e(__($category->name)); ?></a>
                        <?php if(!$loop->last): ?>
                        /
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <p>
                    <b><?php echo app('translator')->get('Model'); ?>:</b> <?php echo e(__($product->model)); ?>

                </p>
                <p>
                    <b><?php echo app('translator')->get('Brand'); ?>:</b> <?php echo e(__($product->brand->name)); ?>

                </p>

                <p>
                    <b><?php echo app('translator')->get('SKU'); ?>:</b> <span class="product-sku"><?php echo e($product->sku??__('Not Available')); ?></span>
                </p>


                <?php if($product->meta_keywords): ?>
                <p>
                    <b>
                        <?php echo app('translator')->get('Tags'); ?>:
                    </b>
                    <?php $__currentLoopData = $product->meta_keywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href=""><?php echo e(__($tag)); ?></a><?php if(!$loop->last): ?>,<?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </p>
                <?php endif; ?>
                <div class="add-cart">
                    <a href="<?php echo e(route('product.detail', ['id'=>$product->id, 'slug'=>slug($product->name)])); ?>" class="qv-btn"><?php echo app('translator')->get('View More'); ?></a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/partials/quick_view.blade.php ENDPATH**/ ?>