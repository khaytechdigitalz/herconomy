<?php $__env->startSection('panel'); ?>
<div class="content-wrapper">
    <div class="container-fluid p-0">
        <div class="card">
            <div class="card-body">
                <!-- Main content -->
                <div class="invoice" id="invoice">
                    <!-- title row -->
                    <div class="row mt-3">
                        <div class="col-lg-6">
                            <h4><i class="fa fa-globe"></i> <?php echo e(__($general->sitename)); ?> </h4>
                        </div>
                        <div class="col-lg-6">
                        <h5 class="float-sm-right"><?php echo e(showDateTime($order->created_at, 'd/M/Y')); ?></h5>
                        </div>
                    </div>
                    <hr>
                    <div class="row invoice-info">
                        <div class="col-md-4">
                            <h5 class="mb-2"><?php echo app('translator')->get('User Details'); ?></h5>
                            <address>
                                <ul>
                                    <li><?php echo app('translator')->get('Name'); ?>: <strong><?php echo e(@$order->user->fullname); ?></strong></li>
                                    <li><?php echo app('translator')->get('Address'); ?>: <?php echo e(@$order->user->address->address); ?></li>
                                    <li><?php echo app('translator')->get('State'); ?>: <?php echo e(@$order->user->address->state); ?></li>
                                    <li><?php echo app('translator')->get('City'); ?>: <?php echo e(@$order->user->address->city); ?></li>
                                    <li><?php echo app('translator')->get('Zip'); ?>: <?php echo e(@$order->user->address->zip); ?></li>
                                    <li><?php echo app('translator')->get('Country'); ?>: <?php echo e(@$order->user->address->country); ?></li>
                                </ul>

                            </address>
                        </div><!-- /.col -->
                        <div class="col-md-4">
                            <h5 class="mb-2"><?php echo app('translator')->get('Shipping Address'); ?></h5>
                            <?php
                                $shipping_address = json_decode($order->shipping_address);
                            ?>

                            <address>
                                <ul>
                                <li><?php echo app('translator')->get('Name'); ?>: <strong><?php echo e($order->user->firstname); ?> <?php echo e($order->user->lastname); ?></strong></li>
                                    <li><?php echo app('translator')->get('Address'); ?>: <?php echo e($shipping_address->address); ?></li>
                                    <li><?php echo app('translator')->get('State'); ?>: <?php echo e($shipping_address->state); ?></li>
                                    <li><?php echo app('translator')->get('City'); ?>: <?php echo e($shipping_address->city); ?></li>
                                    <li><?php echo app('translator')->get('Zip'); ?>: <?php echo e($shipping_address->zip); ?></li>
                                    <li><?php echo app('translator')->get('Country'); ?>: <?php echo e($shipping_address->country); ?></li>
                                </ul>
                            </address>
                        </div><!-- /.col -->

                        <div class="col-md-4">
                            <b><?php echo app('translator')->get('Order ID'); ?>:</b> <?php echo e($order->order_number); ?><br>
                            <b><?php echo app('translator')->get('Order Date'); ?>:</b> <?php echo e(showDateTime($order->created_at, 'd/m/Y')); ?> <br>
                            <b><?php echo app('translator')->get('Total Amount'); ?>:</b> <?php echo e($general->cur_sym.$order->total_amount); ?>

                        </div><!-- /.col -->
                    </div><!-- /.row -->
                    <!-- Table row -->

                    <div class="row">
                        <div class="col-12 table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                <tr>
                                    <th><?php echo app('translator')->get('SN.'); ?></th>
                                    <th><?php echo app('translator')->get('Product'); ?></th>
                                    <th><?php echo app('translator')->get('Variants'); ?></th>
                                    <th><?php echo app('translator')->get('Discount'); ?></th>
                                    <th><?php echo app('translator')->get('Quantity'); ?></th>
                                    <th><?php echo app('translator')->get('Price'); ?></th>
                                    <th><?php echo app('translator')->get('Total Price'); ?></th>
                                </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $subtotal = 0;
                                    ?>
                                    <?php $__currentLoopData = $order->orderDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php
                                    $details = json_decode($data->details);
                                    $offer_price = $details->offer_amount;
                                    $extra_price = 0;
                                    ?>
                                    <tr>
                                        <td><?php echo e($loop->iteration); ?></td>
                                        <td><?php echo e($data->product->name); ?></td>
                                        <td>
                                            <?php if($details->variants): ?>
                                            <?php $__currentLoopData = $details->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                               <span class="d-block"><?php echo e(__($item->name)); ?> :  <b><?php echo e(__($item->value)); ?></b></span>
                                               <?php $extra_price += $item->price;  ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                            <?php echo app('translator')->get('N/A'); ?>
                                            <?php endif; ?>
                                        </td>
                                        <?php $base_price = $data->base_price + $extra_price ?>
                                        <td class="text-right"><?php echo e($general->cur_sym.getAmount($offer_price)); ?>/ <?php echo app('translator')->get('Item'); ?></td>
                                        <td class="text-center"><?php echo e($data->quantity); ?></td>
                                        <td class="text-right"><?php echo e($general->cur_sym. ($data->base_price - getAmount($offer_price))); ?></td>

                                        <td class="text-right"><?php echo e($general->cur_sym.getAmount(($base_price - $offer_price)*$data->quantity)); ?></td>
                                        <?php $subtotal += ($base_price - $offer_price) * $data->quantity ?>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                        </div><!-- /.col -->
                    </div><!-- /.row -->

                    <div class="row mt-4">
                        <!-- accepted payments column -->
                        <div class="col-lg-6">
                            <?php if(isset($order->deposit) && $order->deposit->status != 0): ?>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <tbody>
                                        <tr>
                                            <th width="50%"><?php echo app('translator')->get('Payment Method'); ?></td>
                                            <td width="50%"> <?php if($order->deposit->method_code == 0): ?>
                                                <span data-toggle="tooltip" title="<?php echo app('translator')->get('Cash On Delivery'); ?>"><?php echo app('translator')->get('COD'); ?></span>
                                            <?php endif; ?></td>
                                        </tr>

                                        <tr>
                                            <th><?php echo app('translator')->get('Payment Charge'); ?></td>
                                            <td><?php echo e($general->cur_sym. $charge = getAmount(@$order->deposit->charge)); ?></td>
                                        </tr>
                                        <tr>
                                            <th><?php echo app('translator')->get('Total Payment Amount'); ?> </td>
                                            <td><?php echo e($general->cur_sym. getAmount(($order->deposit->amount + $charge))); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <?php endif; ?>


                        </div><!-- /.col -->
                        <div class="col-lg-6">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <tbody>
                                        <tr>
                                            <th width="50%"><?php echo app('translator')->get('Subtotal'); ?></th>
                                            <td width="50%"><?php echo e(@$general->cur_sym.getAmount($subtotal, 2)); ?></td>
                                        </tr>
                                        <?php if($order->appliedCoupon): ?>
                                        <tr>
                                            <th>(<i class="la la-minus"></i>) <?php echo app('translator')->get('Coupon'); ?> (<?php echo e($order->appliedCoupon->coupon->coupon_code); ?>)</th>
                                            <td> <?php echo e($general->cur_sym.getAmount($order->appliedCoupon->amount, 2)); ?></td>
                                        </tr>
                                        <?php endif; ?>
                                        <tr>
                                            <th>(<i class="la la-plus"></i>) <?php echo app('translator')->get('Shipping'); ?></th>
                                            <td><?php echo e(@$general->cur_sym.getAmount($order->shipping_charge, 2)); ?></td>
                                        </tr>
                                        <tr>
                                            <th><?php echo app('translator')->get('Total'); ?></th>
                                            <td><?php echo e(@$general->cur_sym.($order->total_amount)); ?></td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div><!-- /.col -->
                    </div><!-- /.row -->
                    <!-- this row will not appear when printing -->
                </div><!-- /.content -->
                <hr>
                <div class="no-print float-right">

                    <a href="<?php echo e(route('print.invoice', $order->id)); ?>" target=blank class="btn btn-dark m-1"><i class="fa fa-print"></i><?php echo app('translator')->get('Print'); ?></a>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/admin/order/order_details.blade.php ENDPATH**/ ?>