<!-- Header Section Starts Here -->
<div class="header-top py-1 d-none d-lg-block" <?php echo e(gradient()); ?>>
    <div class="container">
        <div class="header-top-wrap d-flex flex-wrap justify-content-between align-items-center">
            <div class="select-item">
                <select name="language" class="select-bar selectLanguage">
                    <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->code); ?>" <?php if(session('lang') == $item->code): ?> selected  <?php endif; ?>><?php echo e(__($item->name)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="right-side">
                <ul class="menu ml-auto d-none d-lg-flex">
                    <li>
                        <a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('products')); ?>"><?php echo app('translator')->get('Products'); ?></a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('brands')); ?>"><?php echo app('translator')->get('Brands'); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('orderTrack')); ?>"><?php echo app('translator')->get('Track Order'); ?></a>
                    </li>
                    <?php if(auth()->guard()->check()): ?>
                    <li>
                        <a href="<?php echo e(route('ticket')); ?>"><?php echo app('translator')->get('Support'); ?></a>
                    </li>
                    <?php else: ?>
                     <li>
                        <a href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a>
                    </li>
                    <?php endif; ?>

                </ul>
            </div>
        </div>
    </div>
</div>
<div class="header-middle bg-white py-3" <?php echo e(gradient()); ?>>
    <div class="container">
        <div class="header-wrapper justify-content-between align-items-center">
            <div class="logo">
                <a href="<?php echo e(route('home')); ?>">
                    <img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="logo">
                </a>
            </div>

            <?php if(!request()->routeIs('home')): ?>
            <div class="header-category-area d-none d-lg-block">
                <button class="cmn--btn" type="submit"><?php echo app('translator')->get('All Categories'); ?></button>
                <div class="category-link-wrapper d-none d-lg-block">
                    <ul class="category-link d-none d-lg-block">
                        <?php $__currentLoopData = $allCategories->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="<?php echo e(route('products.category', ['id'=>$category->id, 'slug'=>slug($category->name)])); ?>">
                                    <?php echo e($category->name); ?>

                                </a>
                                <?php if($category->allSubcategories->count()>0): ?>
                                <ul class="category-sublink">
                                    <?php $__currentLoopData = $category->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo $__env->make($activeTemplate.'partials.menu_subcategories', ['subcategory' => $subcategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php endif; ?>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php if($allCategories->count()>10): ?>
                            <li> <a href="<?php echo e(route('categories')); ?>"><?php echo app('translator')->get('View All'); ?></a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
            <?php endif; ?>

            <form action="<?php echo e(route('product.search')); ?>" method="GET" class="header-search-form d-none d-md-block">
                <div class="header-form-group">
                    <input type="text" name="search_key" value="<?php echo e(request()->search_key); ?>" placeholder="<?php echo app('translator')->get('Search'); ?>...">
                    <button type="submit"><i class="las la-search"></i></button>
                </div>
                <div class="select-item">
                    <select class="select-bar" name="category_id">
                        <option selected value="0"><?php echo app('translator')->get('All Categories'); ?></option>
                        <?php $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option value="<?php echo e($category->id); ?>"><?php echo app('translator')->get($category->name); ?></option>
                            <?php
                                $prefix = '--'
                            ?>
                            <?php $__currentLoopData = $category->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($subcategory->id); ?>">
                                    <?php echo e($prefix); ?><?php echo app('translator')->get($subcategory->name); ?>
                                </option>

                                <?php echo $__env->make($activeTemplate.'partials.subcategories', ['subcategory' => $subcategory, 'prefix'=>$prefix], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </form>
            <ul class="shortcut-icons">
                <li>
                    <a href="javascript:void(0)" class="dashboard-menu-bar" id="account-btn">
                        <i style="color:black;" class="las la-user"></i>
                    </a>
                </li>
                <li>
                    <a href="<?php echo e(route('compare')); ?>">
                        <i style="color:black;" class="las la-sync-alt"></i>
                        <span class="compare-count amount">0</span>
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)" id="wish-button">
                        <i style="color:black;" class="lar la-heart"></i>
                        <span class="wishlist-count amount">0</span>
                    </a>
                </li>
                <li>
                    <a href="javascript:void(0)" id="cart-button">
                        <i style="color:black;" class="las la-shopping-bag"></i>
                        <span class="cart-count amount">0</span>
                    </a>
                </li>
            </ul>
            <div class="header-bar d-lg-none">
                <span style="color:white;" ></span>
                <span style="color:white;" ></span>
                <span style="color:white;" ></span>
            </div>
        </div>
    </div>
</div>
<div class="header-bottom body-bg py-lg-2 d-md-none">
    <div class="container">
        <form class="header-search-form">
            <div class="header-form-group">
                <input type="text" name="search_key" value="<?php echo e(request()->search_key); ?>" placeholder="<?php echo app('translator')->get('Search'); ?>...">
                <button type="submit"><i class="las la-search"></i></button>
            </div>
            <div class="select-item">
                <select class="select-bar" name="category_id">
                    <option selected value="0"><?php echo app('translator')->get('All Categories'); ?></option>
                    <?php $__currentLoopData = $allCategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <option value="<?php echo e($category->id); ?>"><?php echo app('translator')->get($category->name); ?></option>
                        <?php
                            $prefix = '--'
                        ?>
                        <?php $__currentLoopData = $category->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option value="<?php echo e($subcategory->id); ?>">
                                <?php echo e($prefix); ?><?php echo app('translator')->get($subcategory->name); ?>
                            </option>

                            <?php echo $__env->make($activeTemplate.'partials.subcategories', ['subcategory' => $subcategory, 'prefix'=>$prefix], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
        </form>
    </div>
</div>




<div class="mobile-menu d-lg-none"<?php echo e(gradient()); ?> >
    <div class="mobile-menu-header">
        <div class="mobile-menu-close">
            <i class="las la-times"></i>
        </div>
        <div class="logo">
            <a href="<?php echo e(route('home')); ?>">
                <img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo_2.png')); ?>" alt="logo">
            </a>
        </div>
        <div class="select-item">
            <select name="language" class="selectLanguage select-bar">
                <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                    <?php $__currentLoopData = $language; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->code); ?>" <?php if(session('lang') == $item->code): ?> selected  <?php endif; ?>><?php echo e(__($item->name)); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
    </div>

    <ul class="nav-tabs nav border-0">
        <li>
            <a href="#menu" class="active" data-toggle="tab"><?php echo app('translator')->get('Menu'); ?></a>
        </li>
        <li>
            <a href="#cate" data-toggle="tab"><?php echo app('translator')->get('Categories'); ?></a>
        </li>
    </ul>
    <div class="mobile-menu-body">
        <div class="tab-content">
            <div class="tab-pane fade show active" id="menu">
                <ul class="menu mt-4">
                    <li>
                        <a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('products')); ?>"><?php echo app('translator')->get('Products'); ?></a>
                    </li>

                    <li>
                        <a href="<?php echo e(route('brands')); ?>"><?php echo app('translator')->get('Brands'); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('orderTrack')); ?>"><?php echo app('translator')->get('Track Order'); ?></a>
                    </li>
                    <?php if(auth()->guard()->check()): ?>
                    <li>
                        <a href="<?php echo e(route('ticket')); ?>"><?php echo app('translator')->get('Support'); ?></a>
                    </li>
                    <?php else: ?>
                     <li>
                        <a href="<?php echo e(route('contact')); ?>"><?php echo app('translator')->get('Contact'); ?></a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
            <div class="tab-pane" id="cate">
                <div class="left-category single-style">
                    <ul class="categories">
                        <?php $__currentLoopData = $allCategories->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li>
                            <a href="<?php echo e(route('products.category', ['id'=>$category->id, 'slug'=>slug($category->name)])); ?>"><?php echo e($category->name); ?></a>

                            <?php if($category->allSubcategories->count()>0): ?>
                            <span class="open-links"></span>
                            <ul class="sub-category">
                                <?php $__currentLoopData = $category->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo $__env->make($activeTemplate.'partials.menu_subcategories', ['subcategory' => $subcategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <?php endif; ?>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php if($allCategories->count()>10): ?>
                            <li><a href="<?php echo e(route('categories')); ?>"><?php echo app('translator')->get('View All'); ?></a></li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>


<div id="body-overlay" class="body-overlay"></div>
<?php echo $__env->make($activeTemplate.'partials.side_modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/partials/header.blade.php ENDPATH**/ ?>