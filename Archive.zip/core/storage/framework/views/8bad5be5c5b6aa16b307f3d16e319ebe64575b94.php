<?php $__env->startSection('content'); ?>
<div class="payment-history-section padding-bottom padding-top">
    <div class="container">
        <div class="row">
            <div class="col-xl-3">
                <div class="dashboard-menu">
                    <?php echo $__env->make($activeTemplate.'user.partials.dp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <ul>
                        <?php echo $__env->make($activeTemplate.'user.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-xl-9">
                <table class="payment-table section-bg">
                    <thead>
                        <tr>
                            <th><?php echo app('translator')->get('S.N.'); ?></th>
                            <th><?php echo app('translator')->get('Order ID'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('Products'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('Payment'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('Order'); ?></th>
                            <th class="text-center"><?php echo app('translator')->get('Action'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td data-label="<?php echo app('translator')->get('#'); ?>"><?php echo e($loop->iteration); ?></td>
                            <td data-label="<?php echo app('translator')->get('Order ID'); ?>">
                                <a href="<?php echo e(route('user.order', $order->order_number)); ?>" class="text-info"><?php echo e($order->order_number); ?></a>
                            </td>
                            <td data-label="<?php echo app('translator')->get('Total Products'); ?>" class="text-center"><?php echo e($order->orderDetail->sum('quantity')); ?></td>


                            <td data-label="<?php echo app('translator')->get('Payment'); ?>">
                                <span class="text-white badge badge-capsule
                                    <?php if($order->payment_status==0): ?>
                                        badge--danger
                                    <?php elseif($order->payment_status==2): ?>
                                        badge--primary
                                    <?php else: ?>
                                        badge--success
                                    <?php endif; ?>
                                    ">
                                    <?php if($order->payment_status==0): ?>
                                        <?php echo app('translator')->get('Incomplete'); ?>
                                    <?php elseif($order->payment_status==2): ?>
                                        <abbr data-toggle="tooltip" title="<?php echo app('translator')->get('Cash On Delivery'); ?>"><?php echo e(@$deposit->gateway->name??trans('COD')); ?></abbr>
                                    <?php else: ?>
                                        <?php echo app('translator')->get('Paid'); ?>
                                    <?php endif; ?>
                                </span>
                            </td>

                            <td data-label="<?php echo app('translator')->get('Order Status'); ?>">
                                <span class="text-white badge badge-capsule
                                    <?php if($order->payment_status==0): ?>
                                        badge--danger
                                    <?php else: ?>
                                        <?php if($order->status == 0): ?>
                                            badge--primary
                                            <?php elseif($order->status == 1): ?>
                                            badge--primary
                                        <?php elseif($order->status == 2): ?>
                                            badge--info
                                            <?php elseif($order->status == 3): ?>
                                            badge--success
                                        <?php elseif($order->status == 4): ?>
                                            badge--danger
                                        <?php endif; ?>
                                    <?php endif; ?>
                                    ">
                                    <?php if($order->payment_status==0): ?>
                                    <?php echo app('translator')->get('Incomplete'); ?>
                                    <?php else: ?>
                                        <?php if($order->status == 0): ?>
                                            <?php echo app('translator')->get('Pending'); ?>
                                        <?php elseif($order->status == 1): ?>
                                            <?php echo app('translator')->get('Processing'); ?>...
                                        <?php elseif($order->status == 2): ?>
                                            <?php echo app('translator')->get('Dispatched'); ?>
                                        <?php elseif($order->status == 3): ?>
                                            <?php echo app('translator')->get('Received'); ?>
                                            <?php elseif($order->status == 4): ?>
                                            <?php echo app('translator')->get('Cancelled'); ?>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                </span>
                            </td>
                            <td data-label="<?php echo app('translator')->get('Action'); ?>" class="text-center">
                                <a href="<?php echo e(route('user.order', $order->order_number)); ?>" class="btn-normal-2 btn-sm"> <i class="fas fa-desktop"></i></a>

                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?php echo e($orders->appends(request()->all())->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('breadcrumb-plugins'); ?>
    <li><a href="<?php echo e(route('user.home')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a></li>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/user/orders/index.blade.php ENDPATH**/ ?>