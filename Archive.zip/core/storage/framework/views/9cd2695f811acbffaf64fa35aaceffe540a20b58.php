<li>
    <a href="<?php echo e(route('user.home')); ?>" class="<?php echo e(menuActive('user.home')); ?>"> <i class="las la-home"></i><?php echo app('translator')->get('Dashboard'); ?></a>
</li>
 
<li>
    <a href="<?php echo e(route('user.profile.setting')); ?>" class="<?php echo e(menuActive('user.profile.setting')); ?>"><i class="las la-user-alt"></i><?php echo app('translator')->get('Profile'); ?></a>
</li>

<li>
    <a href="<?php echo e(route('user.deposit.history')); ?>" class="<?php echo e(menuActive('user.deposit.history')); ?>"><i class="las la-money-bill-wave"></i><?php echo app('translator')->get('Payment Log'); ?></a>
</li>

<li>
    <a href="<?php echo e(route('user.orders', 'all')); ?>" class="<?php echo e(menuActive('user.orders')); ?>"><i class="las la-list"></i><?php echo app('translator')->get('Order Log'); ?></a>
</li>

<li>
    <a href="<?php echo e(route('user.product.review')); ?>" class="<?php echo e(menuActive('user.product.review')); ?>"><i class="la la-star"></i> <?php echo app('translator')->get('Review Products'); ?></a>
</li>

<li>
    <a href="<?php echo e(route('ticket')); ?>" class="<?php echo e(menuActive('ticket*')); ?>"><i class="la la-ticket"></i> <?php echo app('translator')->get('Support Tickets'); ?></a>
</li>

<li>
    <a href="<?php echo e(route('user.password.change')); ?>" class="<?php echo e(menuActive('user.password.change')); ?>"><i class="la la-key"></i> <?php echo app('translator')->get('Change Password'); ?></a>
</li>
<li>
    <a href="<?php echo e(route('user.twofactor')); ?>" class="<?php echo e(menuActive('user.twofactor')); ?>"><i class="la la-lock"></i> <?php echo app('translator')->get('2FA Security'); ?></a>
</li>

<li>
    <a href="<?php echo e(route('user.logout')); ?>"><i class="la la-sign-out"></i><?php echo app('translator')->get('Sign Out'); ?></a>
</li>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/user/partials/sidebar.blade.php ENDPATH**/ ?>