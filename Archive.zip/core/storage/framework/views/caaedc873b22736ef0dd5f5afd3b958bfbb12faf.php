<?php $__env->startSection('content'); ?>


<div class="dashboard-section padding-bottom padding-top">
    <div class="container">
        <div class="row">
            <div class="col-xl-3">
                <div class="dashboard-menu">
                    <?php echo $__env->make($activeTemplate.'user.partials.dp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <ul>
                        <?php echo $__env->make($activeTemplate.'user.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-xl-9">
                <div class="row justify-content-center mb-30-none">

                        
                        
                        <div class="col-sm-6 col-lg-6">
                            <div class="dashboard-item">
                                <a href="#" class="d-block">
                                    <span class="dashboard-icon">
                                        <i class="las la-wallet"></i>
                                    </span>
                                    <div class="cont">
                                         <div class="dashboard-header">
                                            <h2 class="title"><?php echo e($general->cur_sym); ?><?php echo e(number_format(Auth::user()->balance,2)); ?></h2>
                                        </div>
                                        <?php echo app('translator')->get('Wallet Balance'); ?>
                                    </div>
                                </a>
                            </div> 
                        </div>

                        <div class="col-sm-6 col-lg-6">
                            <div class="dashboard-item">
                                <a href="<?php echo e(route('user.cashback')); ?>" class="d-block">
                                    <span class="dashboard-icon">
                                        <i class="las la-wallet"></i>
                                    </span>
                                    <div class="cont">
                                         <div class="dashboard-header">
                                            <h2 class="title"><?php echo e($general->cur_sym); ?><?php echo e(number_format(Auth::user()->cashback_balance,2)); ?></h2>
                                        </div>
                                        <?php echo app('translator')->get('Cashback Wallet'); ?>
                                    </div>
                                </a>
                            </div> 
                        </div>

                    <div class="col-sm-6 col-lg-4">
                        <div class="dashboard-item">
                            <a href="<?php echo e(route('user.orders', 'all')); ?>" class="d-block">
                                <span class="dashboard-icon">
                                    <i class="las la-list-ol"></i>
                                </span>
                                <div class="cont">
                                    <?php $number = numberShortFormat($orders->count()) ?>
                                    <div class="dashboard-header">
                                        <h2 class="title"><?php echo e($number[0]); ?></h2>
                                        <h2 class="title"><?php echo e($number[1]); ?></h2>
                                    </div>
                                    <?php echo app('translator')->get('All Orders'); ?>
                                </div>
                            </a>
                        </div>
                    </div>


                    <div class="col-sm-6 col-lg-4">
                        <div class="dashboard-item">
                            <a href="<?php echo e(route('user.orders', 'pending')); ?>">
                                <span class="dashboard-icon">
                                    <i class="las la-clipboard-list"></i>
                                </span>
                                <div class="cont">
                                    <?php $number = numberShortFormat($orders->where('status', 0)->count()) ?>
                                    <div class="dashboard-header">
                                        <h2 class="title"><?php echo e($number[0]); ?></h2>
                                        <h2 class="title"><?php echo e($number[1]); ?></h2>
                                    </div>
                                    <?php echo app('translator')->get('Pending Orders'); ?>
                                </div>
                            </a>
                        </div>
                    </div>


                    <div class="col-sm-6 col-lg-4">
                        <div class="dashboard-item">
                            <a href="<?php echo e(route('user.orders', 'processing')); ?>" class="d-block">
                                <span class="dashboard-icon">
                                    <i class="las la-list-ul"></i>
                                </span>
                                <div class="cont">
                                    <?php $number = numberShortFormat($orders->where('status', 1)->count()) ?>
                                    <div class="dashboard-header">
                                        <h2 class="title"><?php echo e($number[0]); ?></h2>
                                        <h2 class="title"><?php echo e($number[1]); ?></h2>
                                    </div>
                                    <?php echo app('translator')->get('Processing Orders'); ?>
                                </div>
                            </a>
                        </div>
                    </div>

                    <div class="col-sm-6 col-lg-4">
                        <div class="dashboard-item">
                            <a href="<?php echo e(route('user.orders', 'dispatched')); ?>" class="d-block">
                                <span class="dashboard-icon">
                                    <i class="las la-th-list"></i>
                                </span>
                                <div class="cont">
                                    <?php $number = numberShortFormat($orders->where('status',2)->count()) ?>
                                    <div class="dashboard-header">
                                        <h2 class="title"><?php echo e($number[0]); ?></h2>
                                        <h2 class="title"><?php echo e($number[1]); ?></h2>
                                    </div>
                                    <?php echo app('translator')->get('Dispatched Orders'); ?>
                                </div>
                            </a>
                        </div>
                    </div>


                    <div class="col-sm-6 col-lg-4">
                        <div class="dashboard-item">
                            <a href="<?php echo e(route('user.orders', 'completed')); ?>" class="d-block">
                                <span class="dashboard-icon">
                                    <i class="las la-list-alt"></i>
                                </span>
                                <div class="cont">
                                    <?php $number = numberShortFormat($orders->where('status', 3)->count()) ?>
                                    <div class="dashboard-header">
                                        <h2 class="title"><?php echo e($number[0]); ?></h2>
                                        <h2 class="title"><?php echo e($number[1]); ?></h2>
                                    </div>
                                    <?php echo app('translator')->get('Order Completed'); ?>
                                </div>
                            </a>
                        </div>
                    </div>

                    <div class="col-sm-6 col-lg-4">
                        <div class="dashboard-item">
                            <a href="<?php echo e(route('user.orders', 'canceled')); ?>">
                                <span class="dashboard-icon">
                                    <i class="las la-times"></i>
                                </span>
                                <div class="cont">
                                    <?php $number = numberShortFormat($orders->where('status', 4)->count()) ?>
                                    <div class="dashboard-header">
                                        <h2 class="title"><?php echo e($number[0]); ?></h2>
                                        <h2 class="title"><?php echo e($number[1]); ?></h2>
                                    </div>
                                    <?php echo app('translator')->get('Canceled Orders'); ?>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/user/dashboard.blade.php ENDPATH**/ ?>