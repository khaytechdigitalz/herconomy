<?php $__env->startSection('panel'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card b-radius--10 ">
            <div class="card-body p-0">

                <div class="row justify-content-end">
                    <div class="col-xl-3 mb-3">
                        <form action="" method="GET" class="pt-3 px-3">
                            <div class="input-group has_append">
                                <input type="text" name="search" class="form-control" placeholder="Order ID" value="<?php echo e(request()->search); ?>">
                                <div class="input-group-append">
                                    <button class="btn btn--primary box--shadow1" id="search-btn" type="submit"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="table-responsive--md  table-responsive">
                    <table class="table table--light style--two">
                        <thead>
                            <tr>
                                <th class="text-left"><?php echo app('translator')->get('Order ID'); ?> | <?php echo app('translator')->get('Time'); ?></th>
                                <th class="text-left"><?php echo app('translator')->get('Customer'); ?></th>
                                <?php if(!request()->routeIs('seller.order.cod')): ?>
                                 <th class="text-left"><?php echo app('translator')->get('Payment Via'); ?></th>
                                <?php endif; ?>
                                 <th class="text-right"><?php echo app('translator')->get('Amount'); ?></th>
                                <?php if(request()->routeIs('seller.order.index')): ?>
                                    <th><?php echo app('translator')->get('Status'); ?></th>
                                <?php endif; ?>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Order ID'); ?> | <?php echo app('translator')->get('Time'); ?>" class="text-left">
                                    <span class="font-weight-bold d-block text--primary"><?php echo e(@$item->order->order_number); ?></span>
                                    <?php echo e(showDateTime($item->created_at)); ?>

                                </td>

                                <td data-label="<?php echo app('translator')->get('Customer'); ?>" class="text-left">
                                    <?php if($item->order->user): ?><?php echo e($item->order->user->username); ?><?php endif; ?>
                                </td>

                                <?php if(!request()->routeIs('seller.order.cod')): ?>
                                <td data-label="<?php echo app('translator')->get('Payment Via'); ?>" class="text-left">
                                    <?php if($item->order->payment_status==2): ?>
                                    <strong class="text-warning"><abbr data-toggle="tooltip" title="<?php echo app('translator')->get('Cash On Delivery'); ?>"><?php echo e(@$deposit->gateway->name??trans('COD')); ?></abbr></strong>
                                    <?php elseif($item->order->deposit): ?>
                                        <strong class="text-primary"><?php echo e($item->order->deposit->gateway->name); ?></strong>
                                    <?php endif; ?>
                                </td>
                                <?php endif; ?>

                                <td data-label="<?php echo app('translator')->get('Amount'); ?>" class="text-right">
                                    <b><?php echo e($general->cur_sym.(getAmount($item->total_price))); ?></b>
                                </td>
                                <?php if(request()->routeIs('seller.order.index')): ?>

                                <td data-label="<?php echo app('translator')->get('Status'); ?>" class="text-center">
                                    <?php echo $item->order->statusBadge(); ?>
                                </td>
                                <?php endif; ?>
                                <td>
                                    <a href="<?php echo e(route('seller.order.details',$item->order_id)); ?>" class="icon-btn" data-toggle="tooltip" data-title="<?php echo app('translator')->get('Order Details'); ?>"><i class="las la-desktop"></i></a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php if($orders->hasPages()): ?>
                <div class="card-footer py-4">
                    <?php echo e(paginateLinks($orders)); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>


<div class="modal fade" id="approveModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
        <form action="<?php echo e(route('seller.order.status')); ?>" method="POST" id="deliverPostForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" id="oid">
            <input type="hidden" name="action" id="action">
                <div class="modal-header">
                    <h5 class="modal-title" id="approveModalLabel"><?php echo app('translator')->get('Confirmation Alert'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p class="text-bold">

                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('No'); ?></button>
                    <button type="submit" class="btn btn--success"><?php echo app('translator')->get('Yes'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>

    'use strict';
    (function($){

        $('.approveBtn').on('click', function () {
            var modal = $('#approveModal');
            $('#oid').val($(this).data('id'));
            var action = $(this).data('action');

            $('#action').val(action);

            if(action == 1){
                $('.text-bold').text("<?php echo app('translator')->get('Are you sure to mark the order as processing?'); ?>");
            }else if(action ==2){
                $('.text-bold').text("<?php echo app('translator')->get('Are you sure to mark the order as dispatched?'); ?>");
            }else if(action ==3){
                $('.text-bold').text("<?php echo app('translator')->get('Are you sure to mark the order as delivered?'); ?>");
            }else if(action ==4){
                $('.text-bold').text("<?php echo app('translator')->get('Are you sure to cancel this order?'); ?>");
            }else{
                $('.text-bold').text("<?php echo app('translator')->get('Are you sure to retake this order?'); ?>");
            }

            modal.modal('show');
        });
    })(jQuery)

</script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('seller.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/seller/order/index.blade.php ENDPATH**/ ?>