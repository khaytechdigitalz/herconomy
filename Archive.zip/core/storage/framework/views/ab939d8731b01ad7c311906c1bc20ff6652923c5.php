<?php $__env->startSection('panel'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card b-radius--10">
            <div class="card-body p-0">
                <div class="row justify-content-end">
                    <div class="col-xl-3 mb-3 ">
                        <form action="" method="GET" class="pt-3 px-3">
                            <div class="input-group has_append">
                                <input type="text" name="search" class="form-control" placeholder="<?php echo app('translator')->get('Search'); ?>..."
                                    value="<?php echo e(request()->search ?? ''); ?>">
                                <div class="input-group-append">
                                    <button class="btn btn--primary" id="search-btn" type="submit"><i class="la la-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="table-responsive--md table-responsive">
                    <table class="table table--light style--two">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Id'); ?></th>
                                <th><?php echo app('translator')->get('Thumbnail'); ?></th>
                                <th><?php echo app('translator')->get('Name'); ?></th>
                                <th><?php echo app('translator')->get('Price'); ?></th>
                                <th><?php echo app('translator')->get('In Stock'); ?></th>
                                <th><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="Id">
                                    <?php echo e($products->firstItem() + $loop->index); ?>

                                </td>

                                <td data-label="<?php echo app('translator')->get('Thumbnail'); ?>">
                                    <div class="thumbnails d-inline-block">
                                        <div class="thumb">
                                            <a href="<?php echo e(getImage(imagePath()['product']['path'].  '/thumb_'. @$product->main_image, imagePath()['product']['size'])); ?>" class="image-popup">
                                                <img src="<?php echo e(getImage(imagePath()['product']['path']. '/thumb_'. @$product->main_image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('image'); ?>">
                                            </a>
                                        </div>
                                    </div>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Name'); ?>">

                                    <?php if($product->is_featured): ?>
                                        <span class="text--danger" data-toggle="tooltip" title="<?php echo app('translator')->get('Featured'); ?>"><i class="fas fa-2x fa-fire"></i></span>
                                    <?php endif; ?>

                                    <a href="<?php echo e(route('seller.products.edit', [$product->id, slug($product->name)])); ?>"><span class="name mb-0"  onclick="<?php echo e($product->trashed()?'return false':''); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo e(__($product->name)); ?>">
                                        <?php echo e(shortDescription($product->name, 50)); ?></span>
                                    </a>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Price'); ?>"><?php echo e($product->base_price); ?></td>
                                <td data-label="<?php echo app('translator')->get('In Stock'); ?>">
                                    <?php if($product->track_inventory): ?>
                                        <?php echo e(optional($product->stocks)->sum('quantity')); ?>

                                    <?php else: ?>
                                        <?php echo app('translator')->get('Infinite'); ?>
                                    <?php endif; ?>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php if($product->status == 1): ?>
                                       <span class="badge badge--success"><?php echo app('translator')->get('Active'); ?></span>
                                    <?php else: ?>
                                       <span class="badge badge--warning"><?php echo app('translator')->get('Pending'); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Action'); ?>">

                                    <?php if($product->status != 0): ?>
                                        <a href="<?php if($product->trashed()): ?> javascript:void(0) <?php else: ?> <?php echo e(route('seller.products.edit', [$product->id, slug($product->name)])); ?> <?php endif; ?>" class="icon-btn btn--primary <?php echo e($product->trashed()?'disabled':''); ?> mr-1" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('Edit'); ?>">
                                            <i class="la  la-edit"></i>
                                        </a>

                                        <a href="<?php if($product->trashed()): ?> javascript:void(0) <?php else: ?> <?php echo e(route('seller.products.variant.store', [$product->id])); ?> <?php endif; ?>" class="icon-btn btn--info text-white <?php echo e($product->trashed()?'disabled':''); ?> <?php echo e($product->has_variants?'':'disabled'); ?> mr-1" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('Add Variants'); ?>">
                                            <i class="la la-palette"></i>
                                        </a>

                                        <a href="<?php if($product->trashed()): ?> javascript:void(0) <?php else: ?> <?php echo e(route('seller.products.stock.create', [$product->id])); ?> <?php endif; ?>" class="icon-btn btn--warning text-white <?php echo e($product->trashed()?'disabled':''); ?> <?php echo e($product->track_inventory?'':'disabled'); ?> mr-1" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('Manage Inventory'); ?>">
                                            <i class="fas fa-database"></i>
                                        </a>
                                    <?php endif; ?>
                                    <button type="button" class="icon-btn btn--<?php echo e($product->trashed()?'success':'danger'); ?> deleteBtn" data-toggle="tooltip" data-title="<?php echo e($product->trashed()?'Restore':'Delete'); ?>" data-type="<?php echo e($product->trashed()?'restore':'delete'); ?>" data-id='<?php echo e($product->id); ?>'>
                                        <i class="la la-<?php echo e($product->trashed()?'redo':'trash'); ?>" ></i>
                                    </button>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php if($products->hasPages()): ?>
                <div class="card-footer py-4">
                    <?php echo e(paginateLinks($products)); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>



<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <form action="" method="POST" id="deleteForm">
            <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title text-capitalize" id="deleteModalLabel"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p class="text-bold">

                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('No'); ?></button>
                    <button type="submit" class="btn btn--danger"><?php echo app('translator')->get('Yes'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>
<?php $__env->startPush('breadcrumb-plugins'); ?>
    <?php if(request()->routeIs('seller.products.all')): ?>
    <a href="<?php echo e(route('seller.products.create')); ?>" title="<?php echo app('translator')->get('Shortcut'); ?>: shift+n" class="btn btn-sm btn--success box--shadow1 text--small"><i class="la la-plus"></i><?php echo app('translator')->get('Add New'); ?></a>
    <?php else: ?>
        <?php if(request()->routeIs('seller.products.trashed.search')): ?>
        <a href="<?php echo e(route('seller.products.trashed')); ?>" class="btn btn-sm btn--primary box--shadow1 text--small">
            <i class="la la-backward"></i><?php echo app('translator')->get('Go Back'); ?></a>
        <?php else: ?>
        <a href="<?php echo e(route('seller.products.all')); ?>" class="btn btn-sm btn--primary box--shadow1 text--small">
            <i class="la la-backward"></i><?php echo app('translator')->get('Go Back'); ?></a>
        <?php endif; ?>
    <?php endif; ?>

    <?php if(request()->routeIs('seller.products.all')): ?>
    <a href="<?php echo e(route('seller.products.trashed')); ?>" class="btn btn-sm btn--danger box--shadow1 text--small"><i class="la la-trash-alt"></i><?php echo app('translator')->get('Trashed'); ?></a>
    <?php endif; ?>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>

<script>

    "use strict";
    (function ($) {

        $(document).keypress(function (e) {
            var unicode = e.charCode ? e.charCode : e.keyCode;
            if(unicode == 78){
                window.location = "<?php echo e(route('seller.products.create')); ?>";
            }
        });

        $('.deleteBtn').on('click', function () {
            var modal   = $('#deleteModal');
            var id      = $(this).data('id');
            var type    = $(this).data('type');
            var form    = document.getElementById('deleteForm');

            if(type == 'delete'){
                modal.find('.modal-title').text('<?php echo e(trans("Delete Product")); ?>');
                modal.find('.modal-body').text('<?php echo e(trans("Are you sure to delete this product?")); ?>');
            }else{
                modal.find('.modal-title').text('<?php echo e(trans("Restore Product")); ?>');
                modal.find('.btn--danger').removeClass('btn--danger').addClass('btn--success');
                modal.find('.modal-body').text('<?php echo e(trans("Are you sure to restore this product?")); ?>');
            }

            form.action = '<?php echo e(route('seller.products.delete', '')); ?>'+'/'+id;
            modal.modal('show');
        });

        $('.image-popup').magnificPopup({
            type: 'image'
        });


    })(jQuery)
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('seller.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/seller/products/index.blade.php ENDPATH**/ ?>