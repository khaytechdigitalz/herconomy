<?php $__env->startSection('panel'); ?>
    <div class="row">

        <div class="col-xl-12">
            <div class="card">
                <form action="<?php echo e(route('admin.subscriber.sendEmail')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="card-body">
                        <div class="form-row">
                            <div class="form-group col-md-12">
                                <label class="font-weight-bold"><?php echo app('translator')->get('Subject'); ?></label>
                                <input type="text" class="form-control" placeholder="<?php echo app('translator')->get('Subject'); ?>" name="subject" value="<?php echo e(old('subject')); ?>" />
                            </div>
                            <div class="form-group col-md-12">
                                <label class="font-weight-bold"><?php echo app('translator')->get('Body'); ?></label>
                                <textarea name="body" rows="10" class="form-control nicEdit"><?php echo e(old('body')); ?></textarea>
                            </div>

                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-block btn--primary "><i class="fa fa-fw fa-paper-plane"></i><?php echo app('translator')->get('Send Email'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <a href="<?php echo e(route('admin.subscriber.index')); ?>" class="btn btn-sm btn--primary box--shadow1 text--small"><i class="fa fa-fw fa-backward"></i> <?php echo app('translator')->get('Go Back'); ?></a>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/admin/subscriber/send_email.blade.php ENDPATH**/ ?>