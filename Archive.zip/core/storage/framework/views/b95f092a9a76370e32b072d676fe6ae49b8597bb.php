<?php
    $footer    = getContent('footer.content', true);
    if($footer)
    $footer    = $footer->data_values;

    $categories = \App\Models\Category::where('is_top', 1)->inRandomOrder()->take(6)->get();
    $topBrands =  \App\Models\Brand::top()->inRandomOrder()->take(6)->get();

?>

<footer class="section-bg" style="background-color: #F2BA00">
    <div class="container">
        <div class="padding-bottom padding-top">
            <div class="row gy-5">
                <div class="col-lg-6">
                    <div class="row justify-content-between g-4">
                        <div class="col-md-5">
                            <div class="footer__widget footer__widget-about">
                                <div class="logo">
                                    <a href="<?php echo e(route('home')); ?>">
                                        <img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo.png')); ?>" alt="logo">
                                    </a>
                                </div>
                                <p class="addr">
                                    <?php echo app('translator')->get(@$footer->footer_note); ?>
                                </p>
                                <?php
                                    $socials    = getContent('social_media_links.element');
                                ?>

                                <ul class="social__icons">
                                    <?php if($socials->count() >0): ?>
                                        <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a href="<?php echo e($item->data_values->url); ?>" target="blank">
                                                <?php
                                                    echo $item->data_values->social_icon
                                                ?>
                                            </a>
                                        </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>

                        <div class="col-md-7 col-xl-6">
                            <div class="footer__widget widget__info">
                                <h5 class="widget--title"><?php echo app('translator')->get('Contact Us'); ?></h5>
                                <div>
                                    <div class="contact__info">
                                        <div class="icon">
                                            <i style= color:#000000;" class="las la-headset"></i>
                                        </div>
                                        <div class="content">
                                            <h6 class="contact__info-title">
                                                <a href="Tel:<?php echo e(@$footer->cell_number); ?>"><?php echo e(@$footer->cell_number); ?></a>
                                            </h6>
                                            <span class="info"><?php echo e(@$footer->time); ?></span>
                                        </div>
                                    </div>
                                    <div class="contact__info style-two">
                                        <div class="icon">
                                            <i style= color:#000000;" class="las la-envelope-open"></i>
                                        </div>
                                        <div class="content">
                                            <h6 class="contact__info-title">
                                                <a href="mailto:<?php echo e(@$footer->email); ?>"><?php echo e(@$footer->email); ?></a>
                                            </h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="row g-4 pl-xl-5">
                        <div class="col-lg-4 col-6">
                            <div class="footer__widget">
                                <h5 class="widget--title"><?php echo app('translator')->get('Accounts'); ?></h5>
                                <ul class="footer__links">
                                    <li>
                                        <a href="<?php echo e(route('user.login')); ?>"><?php echo app('translator')->get('Login'); ?></a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('user.register')); ?>"><?php echo app('translator')->get('Register as Customer'); ?></a>
                                    </li> 
                                    <li>
                                        <a href="<?php echo e(route('seller.register')); ?>"><?php echo app('translator')->get('Register as Merchant'); ?></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-4 col-6">
                            <div class="footer__widget">
                                <h5 class="widget--title"><?php echo app('translator')->get('Top Brands'); ?></h5>
                                <ul class="footer__links">
                                    <?php $__currentLoopData = $topBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(route('products.brand',[$brand->id,slug($brand->name)])); ?>"><?php echo e($brand->name); ?></a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </ul>
                            </div>
                        </div>
                        <?php
                            $pages  = \App\Models\Frontend::where('data_keys', 'pages.element')->get();
                        ?>
                        <div class="col-lg-4 col-md-6">
                            <div class="footer__widget">
                                <h5 class="widget--title"><?php echo app('translator')->get('Useful Links'); ?></h5>
                                <ul class="footer__links">
                                    <?php if($pages->count() > 0): ?>
                                        <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(route('page.details', [$item->id, slug($item->data_values->pageTitle)])); ?>"><?php echo __($item->data_values->pageTitle) ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="footer-bottom body-bg text-center" style='background-color: #F2BA00'>
        <div class="container">
            <div class="d-flex flex-wrap justify-content-around justify-content-lg-between align-items-center">
                <div class="left py-2">
                    <?php echo e(__(@$footer->copyright_text)); ?>

                </div>
                <div class="right py-2">
                    <?php if(isset($footer->payment_methods)): ?>
                    <img src="<?php echo e(getImage('assets/images/frontend/footer/'.@$footer->payment_methods, "250x30")); ?>" alt="<?php echo app('translator')->get('footer'); ?>">
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</footer>


<div class="modal fade" id="quickView">
    <div class="modal-dialog modal-dialog-centered modal-xl" role="document">
        <div class="modal-content py-4">
            <button type="button" class="close modal-close-btn" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
            <div class="modal-body">
                <div class="ajax-loader-wrapper d-flex align-items-center justify-content-center">
                    <div class="spinner-border" role="status">
                      <span class="sr-only"><?php echo app('translator')->get('Loading'); ?>...</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/partials/footer.blade.php ENDPATH**/ ?>