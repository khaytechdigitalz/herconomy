<?php $__env->startSection('content'); ?>
<?php
    $login_content        = getContent('login_page.content', true);
?>

<section class="account-section padding-bottom padding-top">
    <div class="contact-thumb d-none d-lg-block">
        <img src="<?php echo e(getImage('assets/images/frontend/login_page/'. @$login_content->data_values->image, '600x840')); ?>" alt="<?php echo app('translator')->get('login-bg'); ?>">
    </div>

    <div class="container">
        <div class="row">
            <div class="col-lg-7">
                <div class="section-header left-style">
                    <h3 class="title"><?php echo e(__(@$login_content->data_values->title)); ?></h3>
                    <p><?php echo e(__(@$login_content->data_values->description)); ?></p>
                </div>


<div class="container">
    
    <ul class="nav nav-tabs">
      <li><a class="cmn--btn m-0 text-white" data-toggle="tab" href="#menu1">Login With Herconomy </a></li>
      
    </ul>
  
    <div class="tab-content">
      
      <div id="menu1" class="tab-pane fade">
        <h3></h3>
        <p>Please enter your Herconomy Email & Password Below</p>
        <form method="POST" action="<?php echo e(route('api.loginHeconomy')); ?>" class="contact-form mb-30-none">
            <?php echo csrf_field(); ?>

            <div class="contact-group">
                <label for="username"><?php echo app('translator')->get('Email'); ?></label>
                <input id="username" type="email" name="username" placeholder="<?php echo app('translator')->get('Enter Your Username'); ?>" value="<?php echo e(old('username')); ?>">
            </div>

            <div class="contact-group">
                <label for="password"><?php echo app('translator')->get('Password'); ?></label>
                <input id="password" type="password" name="password" placeholder="<?php echo app('translator')->get('Enter Your Password'); ?>" required autocomplete="current-password">
            </div>
 
                <div class="contact-group">
                    <div class="d-flex flex-wrap align-items-center w-100 justify-content-end ">
                            <button type="submit" class="cmn--btn m-0 text-white"><?php echo app('translator')->get('Login'); ?></button>
                    </div>
                </div>
        </form>
      </div>
      
      <div id="menu2" class="tab-pane fade active">
        <h3></h3>
        <form method="POST" action="<?php echo e(route('user.login')); ?>" class="contact-form mb-30-none">
            <?php echo csrf_field(); ?>

            <div class="contact-group">
                <label for="username"><?php echo app('translator')->get('Username'); ?></label>
                <input id="username" type="text" name="username" placeholder="<?php echo app('translator')->get('Enter Your Username'); ?>" value="<?php echo e(old('username')); ?>">
            </div>

            <div class="contact-group">
                <label for="password"><?php echo app('translator')->get('Password'); ?></label>
                <input id="password" type="password" name="password" placeholder="<?php echo app('translator')->get('Enter Your Password'); ?>" required autocomplete="current-password">
            </div>

                <?php echo $__env->make($activeTemplate.'partials.custom_captcha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <div class="contact-group">
                    <div class="d-flex flex-wrap align-items-center w-100 justify-content-end ">
                            <button type="submit" id="recaptcha" class="cmn--btn m-0 text-white"><?php echo app('translator')->get('Login'); ?></button>
                    </div>
                </div>
                <div class="contact-group">
                    <div class="w-100">
                        <div class="d-flex flex-wrap align-items-center justify-content-between">
                            <?php if(Route::has('user.register')): ?>
                            <span class="acc"><?php echo app('translator')->get('Don\'t have an account'); ?>? <a href="<?php echo e(route('user.register')); ?>"><?php echo app('translator')->get('Create An Account'); ?></a></span>
                            <?php endif; ?>
                            <?php if(Route::has('user.password.request')): ?>
                            <span class="account-alt">
                                <a href="<?php echo e(route('user.password.request')); ?>">
                                    <?php echo e(__('Forgot Password')); ?>?
                                </a>
                            </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
        </form>
      </div> 
      
    </div>
  </div>

  
                
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/user/auth/login.blade.php ENDPATH**/ ?>