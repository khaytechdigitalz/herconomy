

<?php if($subcategory->allSubcategories): ?>
<?php $prefix .='|--'  ?>
    <?php $__currentLoopData = $subcategory->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('seller.partials.subcategories', ['subcategory' => $childCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <option value="<?php echo e($subcategory->id); ?>" > <?php echo e($prefix); ?> <?php echo app('translator')->get($childCategory->name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/seller/partials/subcategories.blade.php ENDPATH**/ ?>