<?php $__env->startSection('panel'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card b-radius--10 ">
            <div class="card-body p-0">
                <div class="table-responsive--md  table-responsive">
                    <table class="table table--light style--two">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('S.N.'); ?></th>
                                <th><?php echo app('translator')->get('Name'); ?></th>
                                <th><?php echo app('translator')->get('Charge'); ?></th>
                                <th class="text-center"><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            <?php $__empty_1 = true; $__currentLoopData = $shipping_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s_method): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('S.N.'); ?>"><?php echo e(($shipping_methods->currentPage()-1) * $shipping_methods->perPage() + $loop->iteration); ?>

                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Name'); ?>"><?php echo e(__($s_method->name)); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Charge'); ?>"><?php echo e(__($s_method->charge)); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Status'); ?>">

                                        <label class="switch">
                                            <input type="checkbox" class="status-change" name="top" <?php echo e($s_method->status==1?'checked':''); ?> data-id=<?php echo e($s_method->id); ?>>
                                            <span class="slider round"></span>
                                        </label>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                        <span data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('Edit'); ?>">
                                            <a href="<?php echo e(route('admin.shipping.methods.edit', $s_method->id)); ?>"
                                                class="icon-btn btn--primary btn-rounded">
                                                <i class="la la-pencil"></i>
                                            </a>
                                        </span>
                                        <span data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('Delete'); ?>">
                                            <button type="button" class="icon-btn btn--danger ml-1" data-toggle="modal"
                                                data-target="#deleteModal" data-id='<?php echo e($s_method->id); ?>'>
                                                <i class="la la-trash"></i>
                                            </button>
                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>


                <?php if($shipping_methods->hasPages()): ?>
                    <div class="card-footer py-4">
                        <?php echo e(paginateLinks($shipping_methods)); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>



<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
        <form action="" method="POST" id="deletePostForm">
            <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title text-capitalize" id="deleteModalLabel"><?php echo app('translator')->get('Confirmation Alert'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <?php echo app('translator')->get('Are you sure to delete this method?'); ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="icon-btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('No'); ?></button>
                    <button type="submit" class="icon-btn btn--danger"><?php echo app('translator')->get('Yes'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <a href="<?php echo e(route('admin.shipping.methods.create')); ?>" class="btn btn-sm btn--primary box--shadow1 text-white text--small">
        <i class="la la-plus"></i> <?php echo app('translator')->get('Add New'); ?>
    </a>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>

    <script>
        "use strict";
        (function($){
            $('#deleteModal').on('show.bs.modal', function (e) {
                var id = $(e.relatedTarget).data('id');
                var form = document.getElementById('deletePostForm');
                form.action =
                    '<?php echo e(route('admin.shipping.methods.delete', '')); ?>' +
                    '/' + id;
            });

            $('.status-change').on('change',function () {
                var id = $(this).data('id');
                var mode = $(this).prop('checked');

                var data = {
                    'id': id
                };

                $.ajax({
                    url: `<?php echo e(route('admin.shipping.methods.status-change')); ?>`,
                    method: "get",
                    data: data,
                    success: function (result) {
                        notify('success', result.message);
                    }
                });
            });
        })(jQuery)

    </script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/admin/shipping_method/index.blade.php ENDPATH**/ ?>