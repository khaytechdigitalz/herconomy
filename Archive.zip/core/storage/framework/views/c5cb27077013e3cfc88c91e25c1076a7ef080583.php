    <!-- ===========Cart=========== -->
    <div class="cart-sidebar-area" id="cart-sidebar-area">
        <?php echo $__env->make($activeTemplate.'partials.side_modal_logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="bottom-content">
            <div class="cart-products cart--products">

            </div>
        </div>
    </div>
    <!-- ===========Cart End=========== -->

    <!-- ===========Wishlist=========== -->
    <div class="cart-sidebar-area" id="wish-sidebar-area">
        <?php echo $__env->make($activeTemplate.'partials.side_modal_logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="bottom-content">
            <div class="cart-products wish-products">

            </div>
        </div>
    </div>
    <!-- ===========Wishlist End=========== -->


    <!-- Header Section Ends Here -->
    <div <?php echo e(gradient()); ?> class="dashboard-menu before-login-menu d-flex flex-wrap justify-content-center flex-column" id="account-sidebar-area">
        <span class="side-sidebar-close-btn"><i class="las la-times"></i></span>
         

        <?php if(auth()->guard()->check()): ?>
        <?php echo $__env->make($activeTemplate.'user.partials.dp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <ul class="cl-white" >
            <?php echo $__env->make($activeTemplate.'user.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </ul>
        <?php endif; ?>

    </div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/partials/side_modal.blade.php ENDPATH**/ ?>