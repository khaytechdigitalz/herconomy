<?php echo  loadTawkto() ?>
<?php echo  loadAnalytics() ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/partials/plugins.blade.php ENDPATH**/ ?>