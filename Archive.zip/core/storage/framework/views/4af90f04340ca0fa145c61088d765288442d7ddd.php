<?php $__env->startSection('panel'); ?>

    <div class="row">

        <div class="col-lg-12">
            <div class="card b-radius--10 ">
                <div class="card-body p-0">
                    <div class="table-responsive--sm table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Name'); ?></th>
                                <th><?php echo app('translator')->get('Min Savings Balance'); ?></th>
                                <th><?php echo app('translator')->get('Max Savings Balance'); ?></th>
                                <th><?php echo app('translator')->get('Cashback'); ?></th>
                                <th><?php echo app('translator')->get('Updated At'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $tiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('Name'); ?>"><?php echo e($data->name); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Min Savings Balance'); ?>"><?php echo e($general->cur_sym); ?><?php echo e(number_format($data->min,2)); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Max Savings Balance'); ?>"><?php echo e($general->cur_sym); ?><?php echo e(number_format($data->max,2)); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Cashback '); ?>"><?php echo e(number_format($data->discount,2)); ?>%</td>
                                    <td data-label="<?php echo app('translator')->get('Updated At'); ?>"><?php echo e(showDateTime($data->created_at)); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                        <a href="javascript:void(0)"
                                           data-id="<?php echo e($data->id); ?>"
                                           data-name="<?php echo e($data->name); ?>"
                                           data-min="<?php echo e($data->min); ?>"
                                           data-max="<?php echo e($data->max); ?>"
                                           class="icon-btn btn--primary ml-1 editModalBtn" data-toggle="tooltip"
                                           data-original-title="<?php echo app('translator')->get('Edit'); ?>">
                                            <i class="las la-edit"></i>
                                        </a>
                                        <a href="javascript:void(0)"
                                        data-id="<?php echo e($data->id); ?>"
                                        class="icon-btn btn--danger ml-1 removeModalBtn" data-toggle="tooltip"
                                        data-original-title="<?php echo app('translator')->get('Remove'); ?>">
                                         <i class="las la-trash"></i>
                                     </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%">No Data Found</td>
                                </tr>
                            <?php endif; ?>

                            </tbody>
                        </table><!-- table end -->
                    </div>
                </div> 
            </div><!-- card end -->
        </div>


    </div>



    
    <div id="createModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Create New Tier'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group mb-2">
                        <label>Name</label>
                        <input type="text" name="name" class="form-control">
                        </div>
                        <div class="form-group mb-2">
                        <label>Minimum Savings Balance</label>
                        <input type="number" name="min" class="form-control">
                        </div>
                        <div class="form-group mb-2">
                        <label>Maximum Savings Balance</label>
                        <input type="number" name="max" class="form-control">
                        </div>
                        <div class="form-group mb-2">
                        <label>Cashback <b>(%)</b></label>
                        <input type="text" name="discount" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn--success"><?php echo app('translator')->get('Create'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    
    <div id="editModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Edit New Tier'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('admin.setting.tier.update')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input name="id" hidden>
                    <div class="modal-body">
                        <div class="form-group mb-2">
                        <label>Name</label>
                        <input type="text" name="name" class="form-control">
                        </div>
                        <div class="form-group mb-2">
                        <label>Minimum Savings Balance</label>
                        <input type="number" name="min" class="form-control">
                        </div>
                        <div class="form-group mb-2">
                        <label>Maximum Savings Balance</label>
                        <input type="number" name="max" class="form-control">
                        </div>

                        <div class="form-group mb-2">
                            <label>Cashback</label>
                            <input type="text" name="discount" class="form-control">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn--success"><?php echo app('translator')->get('Update'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>


    
    <div id="removeModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Are you sure to remove?'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form action="<?php echo e(route('admin.setting.tier.remove')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <input type="hidden" name="id">
                        <p><span class="font-weight-bold subscriber-email"></span> <?php echo app('translator')->get('will be removed.'); ?></p>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                        <button type="submit" class="btn btn--danger"><?php echo app('translator')->get('Remove'); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <a href="#" class="btn btn-sm btn--primary box--shadow1 text--small createModalBtn" ><i class="fa fa-fw fa-paper-plane"></i><?php echo app('translator')->get('Create New Tier'); ?></a>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        (function($){
            "use strict";
            $('.editModalBtn').on('click', function() {
                $('#editModal').find('input[name=id]').val($(this).data('id'));
                $('#editModal').find('input[name=name]').val($(this).data('name'));
                $('#editModal').find('input[name=min]').val($(this).data('min'));
                $('#editModal').find('input[name=max]').val($(this).data('max'));
                $('#editModal').find('input[name=discount]').val($(this).data('discount'));
                $('#editModal').modal('show');
            });

            $('.removeModalBtn').on('click', function() {
                $('#removeModal').find('input[name=id]').val($(this).data('id'));
                $('#removeModal').modal('show');
            });
            $('.createModalBtn').on('click', function() { 
                $('#createModal').modal('show');
            });

        })(jQuery);

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/admin/setting/tiers.blade.php ENDPATH**/ ?>