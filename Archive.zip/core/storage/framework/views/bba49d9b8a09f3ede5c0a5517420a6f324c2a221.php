<div class="user">
    <span class="side-sidebar-close-btn"><i class="las la-times"></i></span>

    <div class="thumb">
        <a href="<?php echo e(route('user.profile.setting')); ?>">
            <img width="50" src="<?php echo e(getAvatar(imagePath()['profile']['user']['path'].'/'.auth()->user()->image)); ?>" alt="<?php echo app('translator')->get('user'); ?>">
        </a>
    </div>
    <div class="content">
        <h6 class="title"><a class="text--base" href="<?php echo e(auth()->user()->fullname); ?>" class="cl-white"><?php echo e(auth()->user()->fullname); ?></a></h6>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/user/partials/dp.blade.php ENDPATH**/ ?>