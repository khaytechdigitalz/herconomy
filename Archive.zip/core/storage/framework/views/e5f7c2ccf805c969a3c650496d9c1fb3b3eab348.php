<?php $__env->startSection('panel'); ?>

<div class="row">

    <div class="col-xl-12 col-md-12 mb-30">
        <div <?php echo e(gradient()); ?> class="widget bb--3 border--success b-radius--10 bg--white p-4 box--shadow2 has--link">
            <div class="widget__icon b-radius--rounded bg--dark"><i class="las la-gift"></i></div>
            <div class="widget__content">
                <p class="text-uppercase text-white"><?php echo app('translator')->get('Total Cashback'); ?></p>
                <h1 class="text--white font-weight-bold">
                    <?php echo e($general->cur_sym.showAmount($sum)); ?>

                </h1> 
            </div>
        </div><!-- widget end -->
    </div>

    <div class="col-lg-12">
        
        <div class="card b-radius--10">
            <div class="card-body p-0">
                 
                <div class="table-responsive--md table-responsive">
                    <table class="table table--light style--two">
                        <thead>
                            <tr>
                                <th class="text-white"><?php echo app('translator')->get('Transaction ID'); ?></th>
                                <th class="text-white"><?php echo app('translator')->get('Customer'); ?></th>
                                <th class="text-white"><?php echo app('translator')->get('Products'); ?></th>
                                <th class="text-white"><?php echo app('translator')->get('Amount'); ?></th>
                                <th class="text-white"><?php echo app('translator')->get('Cashback'); ?></th>
                                <th class="text-white"><?php echo app('translator')->get('Time'); ?></th> 
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                             <?php $__empty_1 = true; $__currentLoopData = $cashbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                             
                            <?php
                            $return = 0;
                            $amount = 0;
                            ?>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $return += $cashback->cashback; ?>
                            <?php $amount += $cashback->amount; ?>
                            <?php $user = App\Models\User::whereId($cashback->user_id)->first();  ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td data-label="#<?php echo app('translator')->get('Order Trx'); ?>"><?php echo e($cashback->order_ref); ?></td>
                                    <td data-label="#<?php echo app('translator')->get('Customers'); ?>"><?php echo e($user->username ?? 'N/A'); ?></td>
                                     <td data-label="<?php echo app('translator')->get('Products'); ?>"><?php echo e(count($data)); ?> Products</td>
                                    <td data-label="<?php echo app('translator')->get('Amount'); ?>"> 
                                        <strong><?php echo e($general->cur_sym); ?><?php echo e(number_format($amount,2)); ?></strong>
                                    </td>
                                    <td>
                                        <a class="text-success"><?php echo e($general->cur_sym); ?><?php echo e(number_format($return,2)); ?></a>
                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Time'); ?>">
                                        <?php echo e(showDateTime($cashback->created_at, 'd M, Y')); ?>

                                    </td>
                                    <td><button class="btn btn--primary" href="#" data-toggle="modal" data-target="#cashbackModal<?php echo e($k); ?>">Details</button></td>

                                    
                                </tr>


                                <!-- Modal -->
                                <div class="modal fade" id="cashbackModal<?php echo e($k); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog" role="document">
                                    <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title" id="exampleModalLabel">Cashback Details</h5>
                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                        </button>
                                    </div>
                                    <div class="modal-body">
                                        <ul class="list-group">
                                            <?php 
                                            $return = 0;
                                            ?>
                                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cashback): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php $return += $cashback->cashback; ?>
                                            <?php $amount += $cashback->amount; ?>
                                            <?php $user = App\Models\User::whereId($cashback->user_id)->first();  ?>
                                            <?php $product = App\Models\Product::whereId($cashback->product_id)->first();  ?>  

                                            <li class="list-group-item"><?php echo e($product->name ?? "N/A"); ?> : <?php echo e($general->cur_sym); ?><?php echo e(number_format($cashback->cashback,2)); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                                            <li class="list-group-item"><b>TOTAL CASHBACK:  <?php echo e($general->cur_sym); ?><?php echo e(number_format($return,2)); ?></b>
                                          </ul>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="button" class="btn btn--primary" data-dismiss="modal">Close</button>
                                    </div>
                                    </div>
                                </div>
                                </div>
  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="100%">No cashback record at the moment</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                   
                </div>
            </div>
         
        </div>
    </div>
</div>

 
<?php $__env->stopSection(); ?>


<?php $__env->startPush('script'); ?>
    <script>
        (function ($) {
            "use strict";
            $('.moreViewBtn').on('click', function() {
                var modal = $('#approveModal');
                modal.find('.withdraw-amount').text($(this).data('amount'));
                modal.find('.withdraw-charge').text($(this).data('charge'));
                modal.find('.withdraw-after_charge').text($(this).data('after_charge'));
                modal.find('.withdraw-rate').text($(this).data('rate'));
                modal.find('.withdraw-payable').text($(this).data('payable'));

                if($(this).data('method_code') >999){

                    var list = [];
                    var details =  Object.entries($(this).data('info'));

                    var ImgPath = "<?php echo e(asset(imagePath()['verify']['deposit']['path'])); ?>/";
                    var singleInfo = '';

                    for (var i = 0; i < details.length; i++) {
                        if (details[i][1].type == 'file') {
                            singleInfo += `<li class="list-group-item">
                                                <span class="font-weight-bold "> ${details[i][0].replaceAll('_', " ")} </span> : <img src="${ImgPath}/${details[i][1].field_name}" alt="<?php echo app('translator')->get('Image'); ?>" class="w-100">
                                            </li>`;
                        }else{
                            singleInfo += `<li class="list-group-item">
                                                <span class="font-weight-bold "> ${details[i][0].replaceAll('_', " ")} </span> : <span class="font-weight-bold ml-3">${details[i][1].field_name}</span>
                                            </li>`;
                        }
                    }

                    if (singleInfo)
                    {
                        modal.find('.withdraw-detail').html(`<br><strong class="my-3"><?php echo app('translator')->get('Payment Information'); ?></strong>  ${singleInfo}`);
                    }else{
                        modal.find('.withdraw-detail').html(`${singleInfo}`);
                    }
                }


                modal.modal('show');
            });

            $('.detailBtn').on('click', function() {
                var modal = $('#detailModal');
                var feedback = $(this).data('admin_feedback');
                modal.find('.withdraw-detail').html(`<p> ${feedback} </p>`);
                modal.modal('show');
            });
        })(jQuery);
    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('seller.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/seller/cashback.blade.php ENDPATH**/ ?>