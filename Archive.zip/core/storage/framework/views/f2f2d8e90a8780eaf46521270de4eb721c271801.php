<?php $__env->startSection('content'); ?>
    <!-- Checkout Section Starts Here -->
    <div class="checkout-section padding-bottom padding-top">
        <div class="container">
            <div class="checkout-area section-bg">
                <div class="row flex-wrap-reverse">
                    <div class="col-md-6 col-lg-7 col-xl-8">
                        <div class="checkout-wrapper">
                            <h4 class="title text-center"><?php echo app('translator')->get('Shipping Address'); ?></h4>
                            <ul class="nav-tabs nav justify-content-center">
                                <li>
                                    <a href="#self" data-toggle="tab" class="active"><?php echo app('translator')->get('For Yourself'); ?></a>
                                </li>
                                <li>
                                    <a href="#guest" data-toggle="tab"><?php echo app('translator')->get('Order As Gift'); ?></a>
                                </li>
                            </ul>
                            <div class="tab-content">
                                <div class="tab-pane show fade active" id="self">
                                    <form action="<?php echo e(route('user.checkout-to-payment', 1)); ?>" method="post" class="billing-form mb--20">
                                        <?php echo csrf_field(); ?>

                                        <div class="row">
                                            <div class="col-lg-12 mb-20">
                                                <label for="shipping-method" class="billing-label"><?php echo app('translator')->get('Shipping Method'); ?></label>
                                                <div class="billing-select">
                                                    <select name="shipping_method" class="select-bar false px-2" required>
                                                        <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                                        <?php $__currentLoopData = $shipping_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option data-shipping="<?php echo e($sm->description); ?>" data-charge="<?php echo e($sm->charge); ?>" value="<?php echo e($sm->id); ?>"><?php echo e($sm->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-12 mb-20">
                                                <label  class="billing-label"><?php echo app('translator')->get('Payment Method'); ?></label>
                                                <div class="billing-select">
                                                    <select name="payment" class="select-bar false px-2" required>
                                                        <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                                        <option value="1"><?php echo app('translator')->get('Direct Payment'); ?></option>
                                                        <?php if($general->cod): ?>
                                                         <option value="2"><?php echo app('translator')->get('Cash On Delivery'); ?></option>
                                                        <?php endif; ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-lg-6 mb-20">
                                                <label for="fname" class="billing-label"><?php echo app('translator')->get('First Name'); ?></label>
                                                <input class="form-control custom--style" id="fname" type="text" name="firstname" value="<?php echo e(auth()->user()->firstname?? old('firstname')); ?>" required>
                                            </div>
                                            <div class="col-lg-6 mb-20">
                                                <label for="lname" class="billing-label"><?php echo app('translator')->get('Last Name'); ?></label>
                                                <input class="form-control custom--style" id="lname" name="lastname" type="text" value="<?php echo e(auth()->user()->lastname?? old('lastname')); ?>" required>
                                            </div>

                                            <div class="col-lg-6 mb-20">
                                                <label for="country" class="billing-label"><?php echo app('translator')->get('Country'); ?></label>
                                                <div class="billing-select">
                                                    <select name="country" id="country" class="select-bar" required>
                                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option data-mobile_code="<?php echo e($country->dial_code); ?>" value="<?php echo e($country->country); ?>" data-code="<?php echo e($key); ?>"><?php echo e(__($country->country)); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>


                                            <div class="col-md-6">
                                                <div class="form-group">
                                                    <label for="mobile" class="billing-label"><?php echo app('translator')->get('Mobile'); ?></label>

                                                    <input type="text" name="mobile" id="mobile" value="<?php echo e(old('mobile')??auth()->user()->mobile); ?>" class="form-control custom--style" placeholder="<?php echo app('translator')->get('Your Phone Number'); ?>">
                                                </div>
                                            </div>

                                            <div class="col-lg-6 mb-20">
                                                <label for="email" class="billing-label"><?php echo app('translator')->get('Email'); ?></label>
                                                <input class="form-control custom--style" id="email" name="email" type="text" value="<?php echo e(auth()->user()->email?? old('email')); ?>" required>
                                            </div>


                                            <div class="col-md-6 mb-20">
                                                <label for="city" class="billing-label"><?php echo app('translator')->get('City'); ?></label>
                                                <input class="form-control custom--style" id="city" name="city" type="text" value="<?php echo e(auth()->user()->address->city?? old('city')); ?>" required>
                                            </div>

                                            <div class="col-md-6 mb-20">
                                                <label for="state" class="billing-label"><?php echo app('translator')->get('State'); ?></label>
                                                <input class="form-control custom--style" id="state" name="state" type="text" value="<?php echo e(auth()->user()->address->state?? old('state')); ?>" required>
                                            </div>

                                            <div class="col-md-6 mb-20">
                                                <label for="zip" class="billing-label"><?php echo app('translator')->get('Zip/Post Code'); ?></label>
                                                <input class="form-control custom--style" id="zip" name="zip" type="text" value="<?php echo e(auth()->user()->address->zip?? old('zip')); ?>" required>
                                            </div>

                                            <div class="col-md-12 mb-20">
                                                <label for="address" class="billing-label"><?php echo app('translator')->get('Address'); ?></label>
                                                <textarea class="form-control custom--style" name="address" id="address" required><?php echo e(auth()->user()->address->address??old('address')); ?></textarea>
                                            </div>
                                        </div>


                                        <div class="row ">

                                            <div class="col-lg-12 mb-20">
                                                <button type="submit" class="bill-button w-100"><?php echo app('translator')->get('Confirm Order'); ?></button>
                                            </div>
                                        </div>

                                    </form>
                                </div>
                                <div class="tab-pane fade" id="guest">
                                    <form action="<?php echo e(route('user.checkout-to-payment', 2)); ?>" method="post" class="guest-form mb--20">
                                        <?php echo csrf_field(); ?>

                                        <div class="row">
                                            <div class="col-lg-12 mb-20">
                                                <label for="shipping-method-2" class="billing-label"><?php echo app('translator')->get('Shipping Method'); ?></label>
                                                <div class="billing-select">
                                                    <select name="shipping_method" id="shipping-method-2" required>
                                                        <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                                        <?php $__currentLoopData = $shipping_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option data-shipping="<?php echo e($sm->description); ?>" data-charge="<?php echo e($sm->charge); ?>" value="<?php echo e($sm->id); ?>"><?php echo e($sm->name); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-12 mb-20">
                                                <label  class="billing-label"><?php echo app('translator')->get('Payment Method'); ?></label>
                                                <div class="billing-select">
                                                    <select name="payment" required>
                                                        <option value=""><?php echo app('translator')->get('Select One'); ?></option>
                                                        <option value="1"><?php echo app('translator')->get('Direct Payment'); ?></option>
                                                        <?php if($general->cod): ?>
                                                         <option value="2"><?php echo app('translator')->get('Cash On Delivery'); ?></option>
                                                        <?php endif; ?>
                                                    </select>
                                                </div>
                                            </div>
                                            <div class="col-lg-6 mb-20">
                                                <label for="firstname" class="billing-label"><?php echo app('translator')->get('First Name'); ?></label>
                                                <input class="form-control custom--style" id="firstname" type="text" name="firstname" value="<?php echo e(old('firstname')); ?>" required>
                                            </div>
                                            <div class="col-lg-6 mb-20">
                                                <label for="lastname" class="billing-label"><?php echo app('translator')->get('Last Name'); ?></label>
                                                <input class="form-control custom--style" id="lastname" name="lastname" type="text" value="<?php echo e(old('lastname')); ?>" required>
                                            </div>


                                            <div class="col-lg-6 mb-20">
                                                <label for="mobile" class="billing-label"><?php echo app('translator')->get('Mobile'); ?></label>
                                                <input class="form-control custom--style" id="mobile" name="mobile" type="text" value="<?php echo e(old('mobile')); ?>" required>
                                            </div>

                                            <div class="col-lg-6 mb-20">
                                                <label for="e-mail" class="billing-label"><?php echo app('translator')->get('Email'); ?></label>
                                                <input class="form-control custom--style" id="e-mail" name="email" type="text" required>
                                            </div>

                                            <div class="col-lg-6 mb-20">
                                                <label for="country-2" class="billing-label"><?php echo app('translator')->get('Country'); ?></label>
                                                <div class="billing-select">
                                                    <select name="country" id="country-2" class="select-bar" required>
                                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option data-mobile_code="<?php echo e($country->dial_code); ?>" value="<?php echo e($country->country); ?>" data-code="<?php echo e($key); ?>"><?php echo e(__($country->country)); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                            </div>

                                            <div class="col-md-6 mb-20">
                                                <label for="city-2" class="billing-label"><?php echo app('translator')->get('City'); ?></label>
                                                <input class="form-control custom--style" id="city-2" name="city" type="text" value="<?php echo e(old('city')); ?>" required>
                                            </div>

                                            <div class="col-md-6 mb-20">
                                                <label for="state-2" class="billing-label"><?php echo app('translator')->get('State'); ?></label>
                                                <input class="form-control custom--style" id="state-2" name="state" type="text" value="<?php echo e(old('state')); ?>" required>
                                            </div>

                                            <div class="col-md-6 mb-20">
                                                <label for="zip-2" class="billing-label"><?php echo app('translator')->get('Zip/Post Code'); ?></label>
                                                <input class="form-control custom--style" id="zip-2" name="zip" type="text" value="<?php echo e(old('zip')); ?>" required>
                                            </div>

                                            <div class="col-md-12 mb-20">
                                                <label for="address-2" class="billing-label"><?php echo app('translator')->get('Address'); ?></label>
                                                <textarea class="form-control custom--style" id="address-2" name="address" required><?php echo e(old('address')); ?></textarea>
                                            </div>
                                        </div>

                                        <div class="row">

                                            <div class="col-lg-12 mb-20">
                                                <button type="submit" class="bill-button w-100"><?php echo app('translator')->get('Confirm Order'); ?></button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-5 col-xl-4">
                        <div class="payment-details">
                            <h4 class="title text-center"><?php echo app('translator')->get('Payment Details'); ?></h4>
                            <ul>
                                <li>
                                    <span class="subtitle"><?php echo app('translator')->get('Subtotal'); ?></span>
                                    <span class="text-success" id="cartSubtotal"><?php echo e($general->cur_sym); ?>0</span>
                                </li>
                                <?php if(session()->has('coupon')): ?>
                                    <li>
                                        <span class="subtitle"><?php echo app('translator')->get('Coupon'); ?> (<?php echo e(session('coupon')['code']); ?>)</span>
                                        <span class="text-success" id="couponAmount"><?php echo e($general->cur_sym); ?><?php echo e(getAmount(session('coupon')['amount'], 2)); ?></span>
                                    </li>

                                    <li>
                                        <span class="subtitle">(<i class="la la-minus"></i>)</span>
                                        <span class="text-success" id="afterCouponAmount"><?php echo e($general->cur_sym); ?>0</span>
                                    </li>
                                <?php endif; ?>
                                <li>
                                    <span class="subtitle"><?php echo app('translator')->get('Shipping Charge'); ?></span>
                                    <span class="text-danger" id="shippingCharge"><?php echo e($general->cur_sym); ?>0</span>
                                </li>
                                <li class="border-0">
                                    <span class="subtitle bold"><?php echo app('translator')->get('Total'); ?></span>
                                    <span class="cl-title" id="cartTotal"><?php echo e($general->cur_sym); ?>0</span>
                                </li>
                            </ul>
                            <p id="shipping-details">

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Checkout Section Ends Here -->

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        (function($){
            var sub_total = Number(sessionStorage.getItem('subtotal'));
            $('#cartSubtotal').text(`<?php echo e($general->cur_sym); ?>`+ parseFloat(sub_total).toFixed(2));

            var couponAmount = <?php if(session()->has('coupon')): ?> <?php echo e(session('coupon')['amount']); ?> <?php else: ?> 0 <?php endif; ?> ;

            var afterCouponAmount = (sub_total - couponAmount).toFixed(2);

            $('#afterCouponAmount').text(afterCouponAmount)

            $('#cartTotal').text(`<?php echo e($general->cur_sym); ?>`+ parseFloat(sub_total - couponAmount).toFixed(2));



            $('select[name=shipping_method]').on('change', function(){
                var charge = parseFloat($('option:selected',this).data("charge"));
                var detail = $('option:selected',this).data('shipping');

                if(isNaN(charge)){
                    charge = 0;
                }

                if(detail){
                    $('#shipping-details').html(detail);
                }else{
                    $('#shipping-details').html('');
                }
                $('#shippingCharge').text(`<?php echo e($general->cur_sym); ?>` + parseFloat(charge).toFixed(2));
                $('#cartTotal').text(`<?php echo e($general->cur_sym); ?>` + (parseFloat(afterCouponAmount) + charge).toFixed(2));
            }).change();

            $('select[name=country]').val("<?php echo e(isset(auth()->user()->address->country)?auth()->user()->address->country:''); ?>");

        })(jQuery)
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
    <li><a href="<?php echo e(route('products')); ?>"><?php echo app('translator')->get('Products'); ?></a></li>
    <li><a href="<?php echo e(route('shopping-cart')); ?>"><?php echo app('translator')->get('Cart'); ?></a></li>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('meta-tags'); ?>
    <?php echo $__env->make('partials.seo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make(activeTemplate() .'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/checkout.blade.php ENDPATH**/ ?>