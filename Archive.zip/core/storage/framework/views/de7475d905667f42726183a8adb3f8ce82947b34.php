<?php $__env->startSection('content'); ?>
    <!-- Vendor Sections Here -->
    <section class="vendor-profile padding-bottom-half">
        <div class="container">
            <div class="vendor__single__item">
                <div class="vendor__single__item-thumb">
                    <img src="<?php echo e(getImage(imagePath()['seller']['shop_cover']['path'].'/'.$seller->shop->cover,imagePath()['seller']['shop_cover']['size'])); ?>" alt="vendor">
                </div>
                <div class="vendor__single__item-content">
                    <div class="vendor__single__author">
                        <div class="thumb">
                            <img src="<?php echo e(getImage(imagePath()['seller']['shop_logo']['path'].'/'.$seller->shop->logo,imagePath()['seller']['shop_logo']['size'])); ?>" alt="vendor">
                        </div>
                        <div class="content">
                            <div class="title__area">
                                <h4 class="title"><?php echo e($seller->shop->name); ?></h4>
                                <?php if(!empty($seller->shop->social_links)): ?>
                                <?php
                                    $socials = json_decode(json_encode($seller->shop->social_links));
                                ?>
                                <ul class="social__icons">
                                    <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a target="_blank" href="<?php echo e($item->link); ?>"><?php echo $item->icon; ?></a>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                                <?php endif; ?>
                            </div>
                            <div class="content-area">
                                <ul>
                                    <li>
                                        <i class="las la-map-marker-alt"><?php echo e($seller->shop->address); ?></i>
                                    </li>
                                    <li>
                                      <i class="las la-phone"></i> <?php echo e($seller->shop->phone); ?>

                                    </li>
                                    <li>
                                       <i class="las la-envelope"></i><?php echo e($seller->email); ?>

                                    </li>
                                    <li>
                                       <i class="las la-door-open"></i><?php echo app('translator')->get('Opens at :'); ?><?php echo e(showDateTime($seller->shop->opens_at,'h:i a')); ?>

                                    </li>
                                    <li>
                                        <i class="las la-door-closed"></i><?php echo app('translator')->get('Closed at :'); ?><?php echo e(showDateTime($seller->shop->closed_at,'h:i a')); ?>

                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Vendor Sections Here -->


    <!-- Vendor Products Sections Here -->
    <section class="vendor-products padding-bottom">
        <div class="container">
            <div class="section-header-2">
                <h4 class="title mr-auto"><?php echo app('translator')->get('Seller Products'); ?></h4>
            </div>

           

            <?php if($seller->shop->cashback_status == 1): ?>
            <div class="cart-total section-bg mb-3" <?php echo e(gradient()); ?>>
                <div class="m--15 d-flex flex-wrap align-items-center justify-content-between">
                    <div class="apply-coupon-code">
                            <button type="botton" name="coupon_apply">Cashback</button>
                    </div>
                    <div class="total">
                        <div class="d-flex flex-wrap justify-content-between">
                            <div class="sub--total">Amount</div>
                            <span class="amount"><span><?php if($seller->shop->cashback_type == 'flat'): ?><a><?php echo e($general->cur_sym); ?></a> <?php endif; ?><?php echo e($seller->shop->cashback_amount); ?> <?php if($seller->shop->cashback_type == 'percentage'): ?><a>%</a><?php endif; ?></span></span>
                        </div> 
                    </div>
                </div>
            </div>
            <?php endif; ?>

             
            <div class="row g-2 justify-content-center">
                <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-lg-3 col-sm-6 col-6 grid-control mb-30">
                    <div class="product-item-2 m-0">
                        <div class="product-item-2-inner wish-buttons-in">
                            <div class="product-thumb">

                                <a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>">
                                    <img src="<?php echo e(getImage(imagePath()['product']['path'].'/thumb_'.@$item->main_image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('flash'); ?>">
                                </a>
                            </div>
                            <div class="product-content">
                                <div class="product-before-content">
                                    <h6 class="title">
                                        <a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>"><?php echo e(__($item->name)); ?></a>
                                    </h6>
                                    <h6 class="title mt-1">
                                        <?php echo app('translator')->get('Brand'); ?> : <?php echo e(__($item->brand->name)); ?>

                                    </h6>
                                    <div class="single_content">
                                        <p><?php echo __($item->summary) ?></p>
                                    </div>

                                    <?php if($seller->shop->cashback_status == 1): ?>
                                    <hr>
                                    <div class="price">
                                    <small><?php if($seller->shop->cashback_type == 'flat'): ?><a><?php echo e($general->cur_sym); ?></a> <?php endif; ?><?php echo e($seller->shop->cashback_amount); ?> <?php if($seller->shop->cashback_type == 'percentage'): ?><a>%</a><?php endif; ?> Cashback</small>
                                    </div>
                                    <?php endif; ?>
                                    <div class="ratings-area justify-content-between">
                                        <div class="ratings">
                                            <?php echo displayAvgRating($item->reviews) ?>
                                        </div>
                                        <span class="ml-2 mr-auto">(<?php echo e($item->reviews->count()); ?>)</span>
                                        <div class="price">
                                            <?php echo e($general->cur_sym); ?><?php echo e(showAmount($item->base_price)); ?>

                                        </div>
                                       
                                    </div>
                                </div>
                                <div class="product-after-content">
                                    <button data-product="<?php echo e($item->id); ?>" class="cmn-btn btn-sm quick-view-btn">
                                        <?php echo app('translator')->get('View'); ?>
                                    </button>
                                    <div class="price">
                                        <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price)); ?>

                                    </div> 
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 col-sm-4 col-md-3 col-lg-2 col-xxl-8-item text-center">
                    <h6><?php echo app('translator')->get('No Product Yet'); ?></h6>
                </div>
                <?php endif; ?>

            </div>
            <div class="row justify-content-center">
                <div class="col-6 col-sm-4 col-md-3 col-lg-2 col-xxl-8-item">
                    <?php echo e($products->appends(request()->all())->links()); ?>

                </div>
            </div>
        </div>
    </section>
    <!-- Vendor Products Sections Here -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate .'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/seller_details.blade.php ENDPATH**/ ?>