<?php
    $categories = \App\Models\Category::where('is_special', 1)->get();
?>

<div class="container mt-4">
    <div class="overflow-hidden">
        <div class="related--slider-wrapper">
            <div class="related-slider owl-carousel owl-theme">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e(route('products.category', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>" class="d-block related-slide-item">
                    <div class="mb-10 overflow-hidden rounded">
                        <img src="<?php echo e(getImage(imagePath()['category']['path'].'/'.@$item->image, imagePath()['category']['size'])); ?>" class="w-100" alt="products-hot">
                    </div>
                    <span class="line-limitation-1 text-center"><?php echo e(__($item->name)); ?></span>
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/sections/banner_categories.blade.php ENDPATH**/ ?>