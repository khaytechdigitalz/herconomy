

<h4 class="title"><?php echo app('translator')->get('Your Wishlist'); ?></h4>

<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <?php
    if($item->product->offer && $item->product->offer->activeOffer){

        $discount = calculateDiscount($item->product->offer->activeOffer->amount, $item->product->offer->activeOffer->discount_type, $item->product->base_price);

    }else $discount = 0;
?>


<div class="single-product-item">
    <div class="thumb">
        <img src="<?php echo e(getImage(imagePath()['product']['path'].'/'.@$item->product->main_image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('shop'); ?>">
    </div>
    <a href="javascript:void(0)" class="remove-wishlist remove-item-button" data-page="0" data-id="<?php echo e($item->id); ?>" data-pid="<?php echo e($item->product->id); ?>"><i class="la la-times"></i></a>

    <div class="content">
        <h4 class="title"><a class="cl-white" href="<?php echo e(route('product.detail', ['id'=>$item->product->id, 'slug'=>slug($item->product->name)])); ?>"><?php echo e(shortDescription(__($item->product->name), 35)); ?></a></h4>
        <div class="price">
            <?php if($discount > 0): ?>
            <span class="pprice"><?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->product->base_price - $discount)); ?></span>
            <del class="dprice"><?php echo e(getAmount($item->product->base_price)); ?></del>
            <?php else: ?>
            <span class="pprice"><?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->product->base_price)); ?></span>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="single-product-item no_data">
    <div class="no_data-thumb w-50 ml-auto mr-auto mb-4 text-white">
        <i class="la la-heart-broken la-10x"></i>
    </div>
    <h6 class="cl-white"><?php echo e(__($emptyMessage)); ?></h6>
</div>
<?php endif; ?>

<?php if($data->count()>0): ?>
<div class="btn-wrapper text-center">
    <a href="<?php echo e(route('wishlist')); ?>" class="qv-btn bg btn-block"><?php if($more> 0): ?>
        <?php echo app('translator')->get('And'); ?> <?php echo e($more); ?> <?php echo app('translator')->get('More'); ?>
    <?php else: ?>
        <?php echo app('translator')->get('View Wishlist'); ?>
    <?php endif; ?></a>
</div>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/partials/wishlist_items.blade.php ENDPATH**/ ?>