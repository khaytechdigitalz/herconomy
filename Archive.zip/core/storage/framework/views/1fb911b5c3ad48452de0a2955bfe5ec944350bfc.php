    <!-- ===========Cart=========== -->
    <div class="cart-sidebar-area" id="cart-sidebar-area">
        <?php echo $__env->make($activeTemplate.'partials.side_modal_logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="bottom-content">
            <div class="cart-products cart--products">

            </div>
        </div>
    </div>
    <!-- ===========Cart End=========== -->

    <!-- ===========Wishlist=========== -->
    <div class="cart-sidebar-area" id="wish-sidebar-area">
        <?php echo $__env->make($activeTemplate.'partials.side_modal_logo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="bottom-content">
            <div class="cart-products wish-products">

            </div>
        </div>
    </div>
    <!-- ===========Wishlist End=========== -->


    <!-- Header Section Ends Here -->
    <div <?php echo e(gradient()); ?> class="dashboard-menu before-login-menu d-flex flex-wrap justify-content-center flex-column" id="account-sidebar-area">
        <span class="side-sidebar-close-btn"><i class="las la-times"></i></span>
        <?php if(auth()->guard()->guest()): ?>
            <div class="login-wrapper py-5 px-4">
                <h4 class="subtitle cl-white"><?php echo app('translator')->get('My Account'); ?></h4>
                <form method="POST" action="<?php echo e(route('user.login')); ?>" class="sign-in-form">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="login-username"><?php echo app('translator')->get('Username'); ?></label>
                        <input type="text" class="form-control" name="username" id="login-username" value="<?php echo e(old('email')); ?>" placeholder="<?php echo app('translator')->get('Username'); ?>">
                    </div>

                    <div class="form-group">
                        <label for="login-pass"><?php echo app('translator')->get('Password'); ?></label>
                        <input type="password" class="form-control" name="password" id="login-pass" placeholder="********">
                    </div>


                    <?php $captcha = loadCustomCaptcha(46, '100%') ?>
                    
                    <?php if($captcha): ?>
                        <div class="form-group">
                        <label for="password"><?php echo app('translator')->get('Captcha'); ?></label>
                            <?php echo $captcha ?>
                            <input type="text" class="mt-3" name="captcha" autocomplete="off" placeholder="<?php echo app('translator')->get('Verify Captcha'); ?>">
                        </div>
                    <?php endif; ?>

                    <div class="form-group text-right pt-2">
                        <button type="submit" class="login-button"><?php echo app('translator')->get('Login'); ?></button>
                    </div>

                    <div class="pt-2 mb-0">
                        <p class="create-accounts">
                            <a href="<?php echo e(route('user.password.request')); ?>" class="mb-2"><?php echo app('translator')->get('Forgot Password'); ?>?</a>
                        </p>
                        <p class="create-accounts">
                            <span><?php echo app('translator')->get('Don\'t have an account'); ?>?
                                 <a href="<?php echo e(route('user.register')); ?>" class="btn btn--secondary text--dark btn-sm mt-2"><?php echo app('translator')->get('Create A Customer Account'); ?></a> 
                            </span>
                        </p>
                        <p class="create-accounts">
                                 <a href="<?php echo e(route('user.affiliate')); ?>" class="btn btn--primary text--dark btn-sm mt-2"><?php echo app('translator')->get('Create An Affiliate Account'); ?></a> 
                            </span>
                        </p>
                    </div>
                </form>
            </div>
        <?php endif; ?>

        <?php if(auth()->guard()->check()): ?>
        <?php echo $__env->make($activeTemplate.'user.partials.dp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <ul class="cl-white" >
            <?php echo $__env->make($activeTemplate.'user.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </ul>
        <?php endif; ?>

    </div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/partials/side_modal.blade.php ENDPATH**/ ?>