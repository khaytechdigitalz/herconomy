<?php $__env->startSection('content'); ?>
 <!-- Category Section Starts Here -->
 <div class="category-section padding-bottom padding-top">
    <div class="container">
        <div class="row">
            <?php $__empty_1 = true; $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-2 mb-4">
                    <div class="cate-item">
                        <a href="<?php echo e(route('products.brand', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>" class="cate-inner">
                            <img class="w-100" src="<?php echo e(getImage(imagePath()['brand']['path'].'/'.@$item->logo, imagePath()['brand']['size'])); ?>" alt="<?php echo e($item->name); ?>">
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <?php if($brands->count() == 0): ?>
                <div class="col-lg-12 mb-30">
                    <?php echo $__env->make($activeTemplate.'partials.empty_message', ['message' => __($emptyMessage)], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>


        <?php echo e($brands->appends(request()->all())->links()); ?>


    </div>
</div>
<!-- Category Section Ends Here -->
<?php $__env->stopSection(); ?>


<?php $__env->startPush('breadcrumb-plugins'); ?>
    <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('meta-tags'); ?>
    <?php echo $__env->make('partials.seo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate .'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/brands.blade.php ENDPATH**/ ?>