<?php $__env->startSection('panel'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card b-radius--10 ">
                <div class="card-body p-0">
                    <div class="row justify-content-end">
                        <div class="col-xl-3 mb-3">
                            <form action="<?php echo e(route('admin.sellers.search', $scope ?? str_replace('admin.sellers.', '', request()->route()->getName()))); ?>" method="GET" class="pt-3 px-3">
                                <div class="input-group has_append">
                                    <input type="text" name="search" class="form-control" placeholder="<?php echo app('translator')->get('sellername or email'); ?>" value="<?php echo e($search ?? ''); ?>">
                                    <div class="input-group-append">
                                        <button class="btn btn--primary" type="submit"><i class="fa fa-search"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <div class="table-responsive--md  table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Seller'); ?></th>
                                <th><?php echo app('translator')->get('Email'); ?> | <?php echo app('translator')->get('Mobile'); ?></th>
                                <th><?php echo app('translator')->get('Products'); ?> | <?php echo app('translator')->get('Sale'); ?></th>
                                <th><?php echo app('translator')->get('Balance'); ?></th>
                                <th><?php echo app('translator')->get('Featured'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Seller'); ?>">
                                    <span class="font-weight-bold d-block"><?php echo e($seller->fullname); ?></span>
                                    <a href="<?php echo e(route('admin.sellers.detail', $seller->id)); ?>"><?php echo e($seller->username); ?></a>
                                </td>

                                <td data-label="<?php echo app('translator')->get('Email'); ?> | <?php echo app('translator')->get('Mobile'); ?>">
                                    <?php echo e($seller->email); ?><br><?php echo e($seller->mobile); ?>

                                </td>

                                <td data-label="<?php echo app('translator')->get('Products'); ?> | <?php echo app('translator')->get('Sale'); ?>">
                                    <span data-toggle="tooltip" title="<?php echo app('translator')->get('Total Products'); ?>"><?php echo e($seller->products->count()); ?></span>
                                    <span class="d-block font-weight-bold" data-toggle="tooltip" title="<?php echo app('translator')->get('Total Sale'); ?>">
                                        <?php echo e($seller->totalSold()); ?> <?php echo app('translator')->get('pcs'); ?>
                                    </span>
                                </td>

                                <td data-label="<?php echo app('translator')->get('Balance'); ?>">
                                    <span class="font-weight-bold">
                                        <?php echo e($general->cur_sym); ?><?php echo e(showAmount($seller->balance)); ?>

                                    </span>
                                </td>

                                <td data-label="<?php echo app('translator')->get('Featured'); ?>">
                                    <?php if($seller->featured == 1): ?>
                                     <span class="badge badge--success"><?php echo app('translator')->get('Yes'); ?></span>
                                    <?php else: ?>
                                     <span class="badge badge--dark"><?php echo app('translator')->get('No'); ?></span>
                                    <?php endif; ?>
                                </td>

                                <td data-label="<?php echo app('translator')->get('Action'); ?>">


                                    <a href="<?php echo e(route('admin.sellers.detail', $seller->id)); ?>" class="icon-btn" data-toggle="tooltip" title="" data-original-title="<?php echo app('translator')->get('Details'); ?>">
                                        <i class="las la-desktop text--shadow"></i>
                                    </a>

                                    <?php if($seller->featured == 1): ?>
                                        <button data-route="<?php echo e(route('admin.sellers.feature', $seller->id)); ?>" class="feature icon-btn btn--danger" data-remove="1" data-toggle="tooltip" title="" data-original-title="<?php echo app('translator')->get('Remove from featured list'); ?>">
                                        <i class="las la-fire"></i>
                                        </button>
                                    <?php else: ?>
                                        <button data-route="<?php echo e(route('admin.sellers.feature', $seller->id)); ?>" class="feature icon-btn btn--secondary" data-remove="" data-toggle="tooltip" title="" data-original-title="<?php echo app('translator')->get('Mark as featured seller'); ?>">
                                            <i class="las la-fire"></i>
                                        </button>
                                    <?php endif; ?>

                                    <div class="dropdown d-inline-flex" data-toggle="tooltip" title="<?php echo app('translator')->get('More'); ?>">
                                        <button class="btn icon-btn btn--dark dropdown-toggle" type="button" role="button" id="dropdownMenuLink" data-toggle="dropdown" aria-expanded="false">
                                            <span class="icon text-white"><i class="las la-chevron-circle-down mr-0"></i></span>
                                        </button>

                                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                                            <a href="<?php echo e(route('admin.sellers.login',$seller->id)); ?>" target="_blank" class="dropdown-item">
                                                <?php echo app('translator')->get('Login as Seller'); ?>
                                            </a>

                                            <a href="<?php echo e(route('admin.sellers.login.history.single', $seller->id)); ?>"
                                                class="dropdown-item">
                                                 <?php echo app('translator')->get('Login Logs'); ?>
                                             </a>
                                             <a href="<?php echo e(route('admin.sellers.email.single',$seller->id)); ?>"
                                                class="dropdown-item">
                                                 <?php echo app('translator')->get('Send Email'); ?>
                                             </a>

                                             <a href="<?php echo e(route('admin.sellers.email.log',$seller->id)); ?>" class="dropdown-item">
                                                 <?php echo app('translator')->get('Email Log'); ?>
                                             </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                            <?php endif; ?>

                            </tbody>
                        </table><!-- table end -->
                    </div>
                </div>
                <?php if($sellers->hasPages()): ?>
                    <div class="card-footer py-4">
                        <?php echo e(paginateLinks($sellers)); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
         <div class="modal fade" id="featureModal" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered" role="document">
              <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="title"></h5>
                        <button type="button" class="close ml-auto" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form action="" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="modal-body">
                            <p class="msg"><?php echo app('translator')->get('Are you sure to mark as feature this seller?'); ?></p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('No'); ?></button>
                            <button type="submit"  class="btn btn--primary del"><?php echo app('translator')->get('Yes'); ?></button>
                        </div>
                    </form>
              </div>
            </div>
        </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
     <script>
            'use strict';
            (function ($) {
                $('.feature').on('click',function () {
                    var route = $(this).data('route');
                    var remove = $(this).data('remove');
                    var modal = $('#featureModal');
                    if(remove == 1){
                        modal.find('.msg').text('<?php echo app('translator')->get("Are you sure wants to remove this seller from featured?"); ?>');
                        modal.find('.title').text('<?php echo app('translator')->get("Remove from featured."); ?>');
                    } else{
                        modal.find('.msg').text('<?php echo app('translator')->get("Are you sure to mark as feature this seller?"); ?>');
                        modal.find('.title').text('<?php echo app('translator')->get("Mark as featured"); ?>');
                    }
                    modal.find('form').attr('action',route);
                    modal.modal('show');
                });
            })(jQuery);
     </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/admin/seller/list.blade.php ENDPATH**/ ?>