<?php $__env->startSection('content'); ?>
<div class="dashboard-section padding-bottom padding-top">
    <div class="container">
        <div class="row">
            <div class="col-xl-3">
                <div class="dashboard-menu">
                    <?php echo $__env->make($activeTemplate.'user.partials.dp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <ul>
                        <?php echo $__env->make($activeTemplate.'user.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </ul>
                </div>
            </div>
            <div class="col-xl-9">
                <table class="regular-table section-bg">
                    <thead>
                        <tr>
                            <th><?php echo app('translator')->get('Products'); ?></th>
                            <th><?php echo app('translator')->get('Review'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td>
                                    <a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>" class="cart-item mw-100 p-2">
                                        <div class="cart-img">
                                            <img src="<?php echo e(getImage(imagePath()['product']['path'].'/thumb_'.@$item->main_image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('cart'); ?>">
                                        </div>

                                        <div class="cart-cont">
                                            <h6 class="title"><?php echo e($item->name); ?></h6>
                                        </div>
                                    </a>
                                </td>
                                <td>
                                    <div class="px-3 d-flex flex-wrap align-items-center justify-content-center">
                                        <?php if($item->userReview): ?>
                                        <a href="javascript:void(0)" class="cmn-btn review-btn"><?php echo app('translator')->get('Reviewed'); ?></a>
                                        <?php else: ?>
                                        <a href="javascript:void(0)" data-pid="<?php echo e($item->id); ?>" class="cmn-btn review-btn"><?php echo app('translator')->get('Review Now'); ?></a>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="100%">
                                    <?php echo e(__($emptyMessage)); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <?php if($products->count() > 16): ?>
                <div class="product-pagination">
                    <div class="theme-paggination-block">
                        <?php echo e($products->appends(request()->all())->links()); ?>

                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="reviewModal" role="dialog">
    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title"><?php echo app('translator')->get('Add Review'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
            </div>
            <div class="modal-body">
                <div class="add-review">
                    <form action="<?php echo e(route('user.product.review.submit')); ?>" method="POST" class="review-form rating row">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="pid" value="">
                        <div class="review-form-group mb-20 col-md-6 d-flex flex-wrap">
                            <label class="review-label mb-0 mr-3"><?php echo app('translator')->get('Your Rating'); ?> :</label>
                            <div class="rating-form-group">
                                <label class="star-label">
                                    <input type="radio" name="rating" value="1"/>
                                    <span class="icon"><i class="las la-star"></i></span>
                                </label>
                                <label class="star-label">
                                    <input type="radio" name="rating" value="2"/>
                                    <span class="icon"><i class="las la-star"></i></span>
                                    <span class="icon"><i class="las la-star"></i></span>
                                </label>
                                <label class="star-label">
                                    <input type="radio" name="rating" value="3"/>
                                    <span class="icon"><i class="las la-star"></i></span>
                                    <span class="icon"><i class="las la-star"></i></span>
                                    <span class="icon"><i class="las la-star"></i></span>
                                </label>
                                <label class="star-label">
                                    <input type="radio" name="rating" value="4"/>
                                    <span class="icon"><i class="las la-star"></i></span>
                                    <span class="icon"><i class="las la-star"></i></span>
                                    <span class="icon"><i class="las la-star"></i></span>
                                    <span class="icon"><i class="las la-star"></i></span>
                                </label>
                                <label class="star-label">
                                    <input type="radio" name="rating" value="5"/>
                                    <span class="icon"><i class="las la-star"></i></span>
                                    <span class="icon"><i class="las la-star"></i></span>
                                    <span class="icon"><i class="las la-star"></i></span>
                                    <span class="icon"><i class="las la-star"></i></span>
                                    <span class="icon"><i class="las la-star"></i></span>
                                </label>
                            </div>
                        </div>
                        <div class="review-form-group mb-20 col-12 d-flex flex-wrap">
                            <label class="review-label" for="review-comments"><?php echo app('translator')->get('Say Something about This Product'); ?></label>
                            <textarea name="review" class="review-input rounded--5 border--1" id="review-comments"></textarea>
                        </div>
                        <div class="review-form-group mb-20 col-12 d-flex flex-wrap">
                            <button type="submit" class="submit-button rounded--5 btn--sm ml-auto"><?php echo app('translator')->get('Submit Review'); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    "use strict";
    (function($){
        $('.review-btn').on('click', function(){
            var modal = $('#reviewModal');
            modal.find('input[name=pid]').val($(this).data('pid'));
            modal.modal('show');
        });
    })(jQuery);
</script>
<?php $__env->stopPush(); ?>


<?php $__env->startPush('breadcrumb-plugins'); ?>
    <li><a href="<?php echo e(route('user.home')); ?>"><?php echo app('translator')->get('Dashboard'); ?></a></li>
<?php $__env->stopPush(); ?>





<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/user/orders/products_for_review.blade.php ENDPATH**/ ?>