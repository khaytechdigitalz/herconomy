<?php $__env->startSection('content'); ?>

<div class="container padding-top padding-bottom">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card border-0 shadow-md">
                    <h5 class="cl-1 pt-3 text-center"><?php echo app('translator')->get('Payment Validaion'); ?></h5>
                    <hr>
                    <div class="card-body">
                        <form action="<?php echo e(route('user.deposit.manual.update')); ?>" method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="gateway" value="<?php echo e($method->id); ?>"/>
                            <div class="row">
                                <div class="col-md-12">
                                    <h4 class="text-center"><?php echo app('translator')->get('You\'re requested to pay the final amount of '); ?> <?php echo e(getAmount($data['final_amo'])); ?> <?php echo e($method->currency); ?> <?php echo app('translator')->get('including'); ?> <?php echo e(getAmount($data['charge']*$data['rate'])); ?> <?php echo e($method->currency); ?> <?php echo app('translator')->get('for charge.'); ?></h4>
                                    <hr>

                                    <h4 class="text-center bg--warning p-2 mb-2"><?php echo app('translator')->get('Please, follow the instruction'); ?></h4>
                                    <p class="pt-2"><?php echo __($method->method->description) ?></p>
                                </div>

                                <?php if($method->gateway_parameter): ?>

                                    <?php $__currentLoopData = json_decode($method->gateway_parameter); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php if($v->type == "text"): ?>
                                            <div class="col-md-12">
                                                <div class="form-group">
                                                    <label><strong><?php echo e(__(inputTitle($v->field_level))); ?> <?php if($v->validation == 'required'): ?> <span class="text-danger">*</span>  <?php endif; ?></strong></label>
                                                    <input type="text" class="form-control form-control-lg"
                                                           name="<?php echo e($k); ?>"  value="<?php echo e(old($k)); ?>" placeholder="<?php echo e(__($v->field_level)); ?>">
                                                </div>
                                            </div>
                                        <?php elseif($v->type == "textarea"): ?>
                                                <div class="col-md-12">
                                                    <div class="form-group">
                                                        <label><strong><?php echo e(__(inputTitle($v->field_level))); ?>

                                                            <?php if($v->validation == 'required'): ?>
                                                            <span class="text-danger">*</span>
                                                            <?php endif; ?></strong>
                                                        </label>
                                                        <textarea name="<?php echo e($k); ?>"  class="form-control"  placeholder="<?php echo e(__($v->field_level)); ?>" rows="3"><?php echo e(old($k)); ?></textarea>

                                                    </div>
                                                </div>
                                        <?php elseif($v->type == "file"): ?>
                                            <div class="col-md-12">

                                                <label class="text-uppercase">
                                                    <strong>
                                                        <?php echo e(__($v->field_level)); ?> <?php if($v->validation == 'required'): ?> <span class="text-danger">*</span>  <?php endif; ?>
                                                    </strong>
                                                </label>
                                                <div class="verification-img">
                                                    <div class="image-upload">
                                                        <div class="image-edit">
                                                            <input type='file' name="<?php echo e($k); ?>" id="imageUpload" accept=".png, .jpg, .jpeg" />
                                                            <label for="imageUpload"></label>
                                                        </div>
                                                        <div class="image-preview">
                                                            <div id="imagePreview" style="background-image: url(<?php echo e(asset(imagePath()['image']['default'])); ?>);">
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                <?php endif; ?>
                                <div class="col-md-12 my-2">
                                    <button type="submit" class="btn btn--base btn-block mt-2 text-center"><?php echo app('translator')->get('Confirm'); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    "use strict";
    (function($){
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();
                reader.onload = function(e) {
                    $('#imagePreview').css('background-image', 'url('+e.target.result +')');
                    $('#imagePreview').hide();
                    $('#imagePreview').fadeIn(650);
                }
                reader.readAsDataURL(input.files[0]);
            }
        }
        $("#imageUpload").on('change', function() {
            readURL(this);
        });
    })(jQuery)
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make(activeTemplate().'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/user/manual_payment/manual_confirm.blade.php ENDPATH**/ ?>