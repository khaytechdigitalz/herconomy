<?php if($reviews->count() > 0): ?>
<?php $__currentLoopData = $reviews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="review-item">
        <div class="thumb">
            <img src="<?php echo e(getAvatar('assets/images/user/profile/'. $item->user->image,'350x300')); ?>" alt="<?php echo app('translator')->get('review'); ?>">
        </div>
        <div class="content">
            <div class="entry-meta">
                <h6 class="posted-on">
                    <a href="#"><?php echo e($item->user->fullname); ?></a>
                    <span><?php echo e(\Carbon\Carbon::parse($item->created_at)->diffForHumans()); ?></span>
                </h6>
                <div class="ratings">
                    <?php echo ratings($item->rating) ?>

                </div>
            </div>
            <div class="entry-content">
                <p><?php echo e($item->review); ?></p>
            </div>
        </div>
    </div>
    <?php
        $last_id = $item->id;
    ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
<div class="alert cl-title alert--base" role="alert">
        <strong><?php echo app('translator')->get('No reviews yet for this product'); ?></strong>
    </div>
<?php endif; ?>

<?php if($reviews->currentPage() != $reviews->lastPage()): ?>
    <div id="load_more">
        <button type="button" name="load_more_button" class="cmn-btn btn-block" id="load_more_button" data-url="<?php echo e($reviews->nextPageUrl()); ?>"><?php echo app('translator')->get('Load More'); ?></button>
    </div>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/partials/product_review.blade.php ENDPATH**/ ?>