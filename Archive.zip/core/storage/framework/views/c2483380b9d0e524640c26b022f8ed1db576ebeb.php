<?php $__env->startSection('panel'); ?>

    <div class="row">
        <div class="col-lg-12">
            <div class="card b-radius--10">
                <div class="card-body p-0">
                    <div class="row justify-content-end">
                        <div class="col-xl-3 mb-3">
                            <form action="" method="GET" class="pt-3 px-3">
                                <div class="input-group has_append">
                                    <input type="text" name="search" class="form-control" placeholder="<?php echo app('translator')->get('Search by Transaction ID'); ?>..."
                                        value="<?php echo e(request()->search ?? ''); ?>">
                                    <div class="input-group-append">
                                        <button class="btn btn--primary" id="search-btn" type="submit"><i class="la la-search"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="table-responsive--md table-responsive">
                        <table class="table table--light style--two">
                            <thead>
                                <tr>
                                    <th><?php echo app('translator')->get('Transaction No.'); ?> | <?php echo app('translator')->get('Time'); ?></th>
                                    <th><?php echo app('translator')->get('Order'); ?></th>
                                    <th><?php echo app('translator')->get('Amount'); ?> | <?php echo app('translator')->get('Charge'); ?></th>
                                    <th><?php echo app('translator')->get('After Charge'); ?></th>
                                    <th><?php echo app('translator')->get('Receivable'); ?></th>
                                    <th><?php echo app('translator')->get('Settled At'); ?></th>
                                    <th><?php echo app('translator')->get('Status'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $settlement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td data-label="<?php echo app('translator')->get('Transaction No.'); ?> | <?php echo app('translator')->get('Time'); ?>">
                                            <span class="d-block font-weight-bold text--primary">
                                                <?php echo e($data->trx); ?>

                                            </span>
                                            <span class="text--small">
                                                <?php echo e(showDateTime($data->created_at)); ?>

                                            </span>
                                        </td>

                                        <td data-label="<?php echo app('translator')->get('Order'); ?>">
                                            <a href="<?php echo e(route('seller.order.details',$data->order_id)); ?>?ref=<?php echo e(encrypt($data->order_ref)); ?>" class="badge btn-sm bg--primary approveBtn" data-admin_feedback="<?php echo e($data->admin_feedback); ?>">View Order <small>(<?php echo e(__($data->order_ref)); ?>)</small></a>

                                        </td>

                                        <td data-label="<?php echo app('translator')->get('Amount'); ?>">
                                            <span class="d-block"><?php echo e(showAmount($data->amount)); ?> <?php echo e(__($general->cur_text)); ?></span>
                                            <span class="text--danger">
                                                <?php echo e(showAmount($data->charge)); ?> <?php echo e(__($general->cur_text)); ?>

                                            </span>
                                        </td>

                                        <td data-label="<?php echo app('translator')->get('After Charge'); ?>">
                                            <?php echo e(showAmount($data->after_charge)); ?> <?php echo e(__($general->cur_text)); ?>

                                        </td>

                                        <td data-label="<?php echo app('translator')->get('Receivable'); ?>" class="text--success">
                                            <span class="d-block font-weight-bold"><?php echo e(showAmount($data->final_amount)); ?> <?php echo e(__($data->currency)); ?></span>
                                        </td>

                                        <td data-label="<?php echo app('translator')->get('Settled At'); ?>" class="text--success">
                                            <span class="d-block font-weight-bold"><?php echo e(showDateTime($data->settled_at)); ?></span> 
                                            <span class="d-block font-weight-bold"><?php echo e(diffForHumans($data->settled_at)); ?></span>
                                        </td>
                                        <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                            <?php if($data->status == 0): ?>
                                                <span class="badge badge--warning"><?php echo app('translator')->get('Pending'); ?></span>
                                            <?php elseif($data->status == 1): ?>
                                                <span class="badge badge--success"><?php echo app('translator')->get('Completed'); ?>
                                                    <button class="admin-feedback-btn bg--primary approveBtn" data-admin_feedback="<?php echo e($data->admin_feedback); ?>"></button>
                                                </span>
                                            <?php elseif($data->status == 2): ?>
                                                <span class="badge badge--danger"><?php echo app('translator')->get('Rejected'); ?>
                                                    <button class="admin-feedback-btn bg--primary approveBtn" data-admin_feedback="<?php echo e($data->admin_feedback); ?>"></button>
                                                </span>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <tr>
                                        <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            
                <?php if($settlement->hasPages()): ?>
                    <div class="card-footer py-4">
                        <?php echo e(paginateLinks($settlement)); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>


    
    <div id="detailModal" class="modal fade" tabindex="-1" role="dialog">
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title"><?php echo app('translator')->get('Admin\'s Feedback'); ?></h5>
                </div>
                <div class="modal-body">

                    <div class="withdraw-detail"></div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('Close'); ?></button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        (function($){
            "use strict";
            $('.approveBtn').on('click', function() {
                var modal = $('#detailModal');
                var feedback = $(this).data('admin_feedback');
                modal.find('.withdraw-detail').html(`<p> ${feedback} </p>`);
                modal.modal('show');
            });
        })(jQuery);

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('seller.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/seller/settlement/log.blade.php ENDPATH**/ ?>