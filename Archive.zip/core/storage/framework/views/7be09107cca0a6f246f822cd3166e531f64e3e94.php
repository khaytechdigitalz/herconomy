<?php $__env->startSection('content'); ?>
    <div class="payment-history-section padding-bottom padding-top">
        <div class="container">
            <div class="row">
                <div class="col-xl-3">
                    <div class="dashboard-menu">
                        <?php echo $__env->make($activeTemplate.'user.partials.dp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <ul>
                            <?php echo $__env->make($activeTemplate.'user.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-9">
                    <a href="<?php echo e(route('ticket.open')); ?>" class="btn btn--base float-right mb-3"> <i class="las la-box-open"></i> <?php echo app('translator')->get('Open New Ticket'); ?> </a>
                    <table class="payment-table section-bg">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Subject'); ?></th>
                                <th><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Priority'); ?></th>
                                <th><?php echo app('translator')->get('Last Reply'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ticket): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Subject'); ?>"> <a href="<?php echo e(route('ticket.view', $ticket->ticket)); ?>" class="font-weight-bold"> [<?php echo app('translator')->get('Ticket'); ?>#<?php echo e($ticket->ticket); ?>] <?php echo e(__($ticket->subject)); ?> </a></td>

                                <td data-label="<?php echo app('translator')->get('Status'); ?>">
                                    <?php echo $ticket->statusBadge() ?>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Priority'); ?>">
                                    <?php echo $ticket->priorityBadge() ?>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Last Reply'); ?>"><?php echo e(\Carbon\Carbon::parse($ticket->last_reply)->diffForHumans()); ?> </td>

                                <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                    <a href="<?php echo e(route('ticket.view', $ticket->ticket)); ?>"  class="btn-normal-2 btn-sm">
                                        <i class="fa fa-desktop"></i>
                                    </a>
                                </td>
                            </tr>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                           <tr><td class="text-center" colspan="12"><?php echo app('translator')->get('No data found'); ?></td></tr>
                          <?php endif; ?>
                        </tbody>
                    </table>

                    <?php echo e($tickets->appends(request()->all())->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/user/support/index.blade.php ENDPATH**/ ?>