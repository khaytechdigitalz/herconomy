<!-- Single Product Section Starts Here -->
<section class="single-product-section padding-bottom-half padding-top-half overflow-hidden border-bottom">
    <div class="container">
        <div class="section-header-2">
            <h4 class="title"><?php echo app('translator')->get('Our Seller'); ?></h4>
            <a class="btn--base btn-sm" href="<?php echo e(route('all.sellers')); ?>"><?php echo app('translator')->get('View All'); ?></a>
        </div>
        <div class="row g-2">
            <?php $__currentLoopData = $featuredSeller; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 col-sm-4 col-md-3 col-xxl-8-item">
                <a class="d-block shop-item" href="<?php echo e(route('seller.details',[$seller->id,slug($seller->shop->name)])); ?>">
                    <div class="thumb mb-10 oh rounded">
                        <img src="<?php echo e(getImage(imagePath()['seller']['shop_logo']['path'].'/'.@$seller->shop->logo, imagePath()['seller']['shop_logo']['size'])); ?>" alt="products">
                    </div>
                    <h6 class="line-limitation-2 text-center"><?php echo e($seller->shop->name); ?></h6>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<!-- Single Product Section Ends Here -->
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/sections/featured_seller.blade.php ENDPATH**/ ?>