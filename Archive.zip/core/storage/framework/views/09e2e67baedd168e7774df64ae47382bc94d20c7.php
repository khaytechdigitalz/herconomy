<?php $__env->startSection('content'); ?>

    <main class="banner-body bg--section">
        <div class="container">
            <div class="banner-section overflow-hidden">
                <?php echo $__env->make($activeTemplate.'partials.left_category_menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make($activeTemplate.'sections.banner_sliders', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make($activeTemplate.'sections.banner_promotional', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
        <?php echo $__env->make($activeTemplate.'sections.banner_categories', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </main>

    <?php echo $__env->make($activeTemplate.'sections.invite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if($offers->count() > 0): ?>
     <?php echo $__env->make($activeTemplate.'sections.offers', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if($featuredProducts->count() > 0): ?>
      <?php echo $__env->make($activeTemplate.'sections.featured_products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if($latestProducts->count() > 0): ?>
      <?php echo $__env->make($activeTemplate.'sections.latest_products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if($featuredSeller->count() > 0): ?>
     <?php echo $__env->make($activeTemplate.'sections.featured_seller', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->make($activeTemplate.'sections.invite_seller', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php if($topBrands->count() > 0): ?>
      <?php echo $__env->make($activeTemplate.'sections.brands', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if($topSellingProducts->count() > 0): ?>
      <?php echo $__env->make($activeTemplate.'sections.trending_products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php echo $__env->make($activeTemplate.'sections.subscribe', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        (function($){
            $(document).on('click','.subscribe-btn' , function(){
                var email = $('input[name="email"]').val();
                $.ajax({
                    headers: {"X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"},
                    url:"<?php echo e(route('subscribe')); ?>",
                    method:"POST",
                    data:{email:email},
                    success:function(response)
                    {
                        if(!response.success) {
                            notify('success', response.success);
                        }else{
                            notify('error', response);
                        }
                    }
                });
            });
        })(jQuery)
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/home.blade.php ENDPATH**/ ?>