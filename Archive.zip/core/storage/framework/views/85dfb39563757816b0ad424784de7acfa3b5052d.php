<section class="shop-section padding-bottom-half padding-top-half overflow-hidden border-bottom">
    <div class="container">
        <div class="section-header-2">
            <h4 class="title"><?php echo app('translator')->get('Top Brands'); ?></h4>

            <span class="">
                <a class="btn--base btn-sm" href="<?php echo e(route('brands')); ?>"><?php echo app('translator')->get('View All'); ?></a>
            </span>

        </div>

        <div class="row g-2">
            <?php $__currentLoopData = $topBrands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 col-sm-4 col-md-3 col-lg-3 col-xl-2 col-xxl-8-item">
                <a href="<?php echo e(route('products.brand',[$brand->id,slug($brand->name)])); ?>" class="d-block shop-item">
                    <div class="thumb mb-10 oh rounded">
                        <img src="<?php echo e(getImage(imagePath()['brand']['path'].'/'.$brand->logo,imagePath()['brand']['size'])); ?>" class="w-100" alt="brand-logo">
                    </div>
                    <span class="line-limitation-2 text-center"><?php echo e($brand->name); ?></span>
                </a>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/sections/brands.blade.php ENDPATH**/ ?>