<div class="empty-message">
    <img src="<?php echo e(getImage('assets/images/empty.png')); ?>" alt="">
    <div class="message"><?php echo e($message); ?></div>

</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/partials/empty_page.blade.php ENDPATH**/ ?>