
<?php
    $banners = getContent('banner_promotional.element', false, 2, true);
?>

<div class="banner__quick-thumb">
    <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a target="_blank" href="<?php echo e($banner->data_values->link); ?>" class="thumb">
        <img src="<?php echo e(getImage('assets/images/frontend/banner_promotional/'. @$banner->data_values->image, '600x500')); ?>" alt="banner">
    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/sections/banner_promotional.blade.php ENDPATH**/ ?>