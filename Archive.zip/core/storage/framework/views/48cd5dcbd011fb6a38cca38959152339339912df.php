<?php $__env->startSection('panel'); ?>
    <form action="" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="card">
            <div class="card-header"><h5 class="card-title mb-0"><?php echo app('translator')->get('Images'); ?></h5></div>
            <div class="card-body pb-0">
                <div class="row">
                    <div class="col-lg-4 col-xl-3 col-sm-5">
                        <div class="payment-method-item">
                            <label class=" font-weight-bold"><?php echo app('translator')->get('Logo'); ?></label>
                            <div class="payment-method-header">
                                <div class="thumb">
                                    <div class="avatar-preview">
                                        <div class="profilePicPreview" style="background-image: url(<?php echo e(getImage(imagePath()['seller']['shop_logo']['path'].'/'.@$shop->logo,imagePath()['seller']['shop_logo']['size'])); ?>)">
                                        </div>
                                    </div>
                                    <div class="avatar-edit">
                                        <input type="file" name="image" class="profilePicUpload" id="image" accept=".png, .jpg, .jpeg"/>
                                        <label for="image" class="bg--primary"><i class="la la-pencil"></i></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-8 col-xl-9 col-sm-7">
                        <div class="payment-method-item">
                            <label class=" font-weight-bold"><?php echo app('translator')->get('Cover Photo'); ?></label>
                            <div class="payment-method-header">
                                <div class="thumb">
                                    <div class="avatar-preview">
                                        <div class="profilePicPreview" style="background-image: url(<?php echo e(getImage(imagePath()['seller']['shop_cover']['path'].'/'.@$shop->cover,imagePath()['seller']['shop_cover']['size'])); ?>); <?php echo e(@$shop->cover?'background-size:cover':''); ?>">
                                        </div>
                                    </div>
                                    <div class="avatar-edit">
                                        <input type="file" name="cover_image" class="profilePicUpload" id="coverImage" accept=".png, .jpg, .jpeg"/>
                                        <label for="coverImage" class="bg--primary"><i class="la la-pencil"></i></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-header"><h5 class="card-title mb-0"><?php echo app('translator')->get('Basic Information'); ?></h5></div>
            <div class="card-body">
                <div class="form-group row">
                    <div class="col-md-3">
                        <label class="font-weight-bold"><?php echo app('translator')->get('Shop Name'); ?></label>
                    </div>
                    <div class="col-md-9">
                        <input class="form-control" type="text" name="name" value="<?php echo e(old('name')??@$shop->name); ?>" >
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label class="font-weight-bold"><?php echo app('translator')->get('Phone'); ?></label>
                    </div>
                    <div class="col-md-9">
                        <input class="form-control" type="number" name="phone" value="<?php echo e(old('phone')??@$shop->phone); ?>" >
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label class="font-weight-bold"><?php echo app('translator')->get('Opens at'); ?></label>
                    </div>
                    <div class="col-md-9">
                        <div class="input-group clockpicker">
                            <input type="text" class="form-control" placeholder="--:--" name="opening_time" autocomplete="off" value="<?php echo e(old('opening_time')??showDateTime(@$shop->opens_at, 'H:i')); ?>">
                        </div>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label class="font-weight-bold"><?php echo app('translator')->get('Closed at'); ?></label>
                    </div>
                    <div class="col-md-9">
                        <div class="input-group clockpicker">
                            <input type="text" class="form-control" value="<?php echo e(old('opening_time')??showDateTime(@$shop->closed_at, 'H:i')); ?>" placeholder="--:--" name="closing_time" autocomplete="off">
                        </div>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label class="font-weight-bold"><?php echo app('translator')->get('Address'); ?></label>
                    </div>
                    <div class="col-md-9">
                        <input class="form-control" type="text" name="address" value="<?php echo e(old('address')??@$shop->address); ?>" >
                    </div>
                </div>
            </div>
        </div>

        <div class="card mt-3">
            <div class="card-header"><h5 class="card-title mb-0"><?php echo app('translator')->get('SEO Contents'); ?></h5></div>

            <div class="card-body">
                <div class="form-group row">
                    <div class="col-md-3">
                        <label class="font-weight-bold"><?php echo app('translator')->get('Meta Title'); ?></label>
                    </div>

                    <?php
                        if(old('meta_title')) $value = old('meta_title');
                        elseif(isset($shop)) $value = $shop->meta_title;
                        else $value = null;
                    ?>

                    <div class="col-md-9">
                        <input type="text" class="form-control" name="meta_title" value="<?php echo e($value); ?>" placeholder="<?php echo app('translator')->get('Meta Title'); ?>">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label class="font-weight-bold"><?php echo app('translator')->get('Meta Description'); ?></label>
                    </div>
                    <?php
                        if(old('meta_description')) $value = old('meta_description');
                        elseif(isset($shop)) $value = $shop->meta_description;
                        else $value = null;
                    ?>

                    <div class="col-md-9">
                        <textarea name="meta_description" rows="5" class="form-control"><?php echo e($value); ?></textarea>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label class="font-weight-bold"><?php echo app('translator')->get('Meta Keywords'); ?></label>
                    </div>
                    <?php
                        if(old('meta_keywords')){
                            $metaKeywords = old('meta_keywords');
                        }elseif($shop && $shop->meta_keywords){
                            $metaKeywords = $shop->meta_keywords;
                        }else{
                            $metaKeywords = null;
                        }
                    ?>

                    <div class="col-md-9">
                        <select name="meta_keywords[]" class="form-control select2-auto-tokenize"  multiple="multiple">
                            <?php if($metaKeywords): ?>
                                <?php $__currentLoopData = $metaKeywords; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($option); ?>" selected><?php echo e(__($option)); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </select>

                        <small class="form-text text-muted">
                            <i class="las la-info-circle"></i> <?php echo app('translator')->get('Type , as seperator or hit enter among keywords'); ?>
                        </small>
                    </div>
                </div>
            </div>
        </div>
        

        <div class="card mt-3">
            <div class="card-header"><h5 class="card-title mb-0"><?php echo app('translator')->get('Social Links'); ?></h5></div>
            <div class="card-body">

                <?php
                    if(old('social_links')){
                        $socialLinks = old('social_links');
                    }elseif($shop && $shop->social_links){
                        $socialLinks = $shop->social_links;
                    }else{
                        $socialLinks = null;
                    }
                ?>

                <div class="socials-wrapper">
                    <?php if($socialLinks): ?>
                        <?php $__currentLoopData = $socialLinks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="socials">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="social_links[<?php echo e($loop->index); ?>][name]" value="<?php echo e($item['name']); ?>" placeholder="<?php echo app('translator')->get('Type Name Here...'); ?>">
                                        </div>
                                    </div>

                                    <?php
                                        $icon = explode('"', $item['icon']);
                                    ?>

                                    <div class="col-md-4">
                                        <div class="input-group has_append">
                                            <input type="text" class="form-control icon-name" name="social_links[<?php echo e($loop->index); ?>][icon]" value="<?php echo e($item['icon']); ?>" placeholder="<?php echo app('translator')->get('Icon'); ?>" required>

                                            <div class="input-group-append">
                                                <button class="btn btn-outline-secondary iconPicker" data-icon="<?php echo e(@$icon[1]); ?>" role="iconpicker"></button>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-5">
                                        <div class="form-group abs-form-group d-flex justify-content-between flex-wrap">
                                            <input type="text" class="form-control" name="social_links[<?php echo e($loop->index); ?>][link]" value="<?php echo e($item['link']); ?>" placeholder="<?php echo app('translator')->get('Type Link Here...'); ?>">
                                            <button type="button" class="btn btn-outline--danger remove-social abs-button"><i class="la la-minus"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php endif; ?>
                </div>
                <div class="row">
                    <div class="col-md-8">
                        <p class="p-2 social-info"><?php echo app('translator')->get('Add social links as you want by clicking the (+) button on the right side.'); ?></p>
                    </div>

                    <div class="col-md-4">
                        <div class="d-flex justify-content-end">
                            <button type="button" class="btn btn-outline--success add-social "><i class="la la-plus"></i></button>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="form-group mt-3">
            <button type="submit" class="btn btn--primary btn-block btn-lg"><?php echo app('translator')->get('Save Changes'); ?></button>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>
    <style>
        .payment-method-item .payment-method-header .thumb, .payment-method-item .payment-method-header .thumb .profilePicPreview {
            width: 100%;
        }

        .payment-method-item .payment-method-header .thumb .profilePicPreview {
            height: 300px;
        }

    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script-lib'); ?>
<script src="<?php echo e(asset('assets/dashboard/js/vendor/bootstrap-clockpicker.min.js')); ?> "></script>
<script src="<?php echo e(asset('assets/dashboard/js/bootstrap-iconpicker.bundle.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style-lib'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/bootstrap-iconpicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
<script>
   'use strict';
    (function($){

        $('.clockpicker').clockpicker({
            placement: 'bottom',
            align: 'left',
            donetext: 'Done',
            autoclose:true,
        });

        $('.add-social').on('click', function(){
            var socials = $(document).find('.socials');
            var length         = socials.length;

            $('.social-info').addClass('d-none');
            var content = `<div class="socials">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="form-group">
                                            <input type="text" class="form-control" name="social_links[${length}][name]" placeholder="<?php echo app('translator')->get('Type Name Here...'); ?>">
                                        </div>
                                    </div>

                                    <div class="col-md-4">
                                        <div class="input-group has_append">
                                            <input type="text" class="form-control icon-name" name="social_links[${length}][icon]" value="<?php echo e(old('icon')); ?>" placeholder="<?php echo app('translator')->get('Icon'); ?>" required>

                                            <div class="input-group-append">
                                                <button class="btn btn-outline-secondary iconPicker" data-icon="fas fa-home" role="iconpicker"></button>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-5">
                                        <div class="form-group abs-form-group d-flex justify-content-between flex-wrap">
                                            <input type="text" class="form-control" name="social_links[${length}][link]" placeholder="<?php echo app('translator')->get('Type Link Here...'); ?>">
                                            <button type="button" class="btn btn-outline--danger remove-social abs-button"><i class="la la-minus"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </div>`;

            $(content).appendTo('.socials-wrapper').hide().slideDown('slow');

            socials     = $(document).find('.socials');
            length      = socials.length;

            socials = $(document).find('.socials');
            length         = socials.length;

            if(length > 0) {
                $('.remove-social').removeClass('d-none');
            }else{
                $('.remove-social').addClass('d-none');
            }

            $(document).find('.iconPicker').iconpicker();
        });

        $(document).on('change','.iconPicker' ,function (e) {
            $(this).parent().siblings('.icon-name').val(`<i class="${e.icon}"></i>`);
        });

        $(document).on('click', '.remove-social' ,function(){
            var parent = $(this).parents('.socials');
            parent.slideUp('slow', function(e){
                this.remove();
            });
        });
    })(jQuery);
</script>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('seller.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/seller/shop.blade.php ENDPATH**/ ?>