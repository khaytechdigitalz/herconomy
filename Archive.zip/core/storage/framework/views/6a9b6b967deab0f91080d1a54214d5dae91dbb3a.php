<?php $__env->startSection('content'); ?>
<div class="container padding-bottom padding-top">
    <div class="row justify-content-center">
        <div class="col-sm-10 col-md-7 col-lg-6 col-xl-4">
            <div class="card text-center">
                <div class="card-body">
                    <img src="<?php echo e($deposit->gatewayCurrency()->methodImage()); ?>"   alt="<?php echo app('translator')->get('Image'); ?>" class="w-100 mb-4">
                    <div>
                        <h5><?php echo app('translator')->get('Please Pay'); ?> <?php echo e(showAmount($deposit->final_amo)); ?> <?php echo e(__($deposit->method_currency)); ?></h5>
                        <h5 class="my-3"><?php echo app('translator')->get('To Get'); ?> <?php echo e(showAmount($deposit->amount)); ?>  <?php echo e(__($general->cur_text)); ?></h5>
                        <button type="button" class="btn--base mt-4 d-block  w-100" id="btn-confirm" onClick="payWithRave()"><?php echo app('translator')->get('Pay Now'); ?></button>
                    </div>
                    <form action="<?php echo e(route('ipn.'.$deposit->gateway->alias)); ?>" method="POST" class="text-center">
                        <script
                        src="//js.paystack.co/v1/inline.js"
                        data-key="<?php echo e($data->key); ?>"
                        data-email="<?php echo e($data->email); ?>"
                        data-amount="<?php echo e($data->amount); ?>"
                        data-currency="<?php echo e($data->currency); ?>"
                        data-ref="<?php echo e($data->ref); ?>"
                        data-custom-button="btn-confirm"
                        >
                       </script>
                   </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/user/payment/Paystack.blade.php ENDPATH**/ ?>