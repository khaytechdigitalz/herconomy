



<?php $__env->startSection('content'); ?>
        <!-- Hero Sections Here -->

        <!-- Hero Sections Here -->

          <!-- Vendor Sections Here -->
    <section class="vendor-section padding-top padding-bottom">
        <div class="container">
            <div class="row g-4 justify-content-center">
                <?php $__currentLoopData = $sellers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seller): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4">
                    <div class="vendor__item">
                        <div class="vendor__top">
                            <h5 class="title">
                                <a href="<?php echo e(route('seller.details',[$seller->id,slug($seller->shop->name)])); ?>"><?php echo e($seller->shop->name); ?></a>
                            </h5>
                            <hr>
                            <ul class="vendor__info">
                                <li>
                                    <i class="las la-map-marker-alt"><?php echo e($seller->shop->address); ?></i>
                                </li>
                                <li>
                                    <a href="Tel:<?php echo e($seller->shop->phone); ?>"><i class="las la-phone"></i> <?php echo e($seller->shop->phone); ?></a>
                                </li>
                                <li>
                                    <a href="Mailto:<?php echo e($seller->email); ?>"><i class="las la-envelope"></i><?php echo e($seller->email); ?></a>
                                </li>
                                <li class="my-2">
                                    <p><i class="las la-door-open"></i><?php echo app('translator')->get('Opens at :'); ?><?php echo e(showDateTime($seller->shop->opens_at,'h:i a')); ?></p>
                                </li>
                                <li class="my-2">
                                    <p> <i class="las la-door-closed"></i><?php echo app('translator')->get('Closed at :'); ?><?php echo e(showDateTime($seller->shop->closed_at,'h:i a')); ?></p>
                                </li>
                            </ul>
                        </div>
                        <div class="vendor__bottom">
                            <a href="<?php echo e(route('seller.details',[$seller->id,slug($seller->shop->name)])); ?>" class="read-more"><?php echo app('translator')->get('See Details'); ?></a>
                            <a href="<?php echo e(route('seller.details',[$seller->id,slug($seller->shop->name)])); ?>" class="vendor-author">
                                <img src="<?php echo e(getImage(imagePath()['seller']['shop_logo']['path'].'/'.$seller->shop->logo,imagePath()['seller']['shop_logo']['size'])); ?>" alt="vendor">
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- Vendor Sections Here -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make($activeTemplate .'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/all_sellers.blade.php ENDPATH**/ ?>