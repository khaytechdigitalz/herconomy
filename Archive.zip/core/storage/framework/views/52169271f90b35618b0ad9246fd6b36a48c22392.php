<?php
	$captcha = loadCustomCaptcha($height = 60, $width = '100%');
?>
<?php if($captcha): ?>
    <div class="contact-group">
        <label for="captcha_code"><?php echo app('translator')->get('Captha'); ?></label>
        <div class="multi-group">
            <?php echo $captcha ?>
        </div>
    </div>
    <div class="contact-group">
        <label for="captcha_code"><?php echo app('translator')->get('Verify Captha'); ?></label>
        <div class="multi-group">
            <input type="text" name="captcha" id="captcha_code" placeholder="<?php echo app('translator')->get('Enter Code'); ?>" class="form-control w-100">
        </div>
    </div>
<?php endif; ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/partials/custom_captcha.blade.php ENDPATH**/ ?>