<?php $__env->startSection('content'); ?>
    <div class="user-profile-section padding-top padding-bottom">
        <div class="container">
            <div class="row">
                <div class="col-xl-3">
                    <div class="dashboard-menu">
                        <?php echo $__env->make($activeTemplate.'user.partials.dp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <ul>
                            <?php echo $__env->make($activeTemplate.'user.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </ul>
                    </div>
                </div>
                <div class="col-xl-9">
                    <div class="checkout-area section-bg">
                        <div class="row">
                            <div class="col-lg-4 col-md-6">
                                <div class="user-profile">
                                    <div class="thumb">
                                        <img id="imagePreview" src="<?php echo e(getAvatar(imagePath()['profile']['user']['path'].'/'.$user->image )); ?>" alt="<?php echo app('translator')->get('user'); ?>">
                                        <label for="file-input" class="file-input-btn">
                                            <i class="la la-edit"></i>
                                        </label>
                                    </div>
                                    <div class="content">
                                        <h5 class="title"><?php echo e($user->fullname); ?></h5>
                                        <span><?php echo app('translator')->get('Username'); ?>: <?php echo e($user->username); ?></span>
                                        <span class="d-block"><?php echo app('translator')->get('Email'); ?>: <?php echo e($user->email); ?></span>
                                        <span class="d-block"><?php echo app('translator')->get('Mobile'); ?>: <?php echo e($user->mobile); ?></span>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-8 col-md-6">
                                <form action="" method="post" enctype="multipart/form-data" class="user-profile-form row mb--20">
                                    <?php echo csrf_field(); ?>

                                    <input type='file' class="d-none" name="image" id="file-input" accept=".png, .jpg, .jpeg" />

                                    <div class="col-lg-6 mb-20">
                                        <label class="billing-label"><?php echo app('translator')->get('First Name'); ?></label>
                                        <input class="form-control custom--style" type="text" name="firstname" value="<?php echo e($user->firstname); ?>" placeholder="<?php echo app('translator')->get('Last Name'); ?>">
                                    </div>

                                    <div class="col-lg-6 mb-20">
                                        <label class="billing-label"><?php echo app('translator')->get('Last Name'); ?></label>
                                        <input class="form-control custom--style" type="text" name="lastname" value="<?php echo e($user->lastname); ?>" placeholder="<?php echo app('translator')->get('Last Name'); ?>">
                                    </div>


                                    <div class="col-lg-6 mb-20">
                                        <label for="state" class="billing-label"><?php echo app('translator')->get('Country'); ?>:</label>
                                        <input type="text" class="form-control custom--style" placeholder="<?php echo app('translator')->get('Country'); ?>" value="<?php echo e(@$user->address->country); ?>" readonly>
                                    </div>

                                    <div class="col-lg-6 mb-20">
                                        <label for="state" class="billing-label"><?php echo app('translator')->get('State'); ?>:</label>
                                        <input type="text" class="form-control custom--style" id="state" name="state" placeholder="<?php echo app('translator')->get('state'); ?>" value="<?php echo e(@$user->address->state); ?>" required>
                                    </div>

                                    <div class="col-lg-6 mb-20">
                                        <label for="city" class="billing-label"><?php echo app('translator')->get('City'); ?>:</label>
                                        <input type="text" class="form-control custom--style" id="city" name="city" placeholder="<?php echo app('translator')->get('City'); ?>" value="<?php echo e(@$user->address->city); ?>" required>
                                    </div>

                                    <div class="col-lg-6 mb-20">
                                        <label for="zip" class="billing-label"><?php echo app('translator')->get('Zip Code'); ?>:</label>
                                        <input type="text" class="form-control custom--style" id="zip" name="zip" placeholder="<?php echo app('translator')->get('Zip Code'); ?>" value="<?php echo e(@$user->address->zip); ?>" required>
                                    </div>

                                    <div class="col-md-12 mb-20">
                                        <label for="address" class="billing-label"><?php echo app('translator')->get('Address'); ?>:</label>
                                        <textarea type="text" rows="2" class="form-control custom--style" id="address" name="address" placeholder="<?php echo app('translator')->get('Address'); ?>" required><?php echo e(@$user->address->address); ?></textarea>
                                    </div>

                                    <div class="col-md-12 ml-auto text-right mb-20">
                                        <button type="submit" class="bill-button w-unset text-white"><?php echo app('translator')->get('Update Profile'); ?></button>
                                    </div>

                                </form>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script>
        'use strict';
        (function($){
            $('select[name=country]').val("<?php echo e(@$user->address->country); ?>");

            $("#file-input").on('change',function() {
                readURL(this);
            });

            function readURL(input) {
                if (input.files && input.files[0]) {
                    var reader = new FileReader();
                    reader.onload = function(e) {
                        $('#imagePreview').attr('src', e.target.result);
                        $('#imagePreview').hide();
                        $('#imagePreview').fadeIn(650);
                    }
                    reader.readAsDataURL(input.files[0]);
                }
            }
        })(jQuery)

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/user/profile_setting.blade.php ENDPATH**/ ?>