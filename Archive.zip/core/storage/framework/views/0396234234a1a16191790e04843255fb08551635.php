<?php $__env->startSection('panel'); ?>



<div class="row mb-none-30">

    <div class="col-xl-6 col-md-6 mb-30">
        <div <?php echo e(gradient()); ?> class="widget bb--3 border--success b-radius--10 bg--white p-4 box--shadow2 has--link">
            <div class="widget__icon b-radius--rounded bg--success"><i class="las la-wallet"></i></div>
            <div class="widget__content">
                <p class="text-uppercase text-white"><?php echo app('translator')->get('Wallet Balance'); ?></p>
                <h1 class="text--white font-weight-bold">
                    <?php echo e($general->cur_sym.showAmount(seller()->balance)); ?>

                </h1> 
            </div>
        </div><!-- widget end -->
    </div>

    <div class="col-xl-6 col-md-6 mb-30">
        <div <?php echo e(gradient()); ?> class="widget bb--3 border--danger b-radius--10 bg--white p-4 box--shadow2 has--link">
            <div class="widget__icon b-radius--rounded bg--danger"><i class="las la-cart-arrow-down"></i></div>
            <div class="widget__content">
                <p class="text-uppercase text-white"><?php echo app('translator')->get('Pending Balance'); ?></p>
                <h1 class="text--white font-weight-bold">
                    <?php echo e($general->cur_sym.showAmount($pendingsettlement)); ?>

                </h1>
                 
            </div>
        </div><!-- widget end -->
    </div>

    <div class="col-xl-4 col-md-6 mb-30">
        <div <?php echo e(gradient()); ?> class="widget bb--3 border--dark b-radius--10 bg--white p-4 box--shadow2 has--link">
            <div class="widget__icon b-radius--rounded bg--dark"><i class="las la-cart-arrow-down"></i></div>
            <div class="widget__content">
                <p class="text-uppercase text-white"><?php echo app('translator')->get('Pending Orders'); ?></p>
                <h1 class="text--white font-weight-bold">
                  <?php echo e($order['pending']); ?>

                </h1>
                <p class="mt-10 text-right">
                    <a class="btn btn-sm btn--dark" href="<?php echo e(route('seller.order.to_deliver')); ?>"><?php echo app('translator')->get('View All'); ?>
                    </a>
                </p>
            </div>
        </div><!-- widget end -->
    </div>

    <div class="col-xl-4 col-md-6 mb-30">
        <div <?php echo e(gradient()); ?> class="widget bb--3 border--teal b-radius--10 bg--white p-4 box--shadow2 has--link">
            <div class="widget__icon b-radius--rounded bg--teal">
                <i class="las la-cart-arrow-down"></i>
            </div>
            <div class="widget__content">
                <p class="text-uppercase text-white"><?php echo app('translator')->get('Proccessing Orders'); ?></p>

                <h1 class="text--white font-weight-bold">
                   <?php echo e($order['processing']); ?>

                </h1>
                <p class="mt-10 text-right">
                    <a class="btn btn-sm bg--teal text-white" href="<?php echo e(route('seller.order.on_processing')); ?>"><?php echo app('translator')->get('View All'); ?>
                    </a>
                </p>
            </div>
        </div><!-- widget end -->
    </div>

    <div class="col-xl-4 col-md-6 mb-30">
        <div <?php echo e(gradient()); ?> class="widget bb--3 border--light-blue b-radius--10 bg--white p-4 box--shadow2 has--link">
            <div class="widget__icon b-radius--rounded bg--light-blue">
                <i class="las la-cart-arrow-down"></i>
            </div>
            <div class="widget__content">
                <p class="text-uppercase text-white"><?php echo app('translator')->get('Dispatched Orders'); ?></p>
                <h1 class="text--white font-weight-bold">
                    <?php echo e($order['dispatched']); ?>

                </h1>
                <p class="mt-10 text-right">
                    <a class="btn btn-sm bg--light-blue text-white" href="<?php echo e(route('seller.order.dispatched')); ?>"><?php echo app('translator')->get('View All'); ?>
                    </a>
                </p>
            </div>
        </div><!-- widget end -->
    </div>

    <div class="col-xl-4 col-md-6 mb-30">
        <div <?php echo e(gradient()); ?> class="widget bb--3 border--success b-radius--10 bg--white p-4 box--shadow2 has--link">
            <div class="widget__icon b-radius--rounded bg--success">
                <i class="las la-cart-arrow-down"></i>
            </div>

            <div class="widget__content">
                <p class="text-uppercase text-white"><?php echo app('translator')->get('Delivered Orders'); ?></p>
                <h1 class="text--white font-weight-bold">
                    <?php echo e($order['dispatched']); ?>

                </h1>

                <p class="mt-10 text-right">
                    <a class="btn btn-sm bg--success text--white" href="<?php echo e(route('seller.order.delivered')); ?>">
                        <?php echo app('translator')->get('View All'); ?>
                    </a>
                </p>
            </div>
        </div><!-- widget-two end -->
    </div>


    <div class="col-xl-4 col-md-6 mb-30">
        <div <?php echo e(gradient()); ?> class="widget bb--3 border--danger b-radius--10 bg--white p-4 box--shadow2 has--link">
            <div class="widget__icon b-radius--rounded bg--danger">
                <i class="las la-comment-slash"></i>
            </div>
            <div class="widget__content">
                <p class="text-uppercase text-white"><?php echo app('translator')->get('Cancelled Orders'); ?></p>
                <h1 class="text--white font-weight-bold">
                    <?php echo e($order['cancelled']); ?>

                </h1>
                <p class="mt-10 text-right">
                    <a class="btn btn-sm btn--danger" href="<?php echo e(route('seller.order.canceled')); ?>"><?php echo app('translator')->get('View All'); ?>
                    </a>
                </p>
            </div>
        </div><!-- widget end -->
    </div>

    <div class="col-xl-4 col-md-6 mb-30">
        <div <?php echo e(gradient()); ?> class="widget bb--3 border--deep-purple b-radius--10 bg--white p-4 box--shadow2 has--link">
            <div class="widget__icon b-radius--rounded bg--deep-purple">
                <i class="las la-shipping-fast"></i>
            </div>
            <div class="widget__content">
                <p class="text-uppercase text-white"><?php echo app('translator')->get('COD Orders'); ?></p>
                <h1 class="text--white font-weight-bold">
                    <?php echo e($order['cod']); ?>

                </h1>
                <p class="mt-10 text-right">
                    <a class="btn btn-sm bg--deep-purple text--white" href="<?php echo e(route('seller.order.cod')); ?>"><?php echo app('translator')->get('View All'); ?>
                    </a>
                </p>
            </div>
        </div><!-- widget end -->
    </div>
    <div class="col-xl-4 col-md-6 mb-30">
        <div <?php echo e(gradient()); ?> class="widget bb--3 border--indigo b-radius--10 bg--white p-4 box--shadow2 has--link">
            <div class="widget__icon b-radius--rounded bg--indigo">
                <i class="las la-tshirt"></i>
            </div>
            <div class="widget__content">
                <p class="text-uppercase text-white"><?php echo app('translator')->get('Approved Products'); ?></p>
                <h1 class="text--white font-weight-bold">
                    <?php echo e($product['approved']); ?>

                </h1>
                <p class="mt-10 text-right">
                    <a class="btn btn-sm bg--indigo text--white" href="<?php echo e(route('seller.products.all')); ?>"><?php echo app('translator')->get('View All'); ?>
                    </a>
                </p>
            </div>
        </div><!-- widget end -->
    </div>
    <div class="col-xl-4 col-md-6 mb-30">
        <div <?php echo e(gradient()); ?> class="widget bb--3 border--orange b-radius--10 bg--white p-4 box--shadow2 has--link">
            <div class="widget__icon b-radius--rounded bg--orange">
                <i class="las la-hourglass-end"></i>
            </div>
            <div class="widget__content">
                <p class="text-uppercase text-white"><?php echo app('translator')->get('Pending Products'); ?></p>
                <h1 class="text--white font-weight-bold">
                    <?php echo e($product['pending']); ?>

                </h1>
                <p class="mt-10 text-right">
                    <a class="btn btn-sm bg--orange text--white" href="<?php echo e(route('seller.products.pending')); ?>"><?php echo app('translator')->get('View All'); ?>
                    </a>
                </p>
            </div>
        </div><!-- widget end -->
    </div>
    <div class="col-xl-4 col-md-6 mb-30">
        <div <?php echo e(gradient()); ?> class="widget bb--3 border--black b-radius--10 bg--white p-4 box--shadow2 has--link">
            <div class="widget__icon b-radius--rounded bg--black">
                <i class="las la-file-invoice-dollar"></i>
            </div>
            <div class="widget__content">
                <p class="text-uppercase text-white"><?php echo app('translator')->get('Total Sold'); ?></p>
                <h1 class="text--white font-weight-bold">
                    <?php echo e($product['total_sold']); ?>

                </h1>
                <p class="mt-10 text-right">
                    <a class="btn btn-sm bg--black text--white" href="<?php echo e(route('seller.sell.log')); ?>"><?php echo app('translator')->get('View All'); ?>
                    </a>
                </p>
            </div>
        </div><!-- widget end -->
    </div>
</div><!-- row end-->

<div class="row mt-5 mb-none-30">
    <div class="col-md-12 mb-3">
        <h4><?php echo app('translator')->get('Sold Amount'); ?></h4>
    </div>
    <div class="col-xl-4 mb-30">
        <div class="widget-two box--shadow2 b-radius--5 bg--white">
          <i class="icon-7 overlay-icon text text--11"></i>
          <div class="widget-two__icon b-radius--5 bg--11">
            <i class="las la-money-bill"></i>
          </div>
          <div class="widget-two__content">
            <h2><?php echo e($general->cur_sym); ?><?php echo e(showAmount($sale['last_seven_days'])); ?></h2>
            <p><?php echo app('translator')->get('Last 7 Days'); ?></p>
          </div>
        </div><!-- widget-two end -->
    </div>

    <div class="col-xl-4 mb-30">
        <div class="widget-two box--shadow2 b-radius--5 bg--white">
          <i class="icon-15 overlay-icon text text--dark"></i>
          <div class="widget-two__icon b-radius--5 bg--15">
            <i class="las la-money-bill"></i>
          </div>
          <div class="widget-two__content">
            <h2><?php echo e($general->cur_sym); ?><?php echo e(showAmount($sale['last_fifteen_days'])); ?></h2>
            <p><?php echo app('translator')->get('Last 15 Days'); ?></p>
          </div>
        </div><!-- widget-two end -->
    </div>

    <div class="col-xl-4 mb-30">
        <div class="widget-two box--shadow2 b-radius--5 bg--white">
          <i class="icon-30 overlay-icon text text--danger"></i>
          <div class="widget-two__icon b-radius--5 bg--5">
            <i class="las la-money-bill"></i>
          </div>
          <div class="widget-two__content">
            <h2><?php echo e($general->cur_sym); ?><?php echo e(showAmount($sale['last_thirty_days'])); ?></h2>
            <p><?php echo app('translator')->get('Last 30 Days'); ?></p>
          </div>
        </div><!-- widget-two end -->
    </div>
</div>

<div class="row mt-50 mb-none-30">
    <div class="col-xl-6 mb-30">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title"><?php echo app('translator')->get('Monthly Withdrawal Report'); ?></h5>
                <div id="apex-bar-chart"> </div>
            </div>
        </div>
    </div>
    <div class="col-xl-6 mb-30">
        <div class="row mb-none-30">
            <div class="col-lg-12 col-sm-6 mb-30">
                <div class="widget-three box--shadow2 b-radius--5 bg--white">
                    <div class="widget-three__icon b-radius--rounded bg--success  box--shadow2">
                        <i class="las la-wallet"></i>
                    </div>
                    <div class="widget-three__content">
                        <h2 class="numbers"><?php echo e($general->cur_sym); ?><?php echo e(showAmount(seller()->balance)); ?></h2>
                        <p class="text--small"><?php echo app('translator')->get('In Wallet'); ?></p>
                    </div>
                </div><!-- widget-two end -->
            </div>
            <div class="col-lg-6 col-sm-6 mb-30">
                <div class="widget-three box--shadow2 b-radius--5 bg--white">
                    <div class="widget-three__icon b-radius--rounded bg--primary  box--shadow2">
                        <i class="las la-clipboard-check"></i>
                    </div>
                    <div class="widget-three__content">
                        <h2 class="numbers"><?php echo e($general->cur_sym); ?><?php echo e(showAmount($withdraw['total'])); ?></h2>
                        <p class="text--small"><?php echo app('translator')->get('Total Withdrawn'); ?></p>
                    </div>
                </div><!-- widget-two end -->
            </div>
            <div class="col-lg-6 col-sm-6 mb-30">
                <div class="widget-three box--shadow2 b-radius--5 bg--white">
                    <div class="widget-three__icon b-radius--rounded bg--warning  box--shadow2">
                        <i class="las la-hourglass-end"></i>
                    </div>
                    <div class="widget-three__content">
                        <h2 class="numbers"><?php echo e($withdraw['pending']); ?></h2>
                        <p class="text--small"><?php echo app('translator')->get('Pending Withdrawals'); ?></p>
                    </div>
                </div><!-- widget-two end -->
            </div>
        </div>
    </div>
</div>

<div class="row mt-5 mb-30">
    <div class="col-md-12">
        <div class="card b-radius--10 ">
            <div class="card-header">
                <h4><?php echo app('translator')->get('Latest Orders'); ?></h4>
            </div>
            <div class="card-body">
                <div class="table-responsive--md  table-responsive">
                    <table class="table table--light style--two">
                        <thead>
                            <tr>
                                <th class="text-left"><?php echo app('translator')->get('Order Date'); ?></th>
                                <th class="text-left"><?php echo app('translator')->get('Customer'); ?></th>
                                <th class="text-left"><?php echo app('translator')->get('Order ID'); ?></th>
                                <th class="text-right"><?php echo app('translator')->get('Amount'); ?></th>
                                <th><?php echo app('translator')->get('Status'); ?></th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            <?php $__empty_1 = true; $__currentLoopData = $latestOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Order Date'); ?>" class="text-left">
                                    <?php echo e(showDateTime($item->created_at, 'd M, Y')); ?>

                                </td>

                                <td data-label="<?php echo app('translator')->get('Customer'); ?>" class="text-left">
                                    <?php if($item->order->user): ?>
                                     <?php echo e($item->order->user->username); ?>

                                    <?php endif; ?>
                                </td>
                                <td data-label="<?php echo app('translator')->get('Order ID'); ?>" class="text-left">
                                    <?php echo e(@$item->order->order_number); ?>

                                </td>
                                <td data-label="<?php echo app('translator')->get('Amount'); ?>" class="text-right">
                                    <b><?php echo e($general->cur_sym.(showAmount($item->total_price))); ?></b>
                                </td>

                                <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                    <span class="badge
                                        <?php if($item->order->status == 0): ?>
                                            <?php echo e('badge--warning'); ?>

                                        <?php elseif($item->order->status == 1): ?>
                                            <?php echo e('badge--primary'); ?>


                                        <?php elseif($item->order->status == 2): ?>
                                            <?php echo e('badge--dark'); ?>

                                        <?php elseif($item->order->status == 3): ?>
                                            <?php echo e('badge--success'); ?>

                                        <?php elseif($item->order->status == 4): ?>
                                            <?php echo e('badge--danger'); ?>

                                        <?php endif; ?>
                                            ">

                                        <?php if($item->order->status == 0): ?>
                                        <?php echo e('Pending'); ?>

                                        <?php elseif($item->order->status == 1): ?>
                                        <?php echo e('Processing...'); ?>

                                        <?php elseif($item->order->status == 2): ?>
                                            <?php echo e('Dispatched'); ?>

                                        <?php elseif($item->order->status == 3): ?>
                                            <?php echo e('Delivered'); ?>

                                        <?php elseif($item->order->status == 4): ?>
                                            <?php echo e('Canceled'); ?>


                                        <?php endif; ?>
                                    </span>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-muted text-center" colspan="100%"><?php echo app('translator')->get('No order found'); ?></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
    <script src="<?php echo e(asset('assets/dashboard/js/vendor/apexcharts.min.js')); ?>"></script>

     <script>
            'use strict';
        // apex-bar-chart js
        var options = {
            series: [{
                name: 'Total Withdraw',
                data: [
                  <?php $__currentLoopData = $months; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e(showAmount(@$withdrawalMonth->where('months',$month)->first()->withdrawAmount)); ?>,
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                ]
            }],
            chart: {
                type: 'bar',
                height: 400,
                toolbar: {
                    show: false
                }
            },
            plotOptions: {
                bar: {
                    horizontal: false,
                    columnWidth: '50%',
                    endingShape: 'rounded'
                },
            },
            dataLabels: {
                enabled: false
            },
            stroke: {
                show: true,
                width: 2,
                colors: ['transparent']
            },
            xaxis: {
                categories: <?php echo json_encode($months, 15, 512) ?>,
            },
            yaxis: {
                title: {
                    text: "<?php echo e(__($general->cur_sym)); ?>",
                    style: {
                        color: '#7c97bb'
                    }
                }
            },
            grid: {
                xaxis: {
                    lines: {
                        show: false
                    }
                },
                yaxis: {
                    lines: {
                        show: false
                    }
                },
            },
            fill: {
                opacity: 1
            },
            tooltip: {
                y: {
                    formatter: function (val) {
                        return "<?php echo e(__($general->cur_sym)); ?>" + val + " "
                    }
                }
            }
        };

        var chart = new ApexCharts(document.querySelector("#apex-bar-chart"), options);
        chart.render();

    </script>
<?php $__env->stopPush(); ?>


<?php echo $__env->make('seller.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/seller/dashboard.blade.php ENDPATH**/ ?>