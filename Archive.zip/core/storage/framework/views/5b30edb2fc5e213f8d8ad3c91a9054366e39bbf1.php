<?php $__env->startSection('panel'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card b-radius--10 ">
            <div class="card-body p-0">
                <div class="row justify-content-end">
                    <div class="col-xl-3 mb-3">
                        <form action="" method="GET" class="pt-3 px-3">
                            <div class="input-group has_append">
                                <input type="text" name="search" class="form-control" placeholder="Order ID" value="<?php echo e(request()->search ?? ''); ?>">
                                <div class="input-group-append">
                                    <button class="btn btn--primary box--shadow1" id="search-btn" type="submit"><i class="fa fa-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <div class="table-responsive--md  table-responsive">
                    <table class="table table--light style--two">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('Order ID'); ?> | <?php echo app('translator')->get('Time'); ?></th>
                                <th><?php echo app('translator')->get('Customer'); ?></th>
                                <?php if(!request()->routeIs('admin.order.cod')): ?>
                                    <th><?php echo app('translator')->get('Payment Via'); ?></th>
                                <?php endif; ?>
                                <th class="text-right"><?php echo app('translator')->get('Amount'); ?></th>
                                <?php if(request()->routeIs('admin.order.index')): ?>
                                    <th><?php echo app('translator')->get('Status'); ?></th>
                                <?php endif; ?>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td data-label="<?php echo app('translator')->get('Order ID'); ?> | <?php echo app('translator')->get('Time'); ?>">
                                    <span class="font-weight-bold d-block text--primary"><?php echo e(@$item->order_number); ?></span>
                                    <?php echo e(showDateTime($item->created_at)); ?>

                                </td>

                                <td data-label="<?php echo app('translator')->get('Customer'); ?>">
                                    <a href="<?php echo e(route('admin.users.detail', $item->user->id)); ?>"><?php echo e($item->user->username); ?></a>
                                </td>

                                <?php if(!request()->routeIs('admin.order.cod')): ?>
                                    <td data-label="<?php echo app('translator')->get('Payment Via'); ?>">
                                        <?php if($item->payment_status==2): ?>
                                            <strong class="text-warning"><abbr data-toggle="tooltip" title="<?php echo app('translator')->get('Cash On Delivery'); ?>">
                                                <?php echo e(@$deposit->gateway->name??trans('COD')); ?></abbr>
                                            </strong>
                                        <?php elseif($item->deposit): ?>
                                            <strong class="text-primary"><?php echo e($item->deposit->gateway->name); ?></strong>
                                        <?php endif; ?>
                                    </td>
                                <?php endif; ?>

                                <td data-label="<?php echo app('translator')->get('Amount'); ?>" class="text-right">
                                    <b><?php echo e($general->cur_sym.($item->total_amount)); ?></b>
                                </td>
                                <?php if(request()->routeIs('admin.order.index')): ?>

                                <td data-label="<?php echo app('translator')->get('Status'); ?>" class="text-center">
                                    <?php echo $item->statusBadge(); ?>
                                </td>
                                <?php endif; ?>

                                <td data-label="<?php echo app('translator')->get('Action'); ?>">

                                    <a href="<?php echo e(route('admin.order.details', $item->id)); ?>" data-toggle="tooltip" title="<?php echo app('translator')->get('View'); ?>" class="icon-btn btn--dark mr-1">
                                        <i class="la la-desktop"></i>
                                    </a>

                                    <?php if(!request()->routeIs('admin.order.notpaid')): ?>
                                    <button type="button" class="approveBtn icon-btn btn--success <?php echo e($item->status >= 3?'disabled':''); ?> text-white" data-toggle="tooltip" data-action="<?php echo e($item->status+1); ?>" data-id='<?php echo e($item->id); ?>'
                                    title="<?php if($item->status == 0): ?> <?php echo app('translator')->get('Mark as Processing'); ?><?php elseif($item->status == 1): ?><?php echo app('translator')->get('Mark as Dispatched'); ?>
                                    <?php elseif($item->status == 2): ?> <?php echo app('translator')->get('Mark as Delivered'); ?><?php endif; ?>">
                                        <i class="la la-check"></i>
                                    </button>

                                    <button type="button" class="<?php echo e(($item->status==0 || $item->status==4)?'approveBtn':''); ?> icon-btn btn--<?php echo e($item->status==4?'warning':'danger'); ?> <?php echo e(($item->status==0 || $item->status==4)?'':'disabled'); ?>" data-toggle="tooltip" data-action="<?php echo e(($item->status==4)?0:4); ?>" data-id='<?php echo e($item->id); ?>' title="<?php echo e($item->status==4?__('Retake'):__('Cancel')); ?>">
                                        <i class="la la-<?php echo e($item->status==4?'reply':'ban'); ?>"></i>
                                    </button>

                                    <?php else: ?>

                                    <button type="button" class="icon-btn btn--danger" data-toggle="modal" data-target="#deleteModal" data-id='<?php echo e($item->id); ?>'>
                                        <i class="la la-trash"></i>
                                    </button>

                                    <?php endif; ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <?php if($orders->hasPages()): ?>
                <div class="card-footer py-4">
                    <?php echo e(paginateLinks($orders)); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<div class="modal fade" id="approveModal" tabindex="-1" role="dialog">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
        <form action="<?php echo e(route('admin.order.status')); ?>" method="POST" id="deliverPostForm">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="id" id="oid">
            <input type="hidden" name="action" id="action">
                <div class="modal-header">
                    <h5 class="modal-title" id="approveModalLabel"><?php echo app('translator')->get('Confirmation Alert'); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p class="text-bold"></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn--dark" data-dismiss="modal"><?php echo app('translator')->get('No'); ?></button>
                    <button type="submit" class="btn btn--success"><?php echo app('translator')->get('Yes'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('script'); ?>
<script>
    'use strict';
    (function($){
        $('.approveBtn').on('click', function () {
            var modal = $('#approveModal');
            $('#oid').val($(this).data('id'));
            var action = $(this).data('action');

            $('#action').val(action);

            if(action == 1){
                $('.text-bold').text("<?php echo app('translator')->get('Are you sure to mark the order as processing?'); ?>");
            }else if(action ==2){
                $('.text-bold').text("<?php echo app('translator')->get('Are you sure to mark the order as dispatched?'); ?>");
            }else if(action ==3){
                $('.text-bold').text("<?php echo app('translator')->get('Are you sure to mark the order as delivered?'); ?>");
            }else if(action ==4){
                $('.text-bold').text("<?php echo app('translator')->get('Are you sure to cancel this order?'); ?>");
            }else{
                $('.text-bold').text("<?php echo app('translator')->get('Are you sure to retake this order?'); ?>");
            }
            modal.modal('show');
        });
    })(jQuery)

</script>
<?php $__env->stopPush(); ?>



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/admin/order/ordered.blade.php ENDPATH**/ ?>