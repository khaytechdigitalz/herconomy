<?php $__env->startSection('content'); ?>
<div class="checkout-section padding-bottom padding-top">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-lg-5">
                <div class="card border-0 shadow-md">
                    <div class="card-header bg-transparent d-flex justify-content-between">
                        <img src="<?php echo e($data->gatewayCurrency()->methodImage()); ?>" class="card-img-top w-25" <?php echo app('translator')->get('gateway-image'); ?>">
                        <h3 class="align-self-center cl-1">
                            <?php echo app('translator')->get('Payment Preview'); ?>
                        </h3>
                    </div>
                    <div class="card-body">

                        <ul class="list-group list-group-flush text-center ">
                            <li class="list-group-item d-flex justify-content-between align-items-center"><?php echo app('translator')->get('Amount'); ?>: <strong><?php echo e(showAmount($data->amount)); ?> <?php echo e($general->cur_text); ?></strong></li>

                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo app('translator')->get('Charge'); ?>:
                                <span><strong><?php echo e(showAmount($data->charge)); ?></strong> <?php echo e($general->cur_text); ?></span>
                            </li>

                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo app('translator')->get('Payable'); ?>: <strong><?php echo e(showAmount($data->amount + $data->charge)); ?> <?php echo e($general->cur_text); ?></strong>
                            </li>

                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo app('translator')->get('Conversion Rate'); ?>: <strong>1 <?php echo e($general->cur_text); ?> = <?php echo e(showAmount($data->rate)); ?>  <?php echo e($data->baseCurrency()); ?></strong>
                            </li>

                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                <?php echo app('translator')->get('In'); ?> <?php echo e($data->baseCurrency()); ?>:
                                <strong><?php echo e(showAmount($data->final_amo)); ?></strong>
                            </li>

                            <?php if($data->gateway->crypto==1): ?>
                                <li class="list-group-item"><?php echo app('translator')->get("Conversion with $data->method_currency and final value will Show on next step"); ?>
                                </li>
                            <?php endif; ?>
                            <?php if( 1000 >$data->method_code): ?>
                            <li class="list-group-item p-0">
                                <a href="<?php echo e(route('user.deposit.confirm')); ?>" class="cmn-btn btn-block"><?php echo app('translator')->get('Pay Now'); ?></a>
                            </li>
                            <?php else: ?>
                                <li class="list-group-item p-0">
                                    <a href="<?php echo e(route('user.deposit.manual.confirm')); ?>" class="cmn-btn btn-block"><?php echo app('translator')->get('Pay Now'); ?></a>
                                </li>
                            <?php endif; ?>
                        </ul>

                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
    <li><a href="<?php echo e(route('products')); ?>"><?php echo app('translator')->get('Products'); ?></a></li>
    <li><a href="<?php echo e(route('shopping-cart')); ?>"><?php echo app('translator')->get('Cart'); ?></a></li>
    <li><a href="<?php echo e(route('user.checkout')); ?>"><?php echo app('translator')->get('Checkout'); ?></a></li>
    <li><a href="<?php echo e(route('user.deposit')); ?>"><?php echo app('translator')->get('Payment'); ?></a></li>
<?php $__env->stopPush(); ?>


<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/user/payment/preview.blade.php ENDPATH**/ ?>