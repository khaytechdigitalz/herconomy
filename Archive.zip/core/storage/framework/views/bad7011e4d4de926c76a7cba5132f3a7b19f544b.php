<?php $__env->startSection('panel'); ?>
<div class="row">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-body p-0">
                <div class="table-responsive--md table-responsive">
                    <table class="table table--light style--two">
                        <thead>
                            <tr>
                                <th><?php echo app('translator')->get('S.N.'); ?></th>
                                <th><?php echo app('translator')->get('Name'); ?></th>
                                <th><?php echo app('translator')->get('Code'); ?></th>
                                <th><?php echo app('translator')->get('Discount Type'); ?></th>
                                <th><?php echo app('translator')->get('Status'); ?></th>
                                <th><?php echo app('translator')->get('Expire Date'); ?></th>
                                <th><?php echo app('translator')->get('Action'); ?></th>
                            </tr>
                        </thead>
                        <tbody class="list">
                            <?php $__empty_1 = true; $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td data-label="<?php echo app('translator')->get('S.N.'); ?>"><?php echo e($loop->iteration); ?></td>
                                    <td data-label="<?php echo app('translator')->get('Name'); ?>">
                                        <?php echo e($coupon->coupon_name); ?>

                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Code'); ?>">
                                        <?php echo e($coupon->coupon_code); ?>

                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Discount'); ?>">
                                        <?php if($coupon->discount_type == 1): ?>
                                        <span class="text--small badge font-weight-normal badge--primary"> <?php echo e($coupon->couponType); ?></span>
                                        <?php else: ?>
                                        <span class="text--small badge font-weight-normal badge--dark"> <?php echo e($coupon->couponType); ?></span>
                                        <?php endif; ?>

                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Status'); ?>">

                                        <label class="switch">
                                            <input type="checkbox" class="change_status" name="top" <?php echo e($coupon->status?'checked':''); ?> data-id=<?php echo e($coupon->id); ?>>
                                            <span class="slider round"></span>
                                        </label>

                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Expire Date'); ?>" class="<?php echo e($coupon->end_date < $now?'text--danger':''); ?>">
                                       <?php echo e(showDateTime($coupon->end_date, 'd M, Y')); ?>

                                    </td>
                                    <td data-label="<?php echo app('translator')->get('Action'); ?>">
                                        <a href="<?php echo e(route('admin.coupon.edit', $coupon->id)); ?>" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('Edit'); ?>"class="icon-btn edit-btn">
                                            <i class="la la-pencil"></i>
                                        </a>

                                        <button type="button" data-toggle="tooltip" data-placement="top" title="<?php echo app('translator')->get('Delete'); ?>"
                                            class="icon-btn btn--danger delete-btn ml-1"
                                            data-type="delete" data-id='<?php echo e($coupon->id); ?>'>
                                            <i class="las la-trash"></i>
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-muted text-center" colspan="100%"><?php echo e(__($emptyMessage)); ?></td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<div class="modal fade" id="deleteModal" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <form action="" method="POST" id="deletePostForm">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title text-capitalize"></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body"></div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-sm btn--dark" data-dismiss="modal"><?php echo app('translator')->get('No'); ?></button>
                    <button type="submit" class="btn btn-sm btn--danger"><?php echo app('translator')->get('Yes'); ?></button>
                </div>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
    <a href="<?php echo e(route('admin.coupon.create')); ?>" class="btn btn-sm btn--success box--shadow1 text--small"> <i class="las la-plus"></i> <?php echo app('translator')->get('Add New'); ?></a>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('script-lib'); ?>
    <script src="<?php echo e(asset('assets/dashboard/js/bootstrap-iconpicker.bundle.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style-lib'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/bootstrap-iconpicker.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>

    <script>
        'use strict';
        (function($){
            $('.delete-btn').on('click', function ()
            {
                var modal   = $('#deleteModal');
                var id      = $(this).data('id');
                var type    = $(this).data('type');
                var form    = document.getElementById('deletePostForm');
                modal.find('.modal-title').text('<?php echo e(trans("Delete Coupon")); ?>');
                modal.find('.modal-body').text('<?php echo e(trans("Are you sure to delete this coupon?")); ?>');
                form.action = '<?php echo e(route('admin.coupon.delete', '')); ?>' + '/' + id;
                modal.modal('show');

            });

            $('.change_status').on('change',function () {
                var id = $(this).data('id');
                var mode = $(this).prop('checked');

                var data = {
                    'id': id
                };
                $.ajax({
                    headers: {
                        "X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>",
                    },
                    url: "<?php echo e(route('admin.coupon.status')); ?>",
                    method: 'POST',
                    data: data,
                    success: function (result) {
                        notify('success', result.success);
                    }
                });
            });
        })(jQuery)

    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/admin/coupons/index.blade.php ENDPATH**/ ?>