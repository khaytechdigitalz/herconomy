<?php $__env->startSection('panel'); ?>

    <div class="card">
        <div class="card-body">
            <form action="" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group row">
                    <div class="col-md-3">
                        <label class=" font-weight-bold"><?php echo app('translator')->get('Image'); ?></label>
                    </div>
                    <div class="col-md-9">
                        <div class="payment-method-item">
                            <div class="payment-method-header">
                                <div class="thumb">
                                    <div class="avatar-preview">
                                        <div class="profilePicPreview" style="background-image: url(<?php echo e(getImage(imagePath()['seller']['profile']['path'].'/'.$seller->image,imagePath()['seller']['profile']['size'])); ?>)">

                                        </div>
                                    </div>
                                    <div class="avatar-edit">
                                        <input type="file" name="image" class="profilePicUpload" id="image" accept=".png, .jpg, .jpeg"/>
                                        <label for="image" class="bg--primary"><i class="la la-pencil"></i></label>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <small><?php echo app('translator')->get('Supported files'); ?>: <b><?php echo app('translator')->get('jpeg'); ?>, <?php echo app('translator')->get('jpg'); ?>, <?php echo app('translator')->get('png'); ?>.</b> <?php echo app('translator')->get('Image will be resized into 400x400px'); ?> </small>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label class="font-weight-bold"><?php echo app('translator')->get('First Name'); ?></label>
                    </div>
                    <div class="col-md-9">
                        <input class="form-control" type="text" name="firstname" value="<?php echo e(old('firstname')??$seller->firstname); ?>" >
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label class=" font-weight-bold"><?php echo app('translator')->get('Last Name'); ?></label>
                    </div>
                    <div class="col-md-9">
                        <input class="form-control" type="text" name="lastname" value="<?php echo e(old('lastname')??$seller->lastname); ?>">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label class=" font-weight-bold"><?php echo app('translator')->get('Email'); ?></label>
                    </div>
                    <div class="col-md-9">
                        <input class="form-control bg--white" type="email" value="<?php echo e($seller->email); ?>" readonly>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label class=" font-weight-bold"><?php echo app('translator')->get('Mobile'); ?></label>
                    </div>
                    <div class="col-md-9">
                        <input class="form-control bg--white" type="number" value="<?php echo e(old('mobile')??$seller->mobile); ?>" readonly>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label class=" font-weight-bold"><?php echo app('translator')->get('Country'); ?></label>
                    </div>
                    <div class="col-md-9">
                        <input class="form-control bg--white" type="text" value="<?php echo e(@$seller->address->country); ?>" readonly>
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label class=" font-weight-bold"><?php echo app('translator')->get('State'); ?></label>
                    </div>
                    <div class="col-md-9">
                        <input class="form-control" type="text" name="state" value="<?php echo e(old('state')??$seller->address->state); ?>">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label class=" font-weight-bold"><?php echo app('translator')->get('City'); ?></label>
                    </div>
                    <div class="col-md-9">
                        <input class="form-control" type="text" name="city" value="<?php echo e(old('city')??$seller->address->city); ?>">
                    </div>
                </div>

                <div class="form-group row">
                    <div class="col-md-3">
                        <label class=" font-weight-bold"><?php echo app('translator')->get('Zip Code'); ?></label>
                    </div>
                    <div class="col-md-9">
                        <input class="form-control" type="number" name="zip" value="<?php echo e(old('zip')??$seller->address->zip); ?>">
                    </div>
                </div>


                <div class="form-group row">
                    <div class="col-md-3">
                        <label class=" font-weight-bold"><?php echo app('translator')->get('Address'); ?></label>
                    </div>

                    <div class="col-md-9">
                        <textarea class="form-control" name="address"><?php echo e(old('address')??$seller->address->address); ?></textarea>
                    </div>
                </div>

                <div class="form-group">
                    <button type="submit" class="btn btn--primary btn-block btn-lg"><?php echo app('translator')->get('Save Changes'); ?></button>
                </div>


            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('seller.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/seller/profile.blade.php ENDPATH**/ ?>