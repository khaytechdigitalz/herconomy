<!-- Featured Section Starts Here -->
<div class="featured-section padding-bottom-half padding-top-half oh">
    <div class="container">
        <div class="section-header-2">
            <h3 class="title"><?php echo app('translator')->get('Our Latest Products'); ?></h3>
        </div>
        <div class="row g-4">
            <?php $__currentLoopData = $latestProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                if($item->offer && $item->offer->activeOffer){
                    $discount = calculateDiscount($item->offer->activeOffer->amount, $item->offer->activeOffer->discount_type, $item->base_price);
                }else $discount = 0;
                $wCk = checkWishList($item->id);
                $cCk = checkCompareList($item->id);
            ?>
            <div class="col-sm-6 col-xl-3 col-6">
                <div class="product-item-2 m-0">
                    <div class="product-item-2-inner wish-buttons-in">
                        <ul class="wish-react">
                            <li>
                                <a href="javascript:void(0)" title="<?php echo app('translator')->get('Add To Wishlist'); ?>" class="add-to-wish-list <?php echo e($wCk?'active':''); ?>" data-id="<?php echo e($item->id); ?>"><i class="lar la-heart"></i></a>
                            </li>
                            <li>

                                <a href="javascript:void(0)" title=" <?php echo app('translator')->get('Compare'); ?>" class="add-to-compare <?php echo e($cCk?'active':''); ?>" data-id="<?php echo e($item->id); ?>"><i class="las la-sync-alt"></i></a>
                            </li>
                        </ul>
                        <div class="product-thumb">
                            <a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>">
                                <img src="<?php echo e(getImage(imagePath()['product']['path'].'/thumb_'.@$item->main_image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('flash'); ?>">
                            </a>
                        </div>
                        <div class="product-content">
                            <div class="product-before-content">
                                <h6 class="title">
                                    <a href="<?php echo e(route('product.detail', ['id'=>$item->id, 'slug'=>slug($item->name)])); ?>"><?php echo e(__($item->name)); ?></a>
                                </h6>
                                <small class="text-success"><b>Up to <?php echo e(cashback()); ?> Cashback</b></small>

                                <div class="ratings-area justify-content-between">
                                    <div class="ratings">
                                        <?php echo displayAvgRating($item->reviews) ?>
                                    </div>
                                    

                                    <span class="ml-2 mr-auto">(<?php echo e($item->reviews->count()); ?>)</span>
                                    <div class="price">
                                        <?php if($discount > 0): ?>
                                        <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price - $discount, 2)); ?>

                                        <del><?php echo e(getAmount($item->base_price, 2)); ?></del>
                                        <?php else: ?>
                                        <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price, 2)); ?>

                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="product-after-content">
                                <button data-product="<?php echo e($item->id); ?>" class="cmn-btn btn-sm quick-view-btn">
                                    <?php echo app('translator')->get('View'); ?>
                                </button>
                                <div class="price">
                                    <?php if($discount > 0): ?>
                                    <?php echo e($general->cur_sym); ?><?php echo e($item->base_price - $discount); ?>

                                    <del><?php echo e(getAmount($item->base_price, 2)); ?></del>
                                    <?php else: ?>
                                    <?php echo e($general->cur_sym); ?><?php echo e(getAmount($item->base_price, 2)); ?>

                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
</div>
<!-- Featured Section Ends Here -->
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/sections/latest_products.blade.php ENDPATH**/ ?>