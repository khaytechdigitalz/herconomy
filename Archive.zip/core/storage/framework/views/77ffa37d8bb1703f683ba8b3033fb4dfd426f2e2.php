<li>
    <a href="<?php echo e(route('products.category', ['id'=>$subcategory->id, 'slug'=>slug($subcategory->name)])); ?>">
        <?php echo e(__($subcategory->name)); ?>

    </a>

    <?php if($subcategory->allSubcategories && $subcategory->allSubcategories->count() >0): ?>
    <span class="open-links"></span>
        <ul class="category-sublink">
            <?php $__currentLoopData = $subcategory->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $childCategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make($activeTemplate.'partials.menu_subcategories', ['subcategory' => $childCategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    <?php endif; ?>
</li>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/partials/menu_subcategories.blade.php ENDPATH**/ ?>