<div class="top-content">
    <a href="<?php echo e(route('home')); ?>" class="logo">
        <img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo_2.png', )); ?>" alt="<?php echo app('translator')->get('logo'); ?>">
    </a>
    <span class="side-sidebar-close-btn"><i class="las la-times"></i></span>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/partials/side_modal_logo.blade.php ENDPATH**/ ?>