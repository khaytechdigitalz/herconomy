<?php $__env->startSection('content'); ?>
<div class="dashboard-section padding-bottom padding-top">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $gatewayCurrency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-2 col-md-3 mb-4">
                    <div class="card">
                        <h5 class="card-header p-1">
                            <img src="<?php echo e($data->methodImage()); ?>" class="card-img-top" alt="<?php echo e(__($data->name)); ?>">
                        </h5>
                        <div class="card-body p-1">
                            <form action="<?php echo e(route('user.deposit.insert')); ?> " method="POST">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="currency" class="edit-currency" value="<?php echo e($data->currency); ?>">
                                <input type="hidden" name="method_code" class="edit-method-code" value="<?php echo e($data->method_code); ?>">
                                <button type="submit" class="cmn-btn btn-block"><?php echo app('translator')->get('Pay Now'); ?></button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make($activeTemplate.'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/user/payment/deposit.blade.php ENDPATH**/ ?>