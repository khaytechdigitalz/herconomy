<?php
    $sidebar = sellerSidebarVariation();
?>

<div class="sidebar <?php echo e($sidebar['selector']); ?> <?php echo e($sidebar['sidebar']); ?> <?php echo e(@$sidebar['overlay']); ?> <?php echo e(@$sidebar['opacity']); ?>" data-background="<?php echo e(getImage('assets/dashboard/images/sidebar/4.jpg')); ?>">
    <button class="res-sidebar-close-btn"><i class="las la-times"></i></button>
    <div class="sidebar__inner">
        <div class="sidebar__logo">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="sidebar__main-logo">
                <img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/logo_2.png')); ?>" alt="<?php echo app('translator')->get('image'); ?>">
            </a>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="sidebar__logo-shape">
                <img src="<?php echo e(getImage(imagePath()['logoIcon']['path'] .'/favicon.png')); ?>" alt="<?php echo app('translator')->get('image'); ?>">
            </a>
            <button type="button" class="navbar__expand"></button>
        </div>

        <div class="sidebar__menu-wrapper" id="sidebar__menuWrapper">
            <ul class="sidebar__menu">

                <li class="sidebar-menu-item bg--white mb-2">
                    <span class="menu-title nav-link font-weight-bold <?php if(seller()->balance> 0): ?>text--success <?php else: ?> text--danger <?php endif; ?>"><?php echo app('translator')->get('Current Balance'); ?>: <?php echo e($general->cur_sym.showAmount(seller()->balance)); ?></span>
                </li>

                <li class="sidebar-menu-item <?php echo e(menuActive('seller.home')); ?>">
                    <a href="<?php echo e(route('seller.home')); ?>" class="nav-link ">
                        <i class="menu-icon la la-dashboard"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Dashboard'); ?></span>
                    </a>
                </li>

                <li class="sidebar-menu-item <?php echo e(menuActive('seller.shop*')); ?>">
                    <a href="<?php echo e(route('seller.shop')); ?>" class="nav-link ">
                        <i class="menu-icon las la-store-alt"></i>
                        <span class="menu-title"><?php echo app('translator')->get('My Shop'); ?></span>
                    </a>
                </li>
                <li class="sidebar-menu-item <?php echo e(menuActive('seller.cashback')); ?>">
                    <a href="<?php echo e(route('seller.cashback')); ?>" class="nav-link ">
                        <i class="menu-icon las la-gift"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Cashback'); ?></span>
                    </a>
                </li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive('seller.products*', 3)); ?>">
                        <i class="la la-product-hunt menu-icon"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Manage Product'); ?></span>
                    </a>

                    <div class="sidebar-submenu <?php echo e(menuActive('seller.products*', 2)); ?> ">
                        <ul>
                            <li class="sidebar-menu-item <?php echo e(menuActive('seller.products.all')); ?>">
                                <a class="nav-link" href="<?php echo e(route('seller.products.all')); ?>">
                                    <i class="menu-icon las la-tshirt"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('All Products'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('seller.products.pending')); ?>">
                                <a class="nav-link" href="<?php echo e(route('seller.products.pending')); ?>">
                                    <i class="menu-icon las la-hourglass"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Pending Products'); ?></span>

                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('seller.products.reviews')); ?>">
                                <a class="nav-link" href="<?php echo e(route('seller.products.reviews')); ?>">
                                    <i class="menu-icon las la-star"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Product Reviews'); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive('seller.order*',3)); ?>">
                        <i class="las la-money-bill menu-icon"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Orders'); ?></span>
                        <?php if($pending_orders_count > 0 || $processing_orders_count || $dispatched_orders_count > 0): ?>
                        <span class="menu-badge pill bg--primary ml-auto">
                            <i class="las la-bell"></i>
                        </span>
                        <?php endif; ?>
                    </a>

                    <div class="sidebar-submenu <?php echo e(menuActive('seller.order*',2)); ?> ">
                        <ul>
                            <li class="sidebar-menu-item <?php echo e(menuActive('seller.order.index')); ?>">
                                <a class="nav-link" href="<?php echo e(route('seller.order.index')); ?>">
                                    <i class="menu-icon las la-list-ol"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('All Orders'); ?></span>

                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('seller.order.to_deliver')); ?>">
                                <a class="nav-link" href="<?php echo e(route('seller.order.to_deliver')); ?>">
                                    <i class="menu-icon las la-pause-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Pending Orders'); ?></span>
                                    <?php if($pending_orders_count > 0): ?>
                                     <span class="badge bg--primary badge-pill ml-2"><i class="fas fa-exclamation"></i></span>
                                    <?php endif; ?>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('seller.order.on_processing')); ?>">
                                <a class="nav-link" href="<?php echo e(route('seller.order.on_processing')); ?>">
                                    <i class="menu-icon las la-spinner"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Processing Orders'); ?></span>
                                    <?php if($processing_orders_count > 0): ?>
                                    <span class="badge bg--primary badge-pill ml-2"><i class="fas fa-exclamation"></i></span>
                                    <?php endif; ?>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('seller.order.dispatched')); ?>">
                                <a class="nav-link" href="<?php echo e(route('seller.order.dispatched')); ?>">
                                    <i class="menu-icon las la-shopping-basket"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Dispatched Orders'); ?></span>
                                    <?php if($dispatched_orders_count > 0): ?>
                                    <span class="badge bg--primary badge-pill ml-2"><i class="fas fa-exclamation"></i></span>
                                    <?php endif; ?>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('seller.order.delivered')); ?>">
                                <a class="nav-link" href="<?php echo e(route('seller.order.delivered')); ?>">
                                    <i class="menu-icon las la-check-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Delivered Orders'); ?> </span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('seller.order.canceled')); ?>">
                                <a class="nav-link" href="<?php echo e(route('seller.order.canceled')); ?>">
                                    <i class="menu-icon las la-times-circle"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Canceled Orders'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('seller.order.cod')); ?>">
                                <a class="nav-link" href="<?php echo e(route('seller.order.cod')); ?>">
                                    <i class="menu-icon las la-hand-holding-usd"></i>
                                    <span class="menu-title"><abbr data-toggle="tooltip" title="<?php echo app('translator')->get('Cash On Delivery'); ?>"><?php echo e(@$deposit->gateway->name??trans('COD')); ?></abbr> <?php echo app('translator')->get('Orders'); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="sidebar-menu-item <?php echo e(menuActive('seller.sell.log')); ?>">
                    <a class="nav-link" href="<?php echo e(route('seller.sell.log')); ?>">
                        <i class="menu-icon las la-file-invoice-dollar"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Sales Log'); ?></span>
                    </a>
                </li>

                <li class="sidebar-menu-item <?php echo e(menuActive('seller.trx.log')); ?>">
                    <a class="nav-link" href="<?php echo e(route('seller.trx.log')); ?>">
                        <i class="menu-icon las la-exchange-alt"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Transaction Log'); ?></span>
                    </a>
                </li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive('seller.settlement*', 3)); ?>">
                        <i class="menu-icon la la-wallet"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Settlement'); ?></span>
                    </a>
                    <div class="sidebar-submenu <?php echo e(menuActive('seller.settlement*', 2)); ?> ">
                        <ul>
                            <li class="sidebar-menu-item <?php echo e(menuActive(['seller.settlement.settings'])); ?>">
                                <a class="nav-link" href="<?php echo e(route('seller.settlement.settings')); ?>">
                                    <i class="menu-icon la la-money"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Settlement Settings'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('seller.settlement.history')); ?>">
                                <a class="nav-link" href="<?php echo e(route('seller.settlement.history')); ?>">
                                    <i class="menu-icon las la-history"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Settlement Log'); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="sidebar-menu-item sidebar-dropdown">
                    <a href="javascript:void(0)" class="<?php echo e(menuActive('seller.withdraw*', 3)); ?>">
                        <i class="menu-icon la la-money"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Withdraw'); ?></span>
                    </a>
                    <div class="sidebar-submenu <?php echo e(menuActive('seller.withdraw*', 2)); ?> ">
                        <ul>
                            <li class="sidebar-menu-item <?php echo e(menuActive(['seller.withdraw.money','seller.withdraw.preview'])); ?>">
                                <a class="nav-link" href="<?php echo e(route('seller.withdraw.money')); ?>">
                                    <i class="menu-icon la la-money"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Withdraw Money'); ?></span>
                                </a>
                            </li>

                            <li class="sidebar-menu-item <?php echo e(menuActive('seller.withdraw.history')); ?>">
                                <a class="nav-link" href="<?php echo e(route('seller.withdraw.history')); ?>">
                                    <i class="menu-icon las la-history"></i>
                                    <span class="menu-title"><?php echo app('translator')->get('Withdrawal History'); ?></span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>

                <li class="sidebar-menu-item <?php echo e(menuActive('seller.twofactor')); ?>">
                    <a class="nav-link" href="<?php echo e(route('seller.twofactor')); ?>">
                        <i class="menu-icon la la-shield"></i>
                        <span class="menu-title"><?php echo app('translator')->get('2FA Security'); ?></span>
                    </a>
                </li>

                <li class="sidebar-menu-item <?php echo e(menuActive(['seller.ticket*'])); ?>">
                    <a class="nav-link" href="<?php echo e(route('seller.ticket.index')); ?>">
                        <i class="menu-icon las la-headset"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Support'); ?></span>
                    </a>
                </li>

                <li class="sidebar-menu-item">
                    <a class="nav-link" href="<?php echo e(route('seller.logout')); ?>">
                        <i class="menu-icon las la-sign-out-alt"></i>
                        <span class="menu-title"><?php echo app('translator')->get('Log Out'); ?></span>
                    </a>
                </li>
            </ul>


            <div class="text-center mb-3 text-uppercase">
                <span class="text--primary"><?php echo e(__(systemDetails()['name'])); ?></span>
                <span class="text--success"><?php echo app('translator')->get('V'); ?><?php echo e(systemDetails()['version']); ?> </span>
            </div>
        </div>
    </div>
</div>
<!-- sidebar end -->


<?php $__env->startPush('style'); ?>
    <style>
        .sidebar[class*="bg--"] .sidebar__menu .sidebar-submenu .sidebar-menu-item:hover a .menu-title {
            color: inherit;
        }

        .sidebar[class*="overlay--white"] .sidebar__menu .sidebar-menu-item.active > a {
            background-color: rgb(209 209 209);
        }
    </style>
<?php $__env->stopPush(); ?>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/seller/partials/sidenav.blade.php ENDPATH**/ ?>