<div class="category-link-wrapper d-none d-lg-block">
    <h6 class="category__header"><?php echo app('translator')->get('Categories'); ?></h6>
    <ul class="category-link d-none d-lg-block">
        <?php $__currentLoopData = $allCategories->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <a href="<?php echo e(route('products.category', ['id'=>$category->id, 'slug'=>slug($category->name)])); ?>">
                    <?php echo e($category->name); ?>

                </a>
                <?php if($category->allSubcategories->count()>0): ?>
                <ul class="category-sublink">
                    <?php $__currentLoopData = $category->allSubcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo $__env->make($activeTemplate.'partials.menu_subcategories', ['subcategory' => $subcategory], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php endif; ?>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if($allCategories->count()>10): ?>
            <li> <a href="<?php echo e(route('categories')); ?>"><?php echo app('translator')->get('View All'); ?></a></li>
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/partials/left_category_menu.blade.php ENDPATH**/ ?>