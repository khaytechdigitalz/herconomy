<?php $__env->startSection('panel'); ?>

<div class="row justify-content-center">

    <div class="loader-container text-center d-none">
        <span class="loader">
            <i class="fa fa-circle-notch fa-spin" aria-hidden="true"></i>
        </span>
    </div>
    

    <div class="col-lg-12">


        <form action="" id="addForm" method="POST"
            enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="card p-2 has-select2">
                <div class="card-header">
                    <h5 class="card-title mb-0"><?php echo app('translator')->get('Update Settlement Setting'); ?></h5>
                </div>

                <div class="card-header">
                <div class="alert alert-primary" role="alert">
                  <span class=" ml-3"> To update your product sales settlement into your wallet, please select a payment cycle of choice and enter account password to validate and update settlement settings</span>
                </div>
                </div>
                
                <div class="card-body">
                   
                    <div class="form-group row">
                        <div class="col-md-2">
                            <label class="font-weight-bold"><?php echo app('translator')->get('Settlement Cycle'); ?> <span class="text--danger">*</span></label>
                        </div>
                        <div class="col-md-10">
                            <select class="form-control select2-basic" name="cycle" required id="brand">
                                <option selected disabled value=""><?php echo app('translator')->get('Select One'); ?></option>

                                <option <?php if( seller()->settlement_cycle == 0): ?> selected <?php endif; ?> value="0"><?php echo app('translator')->get('Instantly'); ?></option>
                                <option <?php if( seller()->settlement_cycle == 1): ?> selected <?php endif; ?> value="1"><?php echo app('translator')->get('24 Hours'); ?></option>
                                <option <?php if( seller()->settlement_cycle == 7): ?> selected <?php endif; ?> value="7"><?php echo app('translator')->get('Weekly'); ?></option>
                                <option <?php if( seller()->settlement_cycle == 30): ?> selected <?php endif; ?> value="30"><?php echo app('translator')->get('Monthly'); ?></option>
                                 
                            </select>
                        </div>
                    </div>
 

                    <button type="submit" class="btn btn--success mt-3">Update</button>
                </div>

               

            </div>

             
        </form>
    </div>
</div>
 
<?php $__env->stopSection(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>

<?php $__env->stopPush(); ?>

<?php $__env->startPush('script-lib'); ?>
<script src="<?php echo e(asset('assets/dashboard/js/image-uploader.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('style-lib'); ?>
<link href="https://fonts.googleapis.com/css?family=Lato:300,700|Montserrat:300,400,500,600,700|Source+Code+Pro&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo e(asset('assets/dashboard/css/image-uploader.min.css')); ?>">
<?php $__env->stopPush(); ?>


<?php $__env->startPush('script'); ?>
 

<?php $__env->stopPush(); ?>

<?php echo $__env->make('seller.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/seller/settlement/settings.blade.php ENDPATH**/ ?>