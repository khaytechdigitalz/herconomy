<?php $__env->startSection('content'); ?>
    <!-- cart-section start -->
    <div class="cart-section padding-bottom padding-top">
        <div class="container">
            <?php if($data->count()>0): ?>
            <table class="order-list-table table cart-table m-0">
                <thead>
                    <tr>
                        <th><?php echo app('translator')->get('Product'); ?></th>
                        <th><?php echo app('translator')->get('Variant'); ?></th>
                        <th><?php echo app('translator')->get('Price'); ?></th>
                        <th><?php echo app('translator')->get('Quantity'); ?></th>
                        <th><?php echo app('translator')->get('Total'); ?></th>
                        <th><?php echo app('translator')->get('Action'); ?></th>
                    </tr>
                </thead>
                <?php
                    $sub_total          = 0;
                    $product_categories = [];
                    $coupon_products    = $data->pluck('product_id')->unique()->toArray();
                ?>

                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $product_categories [] = $item->product->categories->pluck('id')->toArray();

                        $attributes = $item->attributes??null;
                        if($attributes !==null){
                            sort($attributes);
                            $attributes = json_encode($attributes);
                        }
                        $stock_qty  = App\Models\ProductStock::showAvailableStock($item->product_id, $attributes);
                    ?>

                    <tr class="cart-row">
                        <td data-label="<?php echo app('translator')->get('Product'); ?>">
                            <a href="<?php echo e(route('product.detail', ['id'=>$item->product->id, 'slug'=>slug($item->product->name)])); ?>" class="cart-item">
                                <div class="cart-img">
                                    <img src="<?php echo e(getImage(imagePath()['product']['path'].'/'.@$item->product->main_image, imagePath()['product']['size'])); ?>" alt="<?php echo app('translator')->get('product-image'); ?>">
                                </div>
                                <div class="cart-cont">
                                    <h6 class="title"><?php echo e(shortDescription(__($item->product->name), 60)); ?></h6>
                                </div>
                            </a>
                        </td>

                        <td data-label="<?php echo app('translator')->get('Variant'); ?>">
                            <?php if($item->attributes != null): ?>
                                <?php echo App\Models\AssignProductAttribute::cartAttributesShow($item->attributes) ?>
                            <?php else: ?>
                                <?php echo app('translator')->get('N\A'); ?>
                            <?php endif; ?>
                        </td>


                        <td data-label="<?php echo app('translator')->get('Price'); ?>">
                            <?php echo e($general->cur_sym); ?><?php
                            if($item->attributes != null){
                                $s_price = App\Models\AssignProductAttribute::priceAfterAttribute($item->product, $item->attributes);
                                echo getAmount($s_price, 2);
                            }else{
                                if($item->product->offer && $item->product->offer->activeOffer){
                                    $s_price = $item->product->base_price - calculateDiscount($item->product->offer->activeOffer->amount, $item->product->offer->activeOffer->discount_type, $item->product->base_price);
                                }else{
                                    $s_price = $item->product->base_price;
                                }
                                echo getAmount($s_price, 2);
                            }
                            ?>
                        </td>

                        <td data-label="<?php echo app('translator')->get('Quantity'); ?>">
                            <div class="cart-plus-minus p-0 flex-nowrap justify-content-center quantity">
                                <div class="cart-decrease qtybutton dec">
                                    <i class="las la-minus"></i>
                                </div>
                                <input type="number" data-id="<?php echo e($item->id); ?>" data-price="<?php echo e($s_price); ?>" class="qty integer-validation" type="number" min="1" step="1" value="<?php echo e($item['quantity']); ?>">
                                <div class="cart-increase qtybutton inc active">
                                    <i class="las la-plus"></i>
                                </div>
                            </div>
                        </td>

                        <td data-label="<?php echo app('translator')->get('Total'); ?>">
                            <div><?php echo e($general->cur_sym); ?><span class="total_price"><?php echo e(getAmount($s_price*$item['quantity'], 2)); ?></span>
                            </div>
                        </td>

                        <td data-label="<?php echo app('translator')->get('Action'); ?>">
                            <a href="javascript:void(0)">
                                <span class="edit remove-cart-item" data-id="<?php echo e($item->id); ?>">
                                    <i class="las la-trash"></i>
                                </span>
                            </a>
                        </td>

                    </tr>
                <?php $sub_total += $s_price*$item['quantity'] ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <div class="cart-total section-bg ">
                <div class="m--15 d-flex flex-wrap align-items-center justify-content-between">
                    
                    <div class="total">
                        <div class="d-flex flex-wrap justify-content-between">
                            <div class="sub--total"><?php echo app('translator')->get('Subtotal'); ?></div>
                            <span class="amount"><?php echo e($general->cur_sym); ?><span id="cartSubtotal"><?php echo e(getAmount($sub_total, 2)); ?></span></span>
                        </div>
                        <div class="coupon-amount-total <?php if(!session()->has('coupon')): ?> d-none <?php endif; ?>">
                            <div class="d-flex flex-wrap justify-content-between">
                                <div class="sub--total">

                                    <span class="mr-2 cl-theme remove-coupon"><i class="la la-times-circle"></i></span>

                                    <span><?php echo app('translator')->get('Coupon'); ?> (<b class="couponCode"><?php echo e(@session('coupon')['code']); ?></b>) </span>

                                </div>
                                <span class="amount"><?php echo e($general->cur_sym); ?><span id="couponAmount"> <?php echo e(@session('coupon')['amount']??0); ?></span> </span>
                            </div>
                            <div class="d-flex flex-wrap justify-content-between">
                                <div class="sub--total"><span><?php echo app('translator')->get('Total'); ?> </span></div>
                                <span class="amount"><?php echo e($general->cur_sym); ?><span id="finalTotal"><?php echo e(getAmount($sub_total- @session('coupon')['amount']??0 , 0)); ?></span></span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="checkout mt-3 d-flex flex-wrap justify-content-sm-between justify-content-around">
                <a href="<?php echo e(route('products')); ?>" class="theme custom-button btn-dark border-0 mt-3"><?php echo app('translator')->get('Continue Shopping'); ?></a>
                <a href="<?php echo e(route('user.checkout')); ?>" class="theme cmn--btn mt-3"><?php echo app('translator')->get('Checkout'); ?></a>
            </div>
            <?php else: ?>
            <div class="alert alert-warning alert-dismissible fade show" role="alert">
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
                <strong><?php echo e(__($emptyMessage)); ?></strong>
              </div>
            <?php endif; ?>
        </div>
    </div>
    <!-- cart-section end -->

<?php $__env->stopSection(); ?>
<?php $__env->startPush('script'); ?>
    <script>
    'use strict';
    (function($){
        var cartSubtotal = parseFloat('<?php echo e($sub_total??0); ?>');
        sessionStorage.setItem('subtotal', cartSubtotal);

        $('.quantity input[type=number]').on('keyup',function(){
            updateCart($(this), this.value)
        });

        $('.qtybutton').on('click',function(){
            var couponAmount = parseFloat($('#couponAmount').text()).toFixed(2);
            if(couponAmount > 0) {
                notify('error', 'You have applied a coupon on your cart. If you want to update your cart, at first remove the coupon.');
                return false;
            }
            var oldValue = $(this).parents('.cart-row').find('input[type=number]').val();

            if ($(this).hasClass('inc')) {
                var qty = parseFloat(oldValue) + 1;
            } else {
                if (oldValue > 1) {
                    var qty = parseFloat(oldValue) - 1;
                } else {
                    qty = 1;
                }
            }
            updateCart($(this), qty)
        });

        function updateCart(obj, qty) {
            var parent      = obj.parents('.cart-row');
            var sub_total   = formatNumber($('#cartSubtotal').text());
            var prev_total  = formatNumber(parent.find('.total_price').text());
            var price       = formatNumber(parent.find('input[type=number]').data('price'));
            var total       = qty*price;
            var dif         = total - parseFloat(prev_total);
            var subtotal    = (parseFloat(sub_total) + parseFloat(dif));
            var id          = $(parent).find('input[type=number]').data('id');
            var data        = {quantity:qty};

            $.ajax({
                headers: {"X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"},
                url: "<?php echo e(route('update-cart-item', '')); ?>"+"/"+id,
                method:"post",
                data: data,
                success: function(response){
                    if(response.error){
                        $('.quantity input[type=number]').val(response.qty)
                        notify('error', response.error);
                    }else{
                        $('#cartSubtotal').text(parseFloat(subtotal).toFixed(2));
                        sessionStorage.setItem('subtotal', subtotal.toFixed(2));
                        parent.find('.total_price').text(parseFloat(total.toFixed(2)));
                        getCartTotal();
                        getCartData();
                        $('#finalTotal').text(parseFloat((subtotal - parseFloat($('#couponAmount').text())).toFixed(2)));
                    }
                }
            });
        }

        $(document).on('click', 'button[name=coupon_apply]', function(){
            var code = $('input[name=coupon_code]').val();
            var subtotal = formatNumber($('#cartSubtotal').text());

            $.ajax({
                headers: {"X-CSRF-TOKEN": "<?php echo e(csrf_token()); ?>"},
                url: `<?php echo e(route('applyCoupon')); ?>`,
                method:"POST",
                data:{
                    code:code,
                    subtotal: subtotal,
                    categories: <?php echo json_encode(@$product_categories, 15, 512) ?>,
                    products: <?php echo json_encode(@$coupon_products, 15, 512) ?>
                },
                success: function(response){
                    if(response.success) {
                        $('#couponAmount').text(response.amount);
                        $('#finalTotal').text(parseFloat((subtotal - response.amount).toFixed(2)));

                        $('.couponCode').text(response.coupon_code);

                        $('.coupon-amount-total').removeClass('d-none').hide().show('300');
                        getCartData();
                        notify('success', response.success);
                    }else if(response.error){
                        notify('error', response.error);
                    }else{
                        notify('error', response);
                    }
                }
            });
        });

        function formatNumber(number){
            if(typeof(number) != 'string'){
                return number;
            }
            return parseFloat(number.replace(/,/g, ''));
        }
    })(jQuery);
    </script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('breadcrumb-plugins'); ?>
<li><a href="<?php echo e(route('home')); ?>"><?php echo app('translator')->get('Home'); ?></a></li>
<li><a href="<?php echo e(route('products')); ?>"><?php echo app('translator')->get('Products'); ?></a></li>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('meta-tags'); ?>
    <?php echo $__env->make('partials.seo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make(activeTemplate() .'layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/heconomy/core/resources/views/templates/basic/cart.blade.php ENDPATH**/ ?>